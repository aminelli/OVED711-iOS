//
//  InfraDemoTests.swift
//  InfraDemoTests
//
//  Created by Antonio Minelli on 18/06/2026.
//

import Testing
@testable import InfraDemo

struct InfraDemoTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
        // Swift Testing Documentation
        // https://developer.apple.com/documentation/testing
    }

}
