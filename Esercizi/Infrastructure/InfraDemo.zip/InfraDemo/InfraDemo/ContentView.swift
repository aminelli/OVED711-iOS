//
//  ContentView.swift
//  InfraDemo
//
//  Created by Antonio Minelli.
//
// ContentView è ora solo un alias per RootView.
// Tutta la struttura dell'app è gestita da AppCoordinator e RootView.
// Questo file può essere mantenuto per retrocompatibilità con i Preview.

import SwiftUI

struct ContentView: View {
    var body: some View {
        // In produzione viene usata RootView (con DependencyContainer).
        // Qui usiamo un container di default per il Preview.
        RootView(container: DependencyContainer())
    }
}

#Preview {
    ContentView()
}

