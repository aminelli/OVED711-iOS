//
//  InfraDemoApp.swift
//  InfraDemo
//
//  Created by Antonio Minelli.
//
// Punto di ingresso dell'applicazione.
// Il DependencyContainer (Composition Root) viene creato UNA SOLA VOLTA qui
// e distribuito all'intero albero di viste tramite SwiftUI Environment.
// MetricKit viene registrato subito per non perdere eventi dall'avvio.

import SwiftUI
internal import os

@main
struct InfraDemoApp: App {

    // MARK: - Composition Root

    /// Il container è @StateObject per garantire che venga creato una sola volta
    /// e distrutto solo con l'app (ciclo di vita identico a @main).
    @StateObject private var container = DependencyContainer()

    // MARK: - App Delegate adapter (per MetricKit e altre API UIKit)

    @UIApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate

    // MARK: - Scene

    var body: some Scene {
        WindowGroup {
            RootView(container: container)
        }
    }
}

// MARK: - AppDelegate

/// Necessario per la registrazione a MetricKit e altre API che richiedono
/// i metodi del ciclo di vita di UIApplicationDelegate.
final class AppDelegate: NSObject, UIApplicationDelegate {

    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil
    ) -> Bool {
        // Registrazione a MetricKit: deve avvenire il prima possibile
        Task { @MainActor in
            MetricKitSubscriber.shared.register()
        }

        AppLogger.network.info("App avviata — InfraDemo")
        return true
    }

    func applicationWillTerminate(_ application: UIApplication) {
        MetricKitSubscriber.shared.unregister()
    }
}

