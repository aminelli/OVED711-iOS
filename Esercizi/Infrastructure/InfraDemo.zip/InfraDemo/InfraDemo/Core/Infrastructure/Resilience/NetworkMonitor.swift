// NetworkMonitor.swift
// InfraDemo
//
// Monitoraggio della connettività di rete con NWPathMonitor.
// Implementa il pattern "offline-first": l'app sa in ogni momento
// se è connessa e può decidere se usare la cache o mostrare un banner.
// Usa un `actor` per proteggere lo stato della connettività.

import Foundation
import Network
import OSLog
import Combine

// MARK: - NetworkStatus

/// Stato della connettività di rete.
public enum NetworkStatus: Sendable, Equatable {
    case connected(interface: ConnectionInterface)
    case disconnected
    case unknown
}

/// Tipo di interfaccia di rete attiva.
public enum ConnectionInterface: Sendable, Equatable {
    case wifi
    case cellular
    case wiredEthernet
    case other
}

// MARK: - NetworkMonitor

/// Actor che osserva lo stato della rete con `NWPathMonitor`.
/// Espone un `AsyncStream<NetworkStatus>` per il consumo reattivo.
@MainActor
public final class NetworkMonitor: ObservableObject {

    // MARK: - Published State (MainActor)

    /// Stato attuale della connettività, osservabile da SwiftUI.
    @Published public private(set) var status: NetworkStatus = .unknown

    /// `true` se la rete è disponibile.
    public var isConnected: Bool {
        if case .connected = status { return true }
        return false
    }

    // MARK: - Proprietà private

    private let monitor: NWPathMonitor
    private let queue   = DispatchQueue(label: "com.infrademo.NetworkMonitor", qos: .utility)
    private let logger  = Logger(subsystem: "com.infrademo", category: "NetworkMonitor")

    // MARK: - Init

    public init() {
        self.monitor = NWPathMonitor()
    }

    // MARK: - Start / Stop

    /// Avvia il monitoraggio della rete.
    public func start() {
        monitor.pathUpdateHandler = { [weak self] path in
            guard let self else { return }
            let newStatus = Self.mapPath(path)
            Task { @MainActor in
                self.status = newStatus
                self.logger.info("Stato rete → \(String(describing: newStatus))")
            }
        }
        monitor.start(queue: queue)
        logger.debug("NetworkMonitor avviato.")
    }

    /// Ferma il monitoraggio della rete.
    public func stop() {
        monitor.cancel()
        logger.debug("NetworkMonitor fermato.")
    }

    // MARK: - Mapping NWPath → NetworkStatus

    // `nonisolated`: chiamato dalla closure nonisolated di pathUpdateHandler
    // (dispatch queue arbitraria di NWPathMonitor), non dal MainActor.
    private nonisolated static func mapPath(_ path: NWPath) -> NetworkStatus {
        guard path.status == .satisfied else { return .disconnected }

        if path.usesInterfaceType(.wifi)     { return .connected(interface: .wifi) }
        if path.usesInterfaceType(.cellular) { return .connected(interface: .cellular) }
        if path.usesInterfaceType(.wiredEthernet) { return .connected(interface: .wiredEthernet) }
        return .connected(interface: .other)
    }
}
