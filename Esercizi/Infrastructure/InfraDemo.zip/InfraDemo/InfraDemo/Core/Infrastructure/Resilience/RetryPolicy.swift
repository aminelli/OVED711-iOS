// RetryPolicy.swift
// InfraDemo
//
// Policy di retry con backoff esponenziale e jitter.
// Il backoff esponenziale evita il "thundering herd": quando molti client
// falliscono contemporaneamente, aspettano tempi crescenti prima di riprovare,
// distribuendo il carico sul server.
// Il jitter (variazione casuale) evita che tutti i client ripartano allo stesso istante.

import Foundation
import OSLog

// MARK: - RetryPolicy

/// Esegue un blocco asincrono con retry automatici e backoff esponenziale.
/// Conforme a `Sendable` per l'uso con actor e TaskGroup.
public struct RetryPolicy: Sendable {

    // MARK: - Configurazione

    /// Numero massimo di tentativi (incluso il primo).
    public let maxAttempts: Int

    /// Delay base in secondi (es. 0.5 → 0.5s, 1s, 2s, 4s, …).
    public let baseDelay: TimeInterval

    /// Moltiplicatore per il backoff (default = 2.0 → backoff esponenziale base-2).
    public let multiplier: Double

    /// Delay massimo per evitare attese eccessive (es. 30 secondi).
    public let maxDelay: TimeInterval

    /// Set di errori che NON devono essere ritentati (es. 401 Unauthorized).
    public let nonRetryableErrors: Set<NetworkError>

    private let logger = Logger(subsystem: "com.infrademo", category: "RetryPolicy")

    // MARK: - Init

    public init(
        maxAttempts: Int = 3,
        baseDelay: TimeInterval = 0.5,
        multiplier: Double = 2.0,
        maxDelay: TimeInterval = 30.0
    ) {
        self.maxAttempts        = maxAttempts
        self.baseDelay          = baseDelay
        self.multiplier         = multiplier
        self.maxDelay           = maxDelay
        // 401 non va ritentato: il token refresh è gestito separatamente
        self.nonRetryableErrors = [.unauthorized, .cancelled]
    }

    // MARK: - Esecuzione con retry

    /// Esegue `operation` con retry automatico in caso di errore recuperabile.
    /// - Parameter operation: blocco asincrono che può lanciare errori.
    /// - Returns: risultato dell'operazione al primo successo.
    public func execute<T: Sendable>(
        _ operation: @Sendable () async throws -> T
    ) async throws -> T {

        var lastError: Error?

        for attempt in 1...maxAttempts {
            do {
                let result = try await operation()
                if attempt > 1 {
                    logger.info("Operazione riuscita al tentativo \(attempt).")
                }
                return result
            } catch let error as NetworkError where nonRetryableErrors.contains(error) {
                // Errore non-recuperabile: propaga immediatamente senza retry
                logger.warning("Errore non-recuperabile (\(error)): nessun retry.")
                throw error
            } catch {
                lastError = error
                if attempt < maxAttempts {
                    // Calcola il delay con backoff esponenziale + jitter casuale
                    let delay = computeDelay(attempt: attempt)
                    logger.warning(
                        "Tentativo \(attempt)/\(maxAttempts) fallito: \(error). Retry tra \(String(format: "%.2f", delay))s…"
                    )
                    try await Task.sleep(for: .seconds(delay))
                } else {
                    logger.error("Tutti i \(maxAttempts) tentativi falliti.")
                }
            }
        }

        throw lastError ?? URLError(.unknown)
    }

    // MARK: - Calcolo del delay

    /// Calcola il delay per il tentativo `attempt` con backoff esponenziale e jitter.
    /// Formula: min(baseDelay * multiplier^(attempt-1) + random jitter, maxDelay)
    private func computeDelay(attempt: Int) -> TimeInterval {
        // Backoff esponenziale: 0.5s → 1s → 2s → 4s → …
        let exponential = baseDelay * pow(multiplier, Double(attempt - 1))
        // Jitter: ±20% per distribuire i retry
        let jitter = exponential * 0.2 * Double.random(in: -1...1)
        return min(exponential + jitter, maxDelay)
    }
}

// MARK: - NetworkError: Hashable (necessario per Set<NetworkError>)

extension NetworkError: Hashable {
    public static func == (lhs: NetworkError, rhs: NetworkError) -> Bool {
        switch (lhs, rhs) {
        case (.invalidURL, .invalidURL):         return true
        case (.unauthorized, .unauthorized):     return true
        case (.noConnection, .noConnection):     return true
        case (.cancelled, .cancelled):           return true
        case (.invalidResponse(let a), .invalidResponse(let b)): return a == b
        default: return false
        }
    }

    public func hash(into hasher: inout Hasher) {
        switch self {
        case .invalidURL:               hasher.combine(0)
        case .invalidResponse(let c):   hasher.combine(1); hasher.combine(c)
        case .decodingFailed:           hasher.combine(2)
        case .unauthorized:             hasher.combine(3)
        case .noConnection:             hasher.combine(4)
        case .cancelled:                hasher.combine(5)
        case .unknown:                  hasher.combine(6)
        }
    }
}
