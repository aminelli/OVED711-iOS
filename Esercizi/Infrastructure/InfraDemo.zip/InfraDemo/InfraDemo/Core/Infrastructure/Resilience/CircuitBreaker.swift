// CircuitBreaker.swift
// InfraDemo
//
// Implementazione del pattern Circuit Breaker.
// Il Circuit Breaker previene il sovraccarico di un servizio non disponibile:
// dopo N fallimenti consecutivi "apre" il circuito e rifiuta immediatamente
// le richieste per un periodo di cooldown, poi passa allo stato "half-open"
// per verificare se il servizio è tornato disponibile.
//
// Stati:
//   closed    → circuito chiuso, richieste passano normalmente
//   open      → circuito aperto, richieste rifiutate immediatamente
//   halfOpen  → un solo tentativo di verifica, poi closed o open

import Foundation
import OSLog

// MARK: - CircuitBreakerError

public enum CircuitBreakerError: Error, Sendable {
    /// Il circuito è aperto: la richiesta è stata rifiutata senza eseguire l'operazione.
    case circuitOpen
}

// MARK: - CircuitBreaker

/// Actor per il Circuit Breaker: lo stato è protetto dall'actor isolation.
public actor CircuitBreaker {

    // MARK: - Stato

    /// Stato del circuito.
    public enum State: Sendable {
        case closed     // Normale operatività
        case open       // Servizio non disponibile, richieste bloccate
        case halfOpen   // Un tentativo di verifica in corso
    }

    // MARK: - Configurazione

    private let failureThreshold: Int       // N fallimenti per aprire il circuito
    private let cooldownDuration: Duration  // Durata del cooldown in stato open

    // MARK: - Stato interno

    private(set) var state: State = .closed
    private var failureCount: Int = 0
    private var lastFailureDate: Date?

    private let logger = Logger(subsystem: "com.infrademo", category: "CircuitBreaker")

    // MARK: - Init

    public init(failureThreshold: Int = 3, cooldownDuration: Duration = .seconds(15)) {
        self.failureThreshold = failureThreshold
        self.cooldownDuration = cooldownDuration
    }

    // MARK: - Esecuzione protetta

    /// Esegue `operation` se il circuito è chiuso/half-open.
    /// Lancia `CircuitBreakerError.circuitOpen` se il circuito è aperto.
    public func execute<T: Sendable>(
        _ operation: @Sendable () async throws -> T
    ) async throws -> T {

        switch state {

        case .open:
            // Controlla se il cooldown è scaduto e passa a half-open
            guard let last = lastFailureDate,
                  await Date().timeIntervalSince(last) >= cooldownDuration.seconds else {
                logger.warning("Circuito APERTO: richiesta rifiutata.")
                throw CircuitBreakerError.circuitOpen
            }
            // Cooldown scaduto: passa a half-open per un tentativo di verifica
            state = .halfOpen
            logger.info("Circuito → HALF-OPEN: tentativo di verifica.")
            fallthrough

        case .halfOpen, .closed:
            do {
                let result = try await operation()
                // Successo: resetta il circuito
                reset()
                return result
            } catch {
                recordFailure()
                throw error
            }
        }
    }

    // MARK: - Helpers privati

    /// Registra un fallimento e apre il circuito se supera la soglia.
    private func recordFailure() {
        failureCount    += 1
        lastFailureDate  = Date()

        if state == .halfOpen || failureCount >= failureThreshold {
            state = .open
            logger.error(
                "Circuito → APERTO dopo \(self.failureCount) fallimenti. Cooldown: \(self.cooldownDuration.seconds)s"
            )
        } else {
            logger.warning("Fallimento \(self.failureCount)/\(self.failureThreshold) registrato.")
        }
    }

    /// Resetta il circuito allo stato chiuso dopo un successo.
    private func reset() {
        if state != .closed {
            logger.info("Circuito → CHIUSO: servizio ripristinato.")
        }
        state        = .closed
        failureCount = 0
        lastFailureDate = nil
    }
}

// MARK: - Duration helper

private extension Duration {
    /// Converte `Duration` in secondi `TimeInterval` per la compatibilità con `Date`.
    var seconds: TimeInterval {
        let (secs, attosecs) = self.components
        return TimeInterval(secs) + TimeInterval(attosecs) * 1e-18
    }
}
