// AppLogger.swift
// InfraDemo
//
// Logger centralizzato basato su os.Logger (framework OSLog).
// os.Logger è il sistema di logging ufficiale Apple:
//   - Performante: le stringhe private NON vengono interpolate se non necessario
//   - Privacy-aware: i valori sensibili vengono redatti nei log pubblici
//   - Livelli: debug, info, notice, warning, error, fault (critical)
//   - Visibile in Console.app e Instruments
//
// Convenzione di privacy:
//   - .public:  visibile a tutti (no dati sensibili)
//   - .private: redatto nei log, visibile solo in debug con profilo abilitato
//   - .sensitive: alias di .private in OSLog

import Foundation
import OSLog

// MARK: - AppLogger

/// Namespace statico per i logger dell'applicazione, organizzati per categoria.
/// Ogni categoria corrisponde a un modulo o layer dell'app.
public enum AppLogger {

    // MARK: - Logger per categoria

    /// Layer di rete (URLSession, Endpoint, ecc.)
    public static let network = Logger(subsystem: subsystem, category: "Network")

    /// Layer di persistenza/cache
    public static let cache   = Logger(subsystem: subsystem, category: "Cache")

    /// Layer di presentazione (ViewModel, Coordinator)
    public static let ui      = Logger(subsystem: subsystem, category: "UI")

    /// UseCase e logica di business
    public static let domain  = Logger(subsystem: subsystem, category: "Domain")

    /// Errori critici / fault (equivalente a os_log con type: .fault)
    public static let crash   = Logger(subsystem: subsystem, category: "Crash")

    /// Auth e token
    public static let auth    = Logger(subsystem: subsystem, category: "Auth")

    // MARK: - Subsystem

    /// Identificatore univoco del bundle: usato per filtrare in Console.app
    public static let subsystem = Bundle.main.bundleIdentifier ?? "com.infrademo"

    // MARK: - Esempi di utilizzo con livelli e privacy

    /// Registra un evento di rete con i dati dell'URL (pubblico) e del body (privato).
    public static func logRequest(url: String, body: String?) {
        // url è pubblico: non contiene dati personali
        network.debug("→ Request: \(url, privacy: .public)")
        // body può contenere token o dati sensibili → .private
        if let body {
            network.debug("  Body: \(body, privacy: .private)")
        }
    }

    /// Registra un evento di autenticazione. L'email è dati personale → .private
    public static func logLogin(email: String, success: Bool) {
        if success {
            auth.info("Login riuscito per: \(email, privacy: .private)")
        } else {
            auth.warning("Login fallito per: \(email, privacy: .private)")
        }
    }

    /// Registra un errore critico (fault = crash del processo).
    public static func logFault(_ message: String, error: Error) {
        crash.fault("\(message, privacy: .public): \(error.localizedDescription, privacy: .public)")
    }
}

// MARK: - OSLogStore (lettura dei log programmatica)

/// Utility per leggere gli ultimi log dell'app tramite OSLogStore.
/// Utile per il "breadcrumb trail" (vedere BreadcrumbTrail.swift).
@available(iOS 15.0, *)
public struct LogReader {

    /// Recupera gli ultimi N messaggi di log per un dato subsystem.
    /// - Note: Richiede il processo che legge i propri log (no altri processi).
    public static func recentEntries(limit: Int = 50) throws -> [String] {
        let store = try OSLogStore(scope: .currentProcessIdentifier)
        let position = store.position(timeIntervalSinceLatestBoot: 1)

        let entries = try store.getEntries(at: position)
            .compactMap { $0 as? OSLogEntryLog }
            .filter { $0.subsystem == AppLogger.subsystem }
            .suffix(limit)
            .map { "[\($0.date)] [\($0.category)] \($0.composedMessage)" }

        return Array(entries)
    }
}
