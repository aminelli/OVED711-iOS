// BreadcrumbTrail.swift
// InfraDemo
//
// Implementazione del pattern "Breadcrumb Trail" per il debugging.
// Un breadcrumb trail è una sequenza ordinata degli ultimi N eventi significativi
// dell'applicazione. Quando si verifica un crash o un errore difficile da riprodurre,
// il trail fornisce il contesto degli eventi che hanno portato all'errore.
// Ispirato al sistema di Sentry/Crashlytics.

import Foundation
import OSLog

// MARK: - Breadcrumb

/// Un singolo evento nel trail.
public struct Breadcrumb: Sendable, Codable {

    public enum Level: String, Codable, Sendable {
        case debug
        case info
        case warning
        case error
        case critical
    }

    /// Categoria dell'evento (es. "navigation", "network", "ui").
    public let category:  String

    /// Messaggio leggibile dell'evento.
    public let message:   String

    /// Livello di severità.
    public let level:     Level

    /// Timestamp dell'evento.
    public let timestamp: Date

    /// Metadati aggiuntivi opzionali (es. codice HTTP, ID utente).
    public let metadata:  [String: String]?

    public init(
        category: String,
        message:  String,
        level:    Level = .info,
        metadata: [String: String]? = nil
    ) {
        self.category  = category
        self.message   = message
        self.level     = level
        self.timestamp = Date()
        self.metadata  = metadata
    }
}

// MARK: - BreadcrumbTrail

/// Actor che mantiene un buffer circolare degli ultimi N breadcrumb.
/// Thread-safe per design (actor isolation).
public actor BreadcrumbTrail {

    // MARK: - Configurazione

    private let maxCapacity: Int

    // MARK: - Buffer degli eventi

    private var crumbs: [Breadcrumb] = []

    private let logger = Logger(subsystem: "com.infrademo", category: "BreadcrumbTrail")

    // MARK: - Init

    public init(maxCapacity: Int = 50) {
        self.maxCapacity = maxCapacity
    }

    // MARK: - API pubblica

    /// Aggiunge un breadcrumb al trail.
    /// Se il buffer è pieno, rimuove il più vecchio (buffer circolare FIFO).
    public func add(_ crumb: Breadcrumb) {
        if crumbs.count >= maxCapacity {
            crumbs.removeFirst()
        }
        crumbs.append(crumb)

        // Registra anche su os.Logger per visibilità in Console.app
        logger.debug("[\(crumb.category)] \(crumb.message, privacy: .public)")
    }

    /// Restituisce una copia immutabile del trail corrente (dal più vecchio al più recente).
    public func snapshot() -> [Breadcrumb] {
        crumbs
    }

    /// Svuota il trail.
    public func clear() {
        crumbs.removeAll()
    }

    // MARK: - Helper: aggiungi breadcrumb navigazione

    public func navigation(to screen: String) async {
        await add(Breadcrumb(category: "navigation", message: "Aperta schermata: \(screen)"))
    }

    public func networkRequest(url: String, statusCode: Int) async {
        await add(Breadcrumb(
            category: "network",
            message:  "HTTP \(statusCode) ← \(url)",
            level:    statusCode >= 400 ? .error : .info,
            metadata: ["statusCode": "\(statusCode)", "url": url]
        ))
    }

    public func userAction(_ action: String) async {
        await add(Breadcrumb(category: "ui", message: action))
    }
}
