// MetricKitSubscriber.swift
// InfraDemo
//
// Integrazione con MetricKit per il monitoraggio delle prestazioni in produzione.
// MetricKit fornisce metriche aggregate (batteria, CPU, memoria, rete, hang, crash)
// raccolte dal sistema e consegnate all'app ogni 24 ore (o immediatamente per i diagnostici).
//
// Metriche principali disponibili:
//   - MXCPUMetric:         utilizzo CPU
//   - MXMemoryMetric:      utilizzo memoria
//   - MXNetworkTransferMetric: byte inviati/ricevuti
//   - MXAppLaunchMetric:   tempo di avvio
//   - MXHangDiagnostic:    hang dell'UI (> 250ms sul main thread)
//   - MXCrashDiagnostic:   crash con stack trace
//   - MXDiskIOMetric:      I/O su disco

import Foundation
import MetricKit
import OSLog

// MARK: - MetricKitSubscriber

/// Sottoscrittore alle metriche di sistema via MetricKit.
/// Conforme a `MXMetricManagerSubscriber` per ricevere il payload.
/// `@MainActor` perché la registrazione al `MXMetricManager` avviene sul main thread.
@MainActor
public final class MetricKitSubscriber: NSObject, MXMetricManagerSubscriber {

    // MARK: - Singleton (registrazione unica)

    public static let shared = MetricKitSubscriber()

    private let logger = Logger(subsystem: "com.infrademo", category: "MetricKit")

    // MARK: - Registrazione

    /// Da chiamare in `application(_:didFinishLaunchingWithOptions:)` o nell'`@main`.
    public func register() {
        MXMetricManager.shared.add(self)
        logger.info("MetricKitSubscriber registrato.")
    }

    /// Da chiamare quando l'app viene terminata o il subscriber non serve più.
    public func unregister() {
        MXMetricManager.shared.remove(self)
    }

    // MARK: - MXMetricManagerSubscriber

    /// Chiamato dal sistema con il payload delle metriche (ogni ~24h in produzione,
    /// immediatamente in simulatore/Xcode con `xcrun simctl diagnose`).
    nonisolated public func didReceive(_ payloads: [MXMetricPayload]) {
        for payload in payloads {
            processMetricPayload(payload)
        }
    }

    /// Chiamato con i payload diagnostici (hang, crash, ecc.) – più urgenti.
    nonisolated public func didReceive(_ payloads: [MXDiagnosticPayload]) {
        for payload in payloads {
            processDiagnosticPayload(payload)
        }
    }

    // MARK: - Elaborazione metriche

    private nonisolated func processMetricPayload(_ payload: MXMetricPayload) {
        // Intervallo di raccolta delle metriche
        let interval = payload.timeStampBegin..<payload.timeStampEnd

        // Metriche di avvio dell'app
        if let launch = payload.applicationLaunchMetrics {
            let ttid = launch.histogrammedTimeToFirstDraw.bucketEnumerator
                .compactMap { $0 as? MXHistogramBucket<UnitDuration> }
                .first?.bucketEnd.value ?? 0
            logger.info("Avvio app (TTID): ~\(ttid, privacy: .public)ms — intervallo: \(String(describing: interval), privacy: .public)")
        }

        // Utilizzo CPU
        if let cpu = payload.cpuMetrics {
            logger.info("CPU cumulative: \(cpu.cumulativeCPUTime.value, privacy: .public) \(cpu.cumulativeCPUTime.unit, privacy: .public)")
        }

        // Utilizzo memoria
        if let mem = payload.memoryMetrics {
            logger.info("Memoria picco: \(mem.peakMemoryUsage.value, privacy: .public) \(mem.peakMemoryUsage.unit, privacy: .public)")
        }

        // Rete
        if let net = payload.networkTransferMetrics {
            logger.info("Upload: \(net.cumulativeCellularUpload.value, privacy: .public) MB — Download: \(net.cumulativeCellularDownload.value, privacy: .public) MB")
        }

        // Hang del main thread
        if let hang = payload.applicationResponsivenessMetrics {
            logger.warning("Hang del main thread rilevati nell'intervallo: \(String(describing: hang), privacy: .public)")
        }
    }

    private nonisolated func processDiagnosticPayload(_ payload: MXDiagnosticPayload) {
        // Hang diagnostici (UI bloccata > 250ms)
        for hang in payload.hangDiagnostics ?? [] {
            logger.fault("Hang rilevato: \(hang.callStackTree.jsonRepresentation().debugDescription, privacy: .private)")
        }

        // Crash diagnostici con stack trace
        for crash in payload.crashDiagnostics ?? [] {
            logger.fault("Crash: \(crash.callStackTree.jsonRepresentation().debugDescription, privacy: .private)")
        }

        // Disk write exceptions (scritture eccessive)
        for diskWrite in payload.diskWriteExceptionDiagnostics ?? [] {
            logger.error("DiskWrite exception: \(diskWrite.callStackTree.jsonRepresentation().debugDescription, privacy: .private)")
        }
    }
}
