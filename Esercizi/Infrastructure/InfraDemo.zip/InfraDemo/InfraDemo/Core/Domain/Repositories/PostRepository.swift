// PostRepository.swift
// InfraDemo
//
// Protocollo Repository per i Post – layer Dominio.
// Il dominio dichiara SOLO l'interfaccia; l'implementazione concreta
// risiede nel layer Data, rispettando la Dependency Rule di Clean Architecture:
// le dipendenze puntano sempre verso l'interno (dominio).

import Foundation

/// Contratto che ogni implementazione del repository dei post deve rispettare.
/// Usato dagli UseCase per recuperare/modificare i post senza
/// conoscere la sorgente dati sottostante (REST, GraphQL, database locale…).
public protocol PostRepository: Sendable {

    /// Recupera una pagina di post tramite cursore.
    /// - Parameter cursor: cursore opzionale per la paginazione; nil = prima pagina.
    /// - Returns: tupla con l'array di post e il prossimo cursore (nil se ultima pagina).
    func fetchPosts(cursor: String?) async throws -> (posts: [Post], nextCursor: String?)

    /// Recupera un singolo post per identificatore.
    func fetchPost(id: Int) async throws -> Post

    /// Recupera i post di uno specifico utente.
    func fetchPosts(forUserID userID: Int) async throws -> [Post]
}
