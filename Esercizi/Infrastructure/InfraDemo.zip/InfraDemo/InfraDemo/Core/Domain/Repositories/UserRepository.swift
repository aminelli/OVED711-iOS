// UserRepository.swift
// InfraDemo
//
// Protocollo Repository per gli Utenti – layer Dominio.

import Foundation

/// Contratto per l'accesso agli utenti, indipendente dalla sorgente dati.
public protocol UserRepository: Sendable {

    /// Recupera la lista completa degli utenti.
    func fetchUsers() async throws -> [User]

    /// Recupera un singolo utente per ID.
    func fetchUser(id: Int) async throws -> User
}
