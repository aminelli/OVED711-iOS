// Post.swift
// InfraDemo
//
// Entità di dominio per un Post.
// In Clean Architecture, le entità sono il nucleo più interno: non dipendono
// da alcun framework, database o UI. Devono essere pure strutture dati
// con eventuale logica di business intrinseca.

import Foundation

/// Rappresenta un singolo post nel dominio dell'applicazione.
/// Conforme a `Sendable` per la piena compatibilità con Swift 6 strict concurrency:
/// può essere trasmessa in modo sicuro tra actor/task concorrenti.
public struct Post: Identifiable, Equatable, Hashable, Sendable {

    // MARK: - Proprietà di dominio

    /// Identificatore univoco del post.
    public let id: Int

    /// Identificatore dell'utente autore del post.
    public let userID: Int

    /// Titolo del post.
    public let title: String

    /// Corpo testuale del post.
    public let body: String

    // MARK: - Inizializzazione (init-based DI friendly)

    public init(id: Int, userID: Int, title: String, body: String) {
        self.id     = id
        self.userID = userID
        self.title  = title
        self.body   = body
    }
}
