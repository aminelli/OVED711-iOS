// User.swift
// InfraDemo
//
// Entità di dominio per un Utente.
// Separata dal DTO (UserDTO) che vive nel layer Data:
// la Dependency Rule di Clean Architecture vieta al dominio
// di conoscere i dettagli di serializzazione JSON.

import Foundation

/// Rappresenta un utente nel dominio dell'applicazione.
/// `Sendable` consente il passaggio sicuro tra task/actor in Swift 6.
public struct User: Identifiable, Equatable, Hashable, Sendable {

    // MARK: - Proprietà di dominio

    public let id: Int
    public let name: String
    public let username: String
    public let email: String
    public let website: String?

    // MARK: - Indirizzo (oggetto valore annidato)

    /// Indirizzo dell'utente - esempio di Value Object nel dominio.
    public struct Address: Equatable, Hashable, Sendable {
        public let street: String
        public let city: String
        public let zipcode: String

        public init(street: String, city: String, zipcode: String) {
            self.street  = street
            self.city    = city
            self.zipcode = zipcode
        }
    }

    public let address: Address?

    // MARK: - Init

    public init(
        id: Int,
        name: String,
        username: String,
        email: String,
        website: String? = nil,
        address: Address? = nil
    ) {
        self.id       = id
        self.name     = name
        self.username = username
        self.email    = email
        self.website  = website
        self.address  = address
    }
}
