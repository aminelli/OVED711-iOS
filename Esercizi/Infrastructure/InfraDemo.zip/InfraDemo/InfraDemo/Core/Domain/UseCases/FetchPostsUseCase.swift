// FetchPostsUseCase.swift
// InfraDemo
//
// UseCase: recupera una pagina di post con paginazione cursor-based.
// Un UseCase (o Interactor) incapsula UN'unica regola di business.
// Dipende SOLO dall'interfaccia Repository (mai dall'implementazione concreta),
// garantendo testabilità e rispetto della Dependency Rule.

import Foundation

/// Protocollo del UseCase per la testabilità tramite mock.
public protocol FetchPostsUseCaseProtocol: Sendable {
    func execute(cursor: String?) async throws -> (posts: [Post], nextCursor: String?)
}

/// Implementazione concreta del UseCase FetchPosts.
/// Iniettato tramite init-based DI con il protocollo `PostRepository`.
public struct FetchPostsUseCase: FetchPostsUseCaseProtocol {

    // MARK: - Dipendenze (init-based DI)

    /// Repository iniettato: il UseCase NON conosce l'implementazione concreta.
    private let repository: any PostRepository

    // MARK: - Init

    public init(repository: any PostRepository) {
        self.repository = repository
    }

    // MARK: - Esecuzione

    /// Esegue il UseCase restituendo la pagina di post richiesta.
    /// - Parameter cursor: cursore della pagina; nil per la prima pagina.
    public func execute(cursor: String?) async throws -> (posts: [Post], nextCursor: String?) {
        // Delega interamente al repository; in futuro si potrebbero aggiungere
        // validazioni, trasformazioni o regole di business senza toccare il repository.
        try await repository.fetchPosts(cursor: cursor)
    }
}
