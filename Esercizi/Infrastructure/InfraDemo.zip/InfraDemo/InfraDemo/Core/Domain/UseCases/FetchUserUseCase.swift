// FetchUserUseCase.swift
// InfraDemo
//
// UseCase: recupera un singolo utente per ID.
// Dimostra il pattern UseCase con dependency injection init-based
// su un protocollo di Repository.

import Foundation

/// Protocollo per facilitare il mock nei test unitari.
public protocol FetchUserUseCaseProtocol: Sendable {
    func execute(userID: Int) async throws -> User
}

/// UseCase che recupera un utente specifico.
public struct FetchUserUseCase: FetchUserUseCaseProtocol {

    // MARK: - Dipendenze

    private let repository: any UserRepository

    // MARK: - Init

    public init(repository: any UserRepository) {
        self.repository = repository
    }

    // MARK: - Esecuzione

    public func execute(userID: Int) async throws -> User {
        try await repository.fetchUser(id: userID)
    }
}

// MARK: - UseCase: Fetch All Users

/// UseCase per il recupero di tutti gli utenti.
/// Esempio di come si possono avere più UseCase per lo stesso repository,
/// ognuno con una responsabilità singola (Single Responsibility Principle).
public protocol FetchUsersUseCaseProtocol: Sendable {
    func execute() async throws -> [User]
}

public struct FetchUsersUseCase: FetchUsersUseCaseProtocol {
    private let repository: any UserRepository

    public init(repository: any UserRepository) {
        self.repository = repository
    }

    public func execute() async throws -> [User] {
        try await repository.fetchUsers()
    }
}
