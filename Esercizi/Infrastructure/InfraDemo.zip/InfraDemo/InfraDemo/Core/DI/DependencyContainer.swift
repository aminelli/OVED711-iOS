// DependencyContainer.swift
// InfraDemo
//
// Dependency Container: registro centralizzato per la Dependency Injection.
// Questo file implementa tre tecniche di DI:
//   1. Init-based DI      — le dipendenze vengono passate al costruttore (già visto nei UseCase)
//   2. DependencyContainer — un registro globale (service locator) che funge da "root of DI"
//   3. EnvironmentKey     — integrazione con SwiftUI Environment (vedere EnvironmentKeys.swift)
//
// Il DependencyContainer è il "Composition Root": l'unico posto in cui
// vengono collegati i protocolli alle loro implementazioni concrete.
// Tutto il resto del codice dipende SOLO dai protocolli.

import Foundation
import SwiftUI
import Combine

// MARK: - DependencyContainer

/// Registro di tutte le dipendenze dell'applicazione.
/// Creato una volta sola nell'`@main` App, poi distribuito tramite SwiftUI Environment.
@MainActor
public final class DependencyContainer: ObservableObject {

    // MARK: - Infrastruttura di rete

    /// Actor di rete condiviso.
    public let networkActor: NetworkActor

    /// Manager della cache.
    public let cacheManager: CacheManager

    /// Circuit breaker per l'API principale.
    public let circuitBreaker: CircuitBreaker

    /// Monitor della connettività.
    public let networkMonitor: NetworkMonitor

    // MARK: - Repository (interfacce del dominio)

    public let postRepository: any PostRepository
    public let userRepository: any UserRepository

    // MARK: - UseCase

    public let fetchPostsUseCase:  any FetchPostsUseCaseProtocol
    public let fetchUsersUseCase:  any FetchUsersUseCaseProtocol
    public let fetchUserUseCase:   any FetchUserUseCaseProtocol

    // MARK: - Logging / Monitoring

    public let breadcrumbTrail: BreadcrumbTrail

    // MARK: - Feature Flags

    public let featureFlags: FeatureFlagService

    // MARK: - Init (Composition Root)

    /// Assembla il grafo completo delle dipendenze.
    /// L'ordine di inizializzazione segue la Dependency Rule:
    /// infrastruttura → data → dominio → presentazione.
    public init() {
        // 1. Infrastruttura
        let cache         = CacheManager()
        let circuitBkr    = CircuitBreaker()
        let monitor       = NetworkMonitor()
        let breadcrumbs   = BreadcrumbTrail()
        let flags         = FeatureFlagService()

        // URLSession con cache HTTP abilitata
        let session       = CacheManager.makeCachedSession()
        let netActor      = NetworkActor(session: session)

        // 2. Repository (Data layer, implementazioni concrete)
        let postRepo      = PostRepositoryImpl(networkClient: netActor, cacheManager: cache)
        let userRepo      = UserRepositoryImpl(networkClient: netActor)

        // 3. UseCase (Domain layer)
        let fetchPosts    = FetchPostsUseCase(repository: postRepo)
        let fetchUsers    = FetchUsersUseCase(repository: userRepo)
        let fetchUser     = FetchUserUseCase(repository: userRepo)

        // 4. Assegnazione
        self.networkActor       = netActor
        self.cacheManager       = cache
        self.circuitBreaker     = circuitBkr
        self.networkMonitor     = monitor
        self.breadcrumbTrail    = breadcrumbs
        self.featureFlags       = flags
        self.postRepository     = postRepo
        self.userRepository     = userRepo
        self.fetchPostsUseCase  = fetchPosts
        self.fetchUsersUseCase  = fetchUsers
        self.fetchUserUseCase   = fetchUser

        // Avvia il monitoraggio della rete
        monitor.start()
    }
}
