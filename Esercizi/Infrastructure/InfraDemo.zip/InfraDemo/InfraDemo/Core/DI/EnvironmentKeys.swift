// EnvironmentKeys.swift
// InfraDemo
//
// EnvironmentKey personalizzati per SwiftUI.
// Permettono di iniettare dipendenze nell'albero di viste SwiftUI
// senza passarle esplicitamente a ogni vista (prop drilling).
// Tecnica ufficiale Apple per la DI in SwiftUI.
//
// Flusso:
//   1. Definire un `EnvironmentKey` con il valore di default
//   2. Estendere `EnvironmentValues` con la proprietà custom
//   3. Iniettare con `.environment(\.myKey, value)` nel genitore
//   4. Leggere con `@Environment(\.myKey)` nel figlio

import SwiftUI

// MARK: - DependencyContainer EnvironmentKey

private struct DependencyContainerKey: EnvironmentKey {
    /// Valore di default: non disponibile — lancia un fatal error per sicurezza
    /// se la vista viene usata senza configurare l'environment.
    @MainActor
    static let defaultValue: DependencyContainer = DependencyContainer()
}

public extension EnvironmentValues {
    /// Accesso al container DI dall'environment SwiftUI.
    var dependencies: DependencyContainer {
        get { self[DependencyContainerKey.self] }
        set { self[DependencyContainerKey.self] = newValue }
    }
}

// MARK: - FeatureFlagService EnvironmentKey

private struct FeatureFlagKey: EnvironmentKey {
    @MainActor
    static let defaultValue: FeatureFlagService = FeatureFlagService()
}

public extension EnvironmentValues {
    /// Accesso al servizio feature flag dall'environment SwiftUI.
    var featureFlags: FeatureFlagService {
        get { self[FeatureFlagKey.self] }
        set { self[FeatureFlagKey.self] = newValue }
    }
}

// MARK: - NetworkMonitor EnvironmentKey

private struct NetworkMonitorKey: EnvironmentKey {
    @MainActor
    static let defaultValue: NetworkMonitor = NetworkMonitor()
}

public extension EnvironmentValues {
    /// Stato della rete disponibile a tutte le viste.
    var networkMonitor: NetworkMonitor {
        get { self[NetworkMonitorKey.self] }
        set { self[NetworkMonitorKey.self] = newValue }
    }
}

// MARK: - Esempio di utilizzo

/*
 // Nel punto di ingresso (InfraDemoApp.swift):
 ContentView()
     .environment(\.dependencies, container)
     .environment(\.featureFlags, container.featureFlags)
     .environment(\.networkMonitor, container.networkMonitor)

 // In una vista qualsiasi:
 struct PostsView: View {
     @Environment(\.dependencies) private var deps
     @Environment(\.featureFlags) private var flags

     var body: some View { … }
 }
*/
