// CacheManager.swift
// InfraDemo
//
// Gestione della cache con due livelli:
//   1. NSCache  — cache in-memory, LRU automatico, invalidata dalla pressione di memoria
//   2. URLCache — cache HTTP su disco, rispetta gli header Cache-Control / ETag
//
// Differenze chiave:
//   - NSCache:  generico, non persistente, gestione automatica della memoria,
//               thread-safe, ideale per oggetti decodificati già pronti all'uso.
//   - URLCache: specifica per HTTP, persistente su disco, rispetta la semantica
//               HTTP caching (max-age, ETag, Last-Modified). Usata da URLSession
//               automaticamente se configurata nella URLSessionConfiguration.

import Foundation
import OSLog

// MARK: - CacheManager

/// Centralizza la configurazione e l'accesso ai due livelli di cache.
/// `Sendable` grazie al fatto che NSCache e URLCache sono thread-safe.
public final class CacheManager: @unchecked Sendable {

    // MARK: - Cache in-memory (NSCache)

    /// Cache in-memory per oggetti già decodificati (es. array di DTO).
    /// NSCache libera automaticamente gli oggetti sotto pressione di memoria
    /// (memory warning) senza richiedere codice custom.
    public let inMemory: NSCache<NSString, AnyObject> = {
        let cache = NSCache<NSString, AnyObject>()
        // Limite massimo di oggetti in cache
        cache.countLimit    = 100
        // Limite di memoria totale (50 MB)
        cache.totalCostLimit = 50 * 1024 * 1024
        cache.name           = "com.infrademo.InMemoryCache"
        return cache
    }()

    // MARK: - Cache HTTP (URLCache)

    /// Cache HTTP su disco usata da URLSession.
    /// Va configurata nella `URLSessionConfiguration` prima della creazione della sessione.
    /// - memoryCapacity: 20 MB in RAM
    /// - diskCapacity:   100 MB su disco
    public static let httpCache: URLCache = {
        let cache = URLCache(
            memoryCapacity: 20 * 1024 * 1024,
            diskCapacity:  100 * 1024 * 1024
        )
        return cache
    }()

    // MARK: - URLSession con caching HTTP attivo

    /// URLSession configurata per usare URLCache.
    /// URLSession rispetterà automaticamente gli header HTTP:
    /// Cache-Control, ETag, Last-Modified, Expires.
    public static func makeCachedSession() -> URLSession {
        let config = URLSessionConfiguration.default
        config.urlCache         = CacheManager.httpCache
        // Usa la cache se disponibile e non scaduta, altrimenti va in rete
        config.requestCachePolicy = .useProtocolCachePolicy
        return URLSession(configuration: config)
    }

    // MARK: - Invalidazione cache

    private let logger = Logger(subsystem: "com.infrademo", category: "CacheManager")

    /// Svuota entrambi i livelli di cache.
    public func clearAll() {
        inMemory.removeAllObjects()
        CacheManager.httpCache.removeAllCachedResponses()
        logger.info("Cache svuotata.")
    }

    /// Rimuove un oggetto specifico dalla cache in-memory.
    public func remove(key: String) {
        inMemory.removeObject(forKey: key as NSString)
    }

    public init() {}
}
