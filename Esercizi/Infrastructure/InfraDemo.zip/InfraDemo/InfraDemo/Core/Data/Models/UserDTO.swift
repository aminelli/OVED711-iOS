// UserDTO.swift
// InfraDemo
//
// Data Transfer Object per gli Utenti.
// Dimostra la struttura annidata con Codable e la mappatura verso il dominio.

import Foundation

// MARK: - UserDTO

/// Rappresentazione JSON di un utente (API jsonplaceholder).
///
/// NOTA Swift 6.3: `Codable` implementato esplicitamente con `nonisolated`
/// per evitare che la sintesi automatica erediti il default `@MainActor` isolation,
/// che causerebbe l'errore "Main actor-isolated conformance … cannot satisfy Sendable".
public struct UserDTO: Sendable, Identifiable {

    // MARK: - Proprietà top-level

    public let id:       Int
    public let name:     String
    public let username: String
    public let email:    String
    public let website:  String?

    // MARK: - Oggetti annidati

    public let address:  AddressDTO?
    public let company:  CompanyDTO?
    public let phone:    String?

    // MARK: - AddressDTO

    /// Indirizzo dell'utente: esempio di oggetto Codable annidato.
    public struct AddressDTO: Sendable {
        public let street:  String
        public let suite:   String?
        public let city:    String
        public let zipcode: String
        public let geo:     GeoDTO?

        /// Coordinate geografiche – ulteriore livello di nidificazione.
        public struct GeoDTO: Sendable {
            public let lat: String
            public let lng: String
        }
    }

    // MARK: - CompanyDTO

    public struct CompanyDTO: Sendable {
        public let name:        String
        public let catchPhrase: String?
        public let bs:          String?
    }

    // MARK: - Mappatura → Dominio

    /// Converte il DTO nell'entità `User` del dominio.
    public nonisolated func toDomain() -> User {
        let domainAddress = address.map { dto in
            User.Address(
                street:  dto.street,
                city:    dto.city,
                zipcode: dto.zipcode
            )
        }
        return User(
            id:       id,
            name:     name,
            username: username,
            email:    email,
            website:  website,
            address:  domainAddress
        )
    }
}

// MARK: - UserDTO: Codable (nonisolated)

extension UserDTO: Codable {
    private enum CodingKeys: String, CodingKey {
        case id, name, username, email, website, address, company, phone
    }

    public nonisolated init(from decoder: any Decoder) throws {
        let c   = try decoder.container(keyedBy: CodingKeys.self)
        id       = try  c.decode(Int.self,         forKey: .id)
        name     = try  c.decode(String.self,       forKey: .name)
        username = try  c.decode(String.self,       forKey: .username)
        email    = try  c.decode(String.self,       forKey: .email)
        website  = try  c.decodeIfPresent(String.self,     forKey: .website)
        address  = try  c.decodeIfPresent(AddressDTO.self, forKey: .address)
        company  = try  c.decodeIfPresent(CompanyDTO.self, forKey: .company)
        phone    = try  c.decodeIfPresent(String.self,     forKey: .phone)
    }

    public nonisolated func encode(to encoder: any Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(id,       forKey: .id)
        try c.encode(name,     forKey: .name)
        try c.encode(username, forKey: .username)
        try c.encode(email,    forKey: .email)
        try c.encodeIfPresent(website, forKey: .website)
        try c.encodeIfPresent(address, forKey: .address)
        try c.encodeIfPresent(company, forKey: .company)
        try c.encodeIfPresent(phone,   forKey: .phone)
    }
}

// MARK: - AddressDTO: Codable (nonisolated)

extension UserDTO.AddressDTO: Codable {
    private enum CodingKeys: String, CodingKey { case street, suite, city, zipcode, geo }

    public nonisolated init(from decoder: any Decoder) throws {
        let c    = try decoder.container(keyedBy: CodingKeys.self)
        street   = try  c.decode(String.self,   forKey: .street)
        suite    = try  c.decodeIfPresent(String.self, forKey: .suite)
        city     = try  c.decode(String.self,   forKey: .city)
        zipcode  = try  c.decode(String.self,   forKey: .zipcode)
        geo      = try  c.decodeIfPresent(GeoDTO.self, forKey: .geo)
    }

    public nonisolated func encode(to encoder: any Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(street,  forKey: .street)
        try c.encodeIfPresent(suite,   forKey: .suite)
        try c.encode(city,    forKey: .city)
        try c.encode(zipcode, forKey: .zipcode)
        try c.encodeIfPresent(geo,     forKey: .geo)
    }
}

// MARK: - GeoDTO: Codable (nonisolated)

extension UserDTO.AddressDTO.GeoDTO: Codable {
    private enum CodingKeys: String, CodingKey { case lat, lng }

    public nonisolated init(from decoder: any Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        lat   = try c.decode(String.self, forKey: .lat)
        lng   = try c.decode(String.self, forKey: .lng)
    }

    public nonisolated func encode(to encoder: any Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(lat, forKey: .lat)
        try c.encode(lng, forKey: .lng)
    }
}

// MARK: - CompanyDTO: Codable (nonisolated)

extension UserDTO.CompanyDTO: Codable {
    private enum CodingKeys: String, CodingKey { case name, catchPhrase, bs }

    public nonisolated init(from decoder: any Decoder) throws {
        let c        = try decoder.container(keyedBy: CodingKeys.self)
        name         = try  c.decode(String.self,   forKey: .name)
        catchPhrase  = try  c.decodeIfPresent(String.self, forKey: .catchPhrase)
        bs           = try  c.decodeIfPresent(String.self, forKey: .bs)
    }

    public nonisolated func encode(to encoder: any Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(name, forKey: .name)
        try c.encodeIfPresent(catchPhrase, forKey: .catchPhrase)
        try c.encodeIfPresent(bs,          forKey: .bs)
    }
}
