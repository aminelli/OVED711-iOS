// PostDTO.swift
// InfraDemo
//
// Data Transfer Object per i Post.
// I DTO (Data Transfer Object) vivono nel layer Data e si occupano
// di serializzazione/deserializzazione JSON. NON devono trapelare
// nel layer Domain: la mappatura avviene nel Repository.

import Foundation

// MARK: - PostDTO

/// Rappresentazione JSON di un post come restituito dall'API.
/// `Codable` per (de)serializzazione, `Sendable` per Swift 6.
///
/// NOTA Swift 6.3 / Xcode 26: con `@MainActor` come default isolation del modulo,
/// la sintesi automatica di `Codable` eredita l'isolamento `@MainActor`, rendendo
/// `init(from:)` incompatibile con parametri generici `Sendable`.
/// Soluzione: implementazione esplicita con `nonisolated` su `init(from:)` e `encode(to:)`.
public struct PostDTO: Sendable, Identifiable {
    public let id:     Int
    public let userId: Int
    public let title:  String
    public let body:   String

    // MARK: - Init standard

    public init(id: Int, userId: Int, title: String, body: String) {
        self.id     = id
        self.userId = userId
        self.title  = title
        self.body   = body
    }

    // MARK: - Mappatura → Dominio

    /// Converte il DTO nell'entità di dominio.
    /// La mappatura è responsabilità del layer Data (repository).
    public nonisolated func toDomain() -> Post {
        Post(id: id, userID: userId, title: title, body: body)
    }
}

// MARK: - Codable (nonisolated — Swift 6.3 default-actor-isolation workaround)

extension PostDTO: Codable {

    private enum CodingKeys: String, CodingKey {
        case id, userId, title, body
    }

    /// `nonisolated` garantisce che `init(from:)` sia utilizzabile da qualsiasi
    /// contesto di concorrenza, risolvendo l'errore
    /// "Main actor-isolated conformance … cannot satisfy Sendable type parameter".
    public nonisolated init(from decoder: any Decoder) throws {
        let c  = try decoder.container(keyedBy: CodingKeys.self)
        id     = try c.decode(Int.self,    forKey: .id)
        userId = try c.decode(Int.self,    forKey: .userId)
        title  = try c.decode(String.self, forKey: .title)
        body   = try c.decode(String.self, forKey: .body)
    }

    public nonisolated func encode(to encoder: any Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(id,     forKey: .id)
        try c.encode(userId, forKey: .userId)
        try c.encode(title,  forKey: .title)
        try c.encode(body,   forKey: .body)
    }
}

// MARK: - PaginatedPostsDTO

/// Risposta paginata con cursore. Dimostra il pattern cursor-based pagination.
/// L'API reale potrebbe restituire un campo `nextCursor` nel JSON;
/// qui lo simuliamo con la struttura wrapper.
public struct PaginatedPostsDTO: Sendable {

    /// Lista di post della pagina corrente.
    public let data: [PostDTO]

    /// Cursore per la pagina successiva (nil se siamo all'ultima pagina).
    /// Il cursore è opaco per il client: può essere un offset, un timestamp,
    /// o un token cifrato – il client lo passa invariato alla prossima richiesta.
    public let nextCursor: String?

    /// Totale di post disponibili (utile per progress indicator).
    public let total: Int?
}

extension PaginatedPostsDTO: Codable {
    private enum CodingKeys: String, CodingKey { case data, nextCursor, total }
    public nonisolated init(from decoder: any Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        data       = try c.decode([PostDTO].self, forKey: .data)
        nextCursor = try c.decodeIfPresent(String.self, forKey: .nextCursor)
        total      = try c.decodeIfPresent(Int.self,    forKey: .total)
    }
    public nonisolated func encode(to encoder: any Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(data,       forKey: .data)
        try c.encodeIfPresent(nextCursor, forKey: .nextCursor)
        try c.encodeIfPresent(total,      forKey: .total)
    }
}

// MARK: - Codable Union Type (tipo polimorfico)

/// Esempio avanzato di Codable con "union type" (tipo discriminato).
/// L'API restituisce un campo `type` che discrimina tra PostDTO e ArticleDTO.
/// Questa tecnica è utile per API che restituiscono tipi diversi nella stessa lista.

public enum FeedItemDTO: Sendable {
    case post(PostDTO)
    case article(ArticleDTO)
}

// MARK: - FeedItemDTO: Codable (nonisolated)
// Extension separata: permette di marcare init(from:) e encode(to:) come nonisolated
// — workaround per il default @MainActor isolation di Swift 6.3.
extension FeedItemDTO: Codable {

    private enum CodingKeys: String, CodingKey { case type }

    public nonisolated init(from decoder: any Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let type_ = try container.decode(String.self, forKey: .type)

        // Decodifica l'intero oggetto con un decoder "singolo valore"
        let singleContainer = try decoder.singleValueContainer()

        switch type_ {
        case "post":
            self = .post(try singleContainer.decode(PostDTO.self))
        case "article":
            self = .article(try singleContainer.decode(ArticleDTO.self))
        default:
            // Gestione robusta di tipi sconosciuti: non crashare
            throw DecodingError.dataCorruptedError(
                in: singleContainer,
                debugDescription: "Tipo feed sconosciuto: \(type_)"
            )
        }
    }

    public nonisolated func encode(to encoder: any Encoder) throws {
        switch self {
        case .post(let dto):
            try dto.encode(to: encoder)
        case .article(let dto):
            try dto.encode(to: encoder)
        }
    }
}

// MARK: - ArticleDTO (usato nel union type)

public struct ArticleDTO: Sendable, Identifiable {
    public let id:      Int
    public let type:    String   // "article"
    public let title:   String
    public let content: String
    public let author:  String
}

extension ArticleDTO: Codable {
    private enum CodingKeys: String, CodingKey { case id, type, title, content, author }
    public nonisolated init(from decoder: any Decoder) throws {
        let c   = try decoder.container(keyedBy: CodingKeys.self)
        id      = try c.decode(Int.self,    forKey: .id)
        type    = try c.decode(String.self, forKey: .type)
        title   = try c.decode(String.self, forKey: .title)
        content = try c.decode(String.self, forKey: .content)
        author  = try c.decode(String.self, forKey: .author)
    }
    public nonisolated func encode(to encoder: any Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(id,      forKey: .id)
        try c.encode(type,    forKey: .type)
        try c.encode(title,   forKey: .title)
        try c.encode(content, forKey: .content)
        try c.encode(author,  forKey: .author)
    }
}
