// TokenRefreshActor.swift
// InfraDemo
//
// Actor dedicato al refresh del token di autenticazione.
// Usando un `actor` si elimina la necessità di lock manuali (mutex, semafori):
// Swift garantisce che un solo task alla volta acceda allo stato interno.
// Implementa il pattern "coalescing refresh": se più richieste chiedono
// il refresh contemporaneamente, viene eseguita UNA SOLA chiamata di rete.

import Foundation
import OSLog

// MARK: - TokenRefreshActor

/// Gestisce il ciclo di vita del token Bearer.
/// - `currentToken`: token corrente (nil se non autenticato).
/// - `refresh()`: aggiorna il token con coalescing (evita refresh paralleli).
public actor TokenRefreshActor {

    // MARK: - Stato interno dell'actor

    /// Token corrente; isolato nell'actor, nessun data race possibile.
    private(set) var currentToken: String?

    /// Task di refresh in corso, se presente.
    /// Il coalescing si ottiene condividendo lo stesso Task tra più chiamate.
    private var refreshTask: Task<String, Error>?

    private let logger = Logger(subsystem: "com.infrademo", category: "TokenRefresh")

    // MARK: - Init

    public init(initialToken: String? = nil) {
        self.currentToken = initialToken
    }

    // MARK: - Refresh con coalescing

    /// Esegue il refresh del token. Se un refresh è già in corso,
    /// restituisce lo stesso Task esistente (coalescing) invece di avviarne uno nuovo.
    /// Questo evita il classico "thundering herd" problem con i token scaduti.
    public func refresh() async throws {
        // Se c'è già un refresh in volo, aspetta il suo risultato
        if let existing = refreshTask {
            logger.debug("Refresh già in corso, aspetto il risultato…")
            currentToken = try await existing.value
            return
        }

        // Avvia un nuovo refresh
        let task = Task<String, Error> {
            // In produzione: chiamata reale al server di autenticazione
            // Qui simuliamo un ritardo di rete
            try await Task.sleep(for: .milliseconds(300))
            return "refreshed-token-\(Int.random(in: 1000...9999))"
        }

        refreshTask = task

        do {
            let newToken = try await task.value
            currentToken = newToken
            refreshTask  = nil  // Reset: il prossimo refresh parte da zero
            logger.info("Token refreshed con successo.")
        } catch {
            refreshTask = nil
            logger.error("Refresh token fallito: \(error)")
            throw error
        }
    }

    /// Imposta manualmente il token (es. dopo il login).
    public func setToken(_ token: String) {
        currentToken = token
        logger.info("Token impostato manualmente.")
    }

    /// Invalida il token corrente (es. al logout).
    public func clearToken() {
        currentToken = nil
        logger.info("Token rimosso.")
    }
}
