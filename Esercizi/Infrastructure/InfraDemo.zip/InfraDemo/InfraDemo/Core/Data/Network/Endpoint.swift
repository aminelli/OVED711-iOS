// Endpoint.swift
// InfraDemo
//
// Protocollo Endpoint: astrazione per la costruzione delle richieste HTTP.
// Ogni endpoint è un tipo che descrive URL, metodo, headers e body
// senza conoscere nulla di URLSession. Ispirato al pattern "type-safe API client".

import Foundation

// MARK: - HTTPMethod

/// Metodi HTTP supportati, tipizzati come enum per evitare errori di stringa.
public enum HTTPMethod: String, Sendable {
    case get    = "GET"
    case post   = "POST"
    case put    = "PUT"
    case patch  = "PATCH"
    case delete = "DELETE"
}

// MARK: - Endpoint Protocol

/// Ogni endpoint dell'applicazione deve conformarsi a questo protocollo.
/// Fornisce un'astrazione type-safe e testabile per la costruzione di URLRequest.
public protocol Endpoint: Sendable {
    /// Schema (https/http).
    var scheme: String { get }
    /// Host del server (es. "jsonplaceholder.typicode.com").
    var host: String { get }
    /// Percorso della risorsa (es. "/posts").
    var path: String { get }
    /// Metodo HTTP.
    var method: HTTPMethod { get }
    /// Query parameters opzionali.
    var queryItems: [URLQueryItem]? { get }
    /// Headers HTTP aggiuntivi (es. Authorization, Accept).
    var headers: [String: String]? { get }
    /// Body della richiesta serializzato in JSON.
    var body: Data? { get }
}

// MARK: - Endpoint → URLRequest

public extension Endpoint {

    /// Costruisce un `URLRequest` a partire dalla descrizione dell'endpoint.
    /// Lancia `URLError(.badURL)` se la costruzione dell'URL fallisce.
    func asURLRequest() throws -> URLRequest {
        var components = URLComponents()
        components.scheme     = scheme
        components.host       = host
        components.path       = path
        components.queryItems = queryItems

        guard let url = components.url else {
            throw URLError(.badURL)
        }

        var request        = URLRequest(url: url)
        request.httpMethod = method.rawValue
        request.httpBody   = body

        // Header di default
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        // Header personalizzati dell'endpoint
        headers?.forEach { request.setValue($1, forHTTPHeaderField: $0) }

        return request
    }

    // Valori di default condivisi tra tutti gli endpoint
    var scheme: String      { "https" }
    var host: String        { "jsonplaceholder.typicode.com" }
    var queryItems: [URLQueryItem]? { nil }
    var headers: [String: String]?  { nil }
    var body: Data?                 { nil }
}

// MARK: - PostsEndpoint

/// Definisce tutti gli endpoint relativi ai post.
/// Usando un enum si ottiene l'esaustività a compile-time.
public enum PostsEndpoint: Endpoint {
    case list(page: Int, limit: Int)
    case detail(id: Int)
    case byUser(userID: Int)

    public var path: String {
        switch self {
        case .list:            return "/posts"
        case .detail(let id): return "/posts/\(id)"
        case .byUser:          return "/posts"
        }
    }

    public var method: HTTPMethod { .get }

    public var queryItems: [URLQueryItem]? {
        switch self {
        case .list(let page, let limit):
            // Paginazione offset-based convertita in cursor-based lato client per il demo
            return [
                URLQueryItem(name: "_page",  value: "\(page)"),
                URLQueryItem(name: "_limit", value: "\(limit)")
            ]
        case .byUser(let userID):
            return [URLQueryItem(name: "userId", value: "\(userID)")]
        case .detail:
            return nil
        }
    }
}

// MARK: - UsersEndpoint

/// Definisce tutti gli endpoint relativi agli utenti.
public enum UsersEndpoint: Endpoint {
    case list
    case detail(id: Int)

    public var path: String {
        switch self {
        case .list:            return "/users"
        case .detail(let id): return "/users/\(id)"
        }
    }

    public var method: HTTPMethod { .get }
}
