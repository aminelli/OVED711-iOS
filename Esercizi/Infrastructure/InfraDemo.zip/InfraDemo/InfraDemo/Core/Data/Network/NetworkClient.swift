// NetworkClient.swift
// InfraDemo
//
// Client di rete basato su actor (NetworkActor) per garantire la sicurezza
// della concorrenza in Swift 6 (strict concurrency).
// Dimostra:
//   - URLSession async/await (data, download, bytes)
//   - AsyncSequence per streaming
//   - Cancellazione con Task
//   - async let vs TaskGroup
//   - Retry tramite RetryPolicy
//   - Token refresh con TokenRefreshActor
//   - Sendable e strict concurrency

import Foundation
import OSLog

// MARK: - NetworkError

/// Errori di rete tipizzati, conformi a `Sendable` per l'uso tra actor.
public enum NetworkError: Error, Sendable, LocalizedError {
    case invalidURL
    case invalidResponse(statusCode: Int)
    case decodingFailed(Error)
    case unauthorized
    case noConnection
    case cancelled
    case unknown(Error)

    public var errorDescription: String? {
        switch self {
        case .invalidURL:                   return "URL non valido."
        case .invalidResponse(let code):    return "Risposta HTTP non valida: \(code)."
        case .decodingFailed(let err):      return "Decodifica fallita: \(err.localizedDescription)"
        case .unauthorized:                 return "Non autorizzato. Effettua il login."
        case .noConnection:                 return "Nessuna connessione di rete."
        case .cancelled:                    return "Richiesta annullata."
        case .unknown(let err):             return "Errore sconosciuto: \(err.localizedDescription)"
        }
    }
}

// MARK: - HTTPClientProtocol

/// Protocollo del client HTTP per facilitare il mock nei test.
public protocol HTTPClientProtocol: Sendable {
    func perform<T: Decodable & Sendable>(
        _ endpoint: some Endpoint,
        as type: T.Type
    ) async throws -> T

    func download(_ endpoint: some Endpoint) async throws -> URL

    func stream(_ endpoint: some Endpoint) -> AsyncThrowingStream<String, Error>
}

// MARK: - NetworkActor

/// Actor che gestisce tutte le operazioni di rete.
/// Usando un `actor` invece di una `class` con lock manuale, Swift 6 garantisce
/// l'accesso esclusivo allo stato interno senza data race.
public actor NetworkActor: HTTPClientProtocol {

    // MARK: - Proprietà private dell'actor

    /// Sessione URLSession configurata con caching HTTP.
    private let session: URLSession

    /// Decoder JSON condiviso.
    private let decoder: JSONDecoder

    /// Policy di retry con backoff esponenziale.
    private let retryPolicy: RetryPolicy

    /// Actor per il refresh del token di autenticazione.
    private let tokenActor: TokenRefreshActor

    /// Logger dedicato alla rete.
    private let logger = Logger(subsystem: "com.infrademo", category: "NetworkActor")

    // MARK: - Init

    public init(
        session: URLSession = .shared,
        retryPolicy: RetryPolicy = RetryPolicy(),
        tokenActor: TokenRefreshActor = TokenRefreshActor()
    ) {
        self.session     = session
        self.retryPolicy = retryPolicy
        self.tokenActor  = tokenActor

        // Configurazione del decoder JSON con snake_case → camelCase automatico
        let dec = JSONDecoder()
        dec.keyDecodingStrategy  = .convertFromSnakeCase
        dec.dateDecodingStrategy = .iso8601
        self.decoder = dec
    }

    // MARK: - perform<T> — data(for:) con retry e token refresh

    /// Esegue una richiesta HTTP, decodifica il JSON e gestisce retry + refresh token.
    /// Dimostra:
    ///   - `URLSession.data(for:)` async/await
    ///   - Retry con backoff esponenziale (via `RetryPolicy`)
    ///   - Refresh automatico del token in caso di 401
    public func perform<T: Decodable & Sendable>(
        _ endpoint: some Endpoint,
        as type: T.Type = T.self
    ) async throws -> T {

        // Costruisce la URLRequest dall'endpoint type-safe
        var request = try endpoint.asURLRequest()

        // Inietta il token di autenticazione (se presente)
        if let token = await tokenActor.currentToken {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }

        logger.debug("→ \(request.httpMethod ?? "?") \(request.url?.absoluteString ?? "")")

        // Esecuzione con retry
        return try await retryPolicy.execute {
            let (data, response) = try await self.session.data(for: request)

            guard let http = response as? HTTPURLResponse else {
                throw NetworkError.invalidResponse(statusCode: 0)
            }

            self.logger.debug("← HTTP \(http.statusCode)")

            switch http.statusCode {
            case 200...299:
                // Decodifica JSON
                do {
                    return try self.decoder.decode(T.self, from: data)
                } catch {
                    self.logger.error("Decodifica fallita: \(error)")
                    throw NetworkError.decodingFailed(error)
                }

            case 401:
                // Token scaduto: tenta il refresh e rilancia per il retry
                self.logger.warning("Token scaduto, avvio refresh…")
                try await self.tokenActor.refresh()
                throw NetworkError.unauthorized

            default:
                throw NetworkError.invalidResponse(statusCode: http.statusCode)
            }
        }
    }

    // MARK: - download(for:) — scarica un file

    /// Scarica un file sul disco usando `URLSession.download(for:)`.
    /// Utile per risorse pesanti (immagini, PDF, ecc.).
    public func download(_ endpoint: some Endpoint) async throws -> URL {
        let request = try endpoint.asURLRequest()
        logger.debug("Download: \(request.url?.absoluteString ?? "")")

        let (localURL, response) = try await session.download(for: request)

        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            throw NetworkError.invalidResponse(statusCode: 0)
        }
        return localURL
    }

    // MARK: - stream — AsyncSequence per streaming linea per linea

    /// Restituisce un `AsyncThrowingStream<String, Error>` che emette
    /// le righe di testo man mano che arrivano dal server (Server-Sent Events / NDJSON).
    /// Dimostra `URLSession.bytes(for:)` e `AsyncSequence`.
    public nonisolated func stream(_ endpoint: some Endpoint) -> AsyncThrowingStream<String, Error> {
        AsyncThrowingStream { continuation in
            // Crea un Task cancellabile che legge lo stream riga per riga
            let task = Task {
                do {
                    let request = try endpoint.asURLRequest()
                    // bytes(for:) restituisce un AsyncSequence di byte
                    let (bytes, _) = try await self.session.bytes(for: request)

                    // Itera sulle righe di testo in modo asincrono
                    for try await line in bytes.lines {
                        // Verifica la cancellazione ad ogni iterazione
                        try Task.checkCancellation()
                        continuation.yield(line)
                    }
                    continuation.finish()
                } catch is CancellationError {
                    continuation.finish(throwing: NetworkError.cancelled)
                } catch {
                    continuation.finish(throwing: error)
                }
            }

            // Quando il consumer annulla lo stream, annulla anche il Task
            continuation.onTermination = { _ in task.cancel() }
        }
    }

    // MARK: - Fetch parallelo con async let

    /// Esempio di concorrenza strutturata con `async let`:
    /// carica post e utente in parallelo, attendendo entrambi.
    public func fetchPostAndUser(
        postEndpoint: some Endpoint,
        userEndpoint: some Endpoint
    ) async throws -> (PostDTO, UserDTO) {
        // async let avvia immediatamente entrambe le chiamate in parallelo
        async let postResult: PostDTO = perform(postEndpoint, as: PostDTO.self)
        async let userResult: UserDTO = perform(userEndpoint, as: UserDTO.self)

        // await unificato: attende entrambe e lancia se una fallisce
        return try await (postResult, userResult)
    }

    // MARK: - Fetch multiplo con TaskGroup

    /// Esempio di `TaskGroup` per caricare N risorse in parallelo
    /// con controllo granulare su ogni task (utile quando N è variabile).
    public func fetchMultiplePosts(ids: [Int]) async throws -> [PostDTO] {
        try await withThrowingTaskGroup(of: PostDTO.self) { group in
            for id in ids {
                group.addTask {
                    // Ogni task scarica un post in modo indipendente
                    try await self.perform(PostsEndpoint.detail(id: id), as: PostDTO.self)
                }
            }
            // Raccoglie i risultati nell'ordine di completamento
            var results: [PostDTO] = []
            for try await post in group {
                results.append(post)
            }
            return results
        }
    }
}
