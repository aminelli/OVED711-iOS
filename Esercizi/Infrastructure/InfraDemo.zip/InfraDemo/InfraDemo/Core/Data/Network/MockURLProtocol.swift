// MockURLProtocol.swift
// InfraDemo
//
// URLProtocol personalizzato per intercettare le richieste HTTP durante i test
// (e per il demo di rete offline).
// `URLProtocol` è il punto di estensione ufficiale di Apple per customizzare
// il comportamento di URLSession: qualsiasi richiesta passa prima dai protocolli registrati.

import Foundation

// MARK: - MockURLProtocol

/// Un `URLProtocol` che intercetta le richieste e restituisce risposte predefinite.
/// Utilizzo nei test:
///   ```swift
///   let config = URLSessionConfiguration.ephemeral
///   config.protocolClasses = [MockURLProtocol.self]
///   let session = URLSession(configuration: config)
///   ```
public final class MockURLProtocol: URLProtocol, @unchecked Sendable {

    // MARK: - Registro delle risposte mock

    /// Dizionario URL → handler che restituisce (Data?, URLResponse?, Error?).
    /// `nonisolated(unsafe)` perché accediamo da contesti non-isolated; in produzione
    /// usare un actor dedicato. Il `@unchecked Sendable` è giustificato dal fatto
    /// che la modifica avviene solo in fase di setup del test (single-threaded).
    nonisolated(unsafe) public static var requestHandlers:
        [URL: @Sendable (URLRequest) throws -> (Data, HTTPURLResponse)] = [:]

    // MARK: - URLProtocol overrides

    /// Indica se questo protocollo gestisce la richiesta data.
    /// Restituisce `true` per tutte le richieste registrate nel dizionario.
    override public class func canInit(with request: URLRequest) -> Bool {
        guard let url = request.url else { return false }
        return requestHandlers[url] != nil
    }

    /// Restituisce la richiesta canonica (invariata in questo caso).
    override public class func canonicalRequest(for request: URLRequest) -> URLRequest {
        request
    }

    /// Avvia il caricamento della richiesta simulata.
    override public func startLoading() {
        guard let url = request.url,
              let handler = MockURLProtocol.requestHandlers[url] else {
            client?.urlProtocol(self, didFailWithError: URLError(.fileDoesNotExist))
            return
        }

        do {
            let (data, response) = try handler(request)
            // Notifica il client (URLSession) con la risposta simulata
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: data)
            client?.urlProtocolDidFinishLoading(self)
        } catch {
            client?.urlProtocol(self, didFailWithError: error)
        }
    }

    /// Ferma il caricamento (nessuna operazione asincrona da cancellare).
    override public func stopLoading() {}
}

// MARK: - Helper per la creazione di risposte mock

public extension MockURLProtocol {

    /// Registra una risposta JSON per un endpoint dato.
    static func register<T: Encodable>(
        endpoint: some Endpoint,
        statusCode: Int = 200,
        response: T
    ) throws {
        let request = try endpoint.asURLRequest()
        guard let url = request.url else { return }

        requestHandlers[url] = { _ in
            let data = try JSONEncoder().encode(response)
            let httpResponse = HTTPURLResponse(
                url: url,
                statusCode: statusCode,
                httpVersion: "HTTP/1.1",
                headerFields: ["Content-Type": "application/json"]
            )!
            return (data, httpResponse)
        }
    }

    /// Rimuove tutti gli handler registrati (da chiamare in `tearDown`).
    static func reset() {
        requestHandlers.removeAll()
    }
}
