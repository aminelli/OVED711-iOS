// UserRepositoryImpl.swift
// InfraDemo
//
// Implementazione concreta del UserRepository.

import Foundation
import OSLog

public struct UserRepositoryImpl: UserRepository {

    // MARK: - Dipendenze

    private let networkClient: NetworkActor
    private let logger = Logger(subsystem: "com.infrademo", category: "UserRepository")

    // MARK: - Init

    public init(networkClient: NetworkActor) {
        self.networkClient = networkClient
    }

    // MARK: - UserRepository

    public func fetchUsers() async throws -> [User] {
        logger.debug("Fetch tutti gli utenti")
        let dtos: [UserDTO] = try await networkClient.perform(
            UsersEndpoint.list,
            as: [UserDTO].self
        )
        return dtos.map { $0.toDomain() }
    }

    public func fetchUser(id: Int) async throws -> User {
        logger.debug("Fetch utente id=\(id)")
        let dto: UserDTO = try await networkClient.perform(
            UsersEndpoint.detail(id: id),
            as: UserDTO.self
        )
        return dto.toDomain()
    }
}
