// PostRepositoryImpl.swift
// InfraDemo
//
// Implementazione concreta del PostRepository.
// Vive nel layer Data e:
//   - Usa NetworkActor per le chiamate HTTP
//   - Usa CacheManager per la cache
//   - Mappa i DTO nelle entità di dominio
//   - Implementa la paginazione cursor-based
// Non viene mai referenziata direttamente dal dominio:
// il binding avviene nel DependencyContainer (DI).

import Foundation
import OSLog

// MARK: - PostRepositoryImpl

/// Implementazione REST di `PostRepository`.
/// Conforme a `Sendable` grazie al fatto che tutte le dipendenze lo sono.
public struct PostRepositoryImpl: PostRepository {

    // MARK: - Dipendenze (init-based DI)

    private let networkClient: NetworkActor
    private let cacheManager:  CacheManager
    private let logger = Logger(subsystem: "com.infrademo", category: "PostRepository")

    // MARK: - Configurazione paginazione

    /// Numero di post per pagina.
    private let pageSize = 10

    // MARK: - Init

    public init(networkClient: NetworkActor, cacheManager: CacheManager) {
        self.networkClient = networkClient
        self.cacheManager  = cacheManager
    }

    // MARK: - PostRepository

    /// Recupera una pagina di post. Il cursore è codificato come "page=N" in base64
    /// per simulare un cursore opaco (in produzione sarebbe un token del server).
    public func fetchPosts(cursor: String?) async throws -> (posts: [Post], nextCursor: String?) {
        // Decodifica il numero di pagina dal cursore (o 1 se è la prima pagina)
        let page = decodeCursor(cursor) ?? 1
        logger.debug("Fetch posts pagina \(page)")

        // Chiave di cache: "posts_page_N"
        let cacheKey = "posts_page_\(page)" as NSString

        // Prova prima la cache NSCache (in-memory)
        if let cached: [PostDTO] = cacheManager.inMemory.object(forKey: cacheKey) as? [PostDTO] {
            logger.debug("Cache HIT per pagina \(page)")
            let posts = cached.map { $0.toDomain() }
            let next  = encodeCursor(page + 1, totalPages: 10)
            return (posts, next)
        }

        // Cache MISS: chiama l'API
        let endpoint = PostsEndpoint.list(page: page, limit: pageSize)
        let dtos: [PostDTO] = try await networkClient.perform(endpoint, as: [PostDTO].self)

        // Salva in cache NSCache
        cacheManager.inMemory.setObject(dtos as AnyObject, forKey: cacheKey)
        logger.debug("Salvati \(dtos.count) post in cache per pagina \(page)")

        let posts      = dtos.map { $0.toDomain() }
        let nextCursor = dtos.count == pageSize ? encodeCursor(page + 1, totalPages: 10) : nil

        return (posts, nextCursor)
    }

    /// Recupera un singolo post.
    public func fetchPost(id: Int) async throws -> Post {
        let endpoint = PostsEndpoint.detail(id: id)
        let dto: PostDTO = try await networkClient.perform(endpoint, as: PostDTO.self)
        return dto.toDomain()
    }

    /// Recupera i post di un utente.
    public func fetchPosts(forUserID userID: Int) async throws -> [Post] {
        let endpoint = PostsEndpoint.byUser(userID: userID)
        let dtos: [PostDTO] = try await networkClient.perform(endpoint, as: [PostDTO].self)
        return dtos.map { $0.toDomain() }
    }

    // MARK: - Cursor Helpers

    /// Codifica un numero di pagina in un cursore opaco Base64.
    private func encodeCursor(_ page: Int, totalPages: Int) -> String? {
        guard page <= totalPages else { return nil }
        let raw = "page=\(page)"
        return Data(raw.utf8).base64EncodedString()
    }

    /// Decodifica un cursore Base64 estraendo il numero di pagina.
    private func decodeCursor(_ cursor: String?) -> Int? {
        guard let cursor,
              let data   = Data(base64Encoded: cursor),
              let raw    = String(data: data, encoding: .utf8),
              raw.hasPrefix("page="),
              let pageStr = raw.split(separator: "=").last,
              let page    = Int(pageStr) else { return nil }
        return page
    }
}
