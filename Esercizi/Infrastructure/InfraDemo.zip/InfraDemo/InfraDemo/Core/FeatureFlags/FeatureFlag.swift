// FeatureFlag.swift
// InfraDemo
//
// Sistema di Feature Flag per modulo.
// I feature flag permettono di:
//   - Abilitare/disabilitare funzionalità a runtime (A/B test, rollout graduale)
//   - Separare il deploy dal release (trunk-based development)
//   - Personalizzare il comportamento per tenant/utente
//
// In questo demo i flag sono locali (UserDefaults); in produzione
// si integrerebbe con un servizio remoto (es. Firebase Remote Config,
// LaunchDarkly, Unleash).

import Foundation
import OSLog
import SwiftUI
import Combine

// MARK: - FeatureFlag

/// Enumerazione di tutti i feature flag dell'applicazione.
/// Ogni flag ha:
///   - un `key` univoco (usato in UserDefaults)
///   - un `defaultValue` per i nuovi utenti o in assenza di configurazione remota
///   - una `description` per la documentazione
public enum FeatureFlag: String, CaseIterable, Sendable {

    /// Abilita la nuova schermata "Streaming" con AsyncSequence.
    case streamingEnabled   = "feature.streaming_enabled"

    /// Abilita la paginazione cursor-based (disabilitato = paginazione offset classica).
    case cursorPagination   = "feature.cursor_pagination"

    /// Mostra il banner di stato della rete.
    case networkStatusBanner = "feature.network_status_banner"

    /// Abilita i log di debug nella UI (solo per sviluppatori).
    case debugLogsVisible   = "feature.debug_logs_visible"

    /// Abilita il Circuit Breaker (disabilitato = fail fast senza protezione).
    case circuitBreakerEnabled = "feature.circuit_breaker"

    // MARK: - Metadati del flag

    public var defaultValue: Bool {
        switch self {
        case .streamingEnabled:     return true
        case .cursorPagination:     return true
        case .networkStatusBanner:  return true
        case .debugLogsVisible:     return false  // Off per default in produzione
        case .circuitBreakerEnabled: return true
        }
    }

    public var description: String {
        switch self {
        case .streamingEnabled:      return "Abilita lo streaming AsyncSequence"
        case .cursorPagination:      return "Paginazione cursor-based"
        case .networkStatusBanner:   return "Banner stato rete in UI"
        case .debugLogsVisible:      return "Log di debug visibili nella UI"
        case .circuitBreakerEnabled: return "Circuit Breaker per le API"
        }
    }
}

// MARK: - FeatureFlagService

/// Servizio che gestisce la lettura e la scrittura dei feature flag.
/// `@MainActor` per la compatibilità con SwiftUI (`ObservableObject`).
@MainActor
public final class FeatureFlagService: ObservableObject {

    // MARK: - Storage

    private let store: UserDefaults
    private let logger = Logger(subsystem: "com.infrademo", category: "FeatureFlags")

    // MARK: - Init

    public init(store: UserDefaults = .standard) {
        self.store = store
        // Registra i valori di default: non sovrascrivono valori esistenti
        let defaults = Dictionary(uniqueKeysWithValues:
            FeatureFlag.allCases.map { ($0.rawValue, $0.defaultValue) }
        )
        store.register(defaults: defaults)
    }

    // MARK: - Lettura

    /// Restituisce `true` se il flag è abilitato.
    public func isEnabled(_ flag: FeatureFlag) -> Bool {
        store.bool(forKey: flag.rawValue)
    }

    /// Subscript conveniente: `flags[.streamingEnabled]`
    public subscript(flag: FeatureFlag) -> Bool {
        isEnabled(flag)
    }

    // MARK: - Scrittura (es. pannello di debug)

    public func set(_ flag: FeatureFlag, enabled: Bool) {
        store.set(enabled, forKey: flag.rawValue)
        objectWillChange.send()
        logger.info("Flag \(flag.rawValue, privacy: .public) → \(enabled ? "ON" : "OFF")")
    }

    // MARK: - Reset

    public func resetAll() {
        FeatureFlag.allCases.forEach { flag in
            store.set(flag.defaultValue, forKey: flag.rawValue)
        }
        objectWillChange.send()
        logger.info("Tutti i feature flag resettati ai valori di default.")
    }
}

// MARK: - SwiftUI: FeatureFlagToggleView (pannello di debug)

/// Vista di debug che mostra e permette di modificare tutti i feature flag.
/// Da mostrare solo in build Debug (controllata dal flag `debugLogsVisible`).
public struct FeatureFlagDebugView: View {

    @ObservedObject var service: FeatureFlagService

    public init(service: FeatureFlagService) {
        self.service = service
    }

    public var body: some View {
        NavigationStack {
            List(FeatureFlag.allCases, id: \.rawValue) { flag in
                Toggle(isOn: Binding(
                    get: { service.isEnabled(flag) },
                    set: { service.set(flag, enabled: $0) }
                )) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(flag.rawValue)
                            .font(.caption.monospaced())
                            .foregroundStyle(.secondary)
                        Text(flag.description)
                            .font(.body)
                    }
                }
            }
            .navigationTitle("Feature Flags")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Reset") { service.resetAll() }
                }
            }
        }
    }
}
