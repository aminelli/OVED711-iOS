// AppCoordinator.swift
// InfraDemo
//
// Coordinator radice dell'applicazione.
// Gestisce la struttura di navigazione di primo livello (TabView)
// e crea i coordinator figli per ogni modulo.
// In un'app più grande, ogni tab avrebbe il proprio NavigationStack
// gestito dal proprio coordinator.

import SwiftUI
import Combine

// MARK: - AppTab

/// Le schede principali dell'applicazione.
public enum AppTab: String, CaseIterable {
    case posts  = "Post"
    case users  = "Utenti"
    case infra  = "Infrastruttura"
    case flags  = "Feature Flags"

    var icon: String {
        switch self {
        case .posts: return "doc.text.fill"
        case .users: return "person.3.fill"
        case .infra: return "network"
        case .flags: return "flag.fill"
        }
    }
}

// MARK: - AppCoordinator

@MainActor
public final class AppCoordinator: ObservableObject {

    // MARK: - Stato navigazione top-level

    @Published public var selectedTab: AppTab = .posts

    // MARK: - Dipendenze

    public let container: DependencyContainer

    // MARK: - Init

    public init(container: DependencyContainer) {
        self.container = container
    }

    // MARK: - Navigazione deep-link (esempio)

    /// Gestisce un deep link (es. infrademo://posts/42).
    public func handle(deepLink url: URL) {
        guard let host = url.host() else { return }
        switch host {
        case "posts":
            selectedTab = .posts
        case "users":
            selectedTab = .users
        default:
            break
        }
    }
}

// MARK: - RootView

/// Vista radice che coordina la TabView.
public struct RootView: View {

    @StateObject private var coordinator: AppCoordinator

    public init(container: DependencyContainer) {
        _coordinator = StateObject(wrappedValue: AppCoordinator(container: container))
    }

    public var body: some View {
        TabView(selection: $coordinator.selectedTab) {

            // Tab Posts (modulo con MVVM-C)
            PostsCoordinatorView(container: coordinator.container)
                .tabItem {
                    Label(AppTab.posts.rawValue, systemImage: AppTab.posts.icon)
                }
                .tag(AppTab.posts)

            // Tab Users
            UsersCoordinatorView(container: coordinator.container)
                .tabItem {
                    Label(AppTab.users.rawValue, systemImage: AppTab.users.icon)
                }
                .tag(AppTab.users)

            // Tab Infrastruttura (dashboard tecnica)
            InfraDashboardView(container: coordinator.container)
                .tabItem {
                    Label(AppTab.infra.rawValue, systemImage: AppTab.infra.icon)
                }
                .tag(AppTab.infra)

            // Tab Feature Flags (solo in debug)
            FeatureFlagDebugView(service: coordinator.container.featureFlags)
                .tabItem {
                    Label(AppTab.flags.rawValue, systemImage: AppTab.flags.icon)
                }
                .tag(AppTab.flags)
        }
        // Inietta le dipendenze nell'Environment per tutte le viste figlio
        .environment(\.dependencies,    coordinator.container)
        .environment(\.featureFlags,    coordinator.container.featureFlags)
        .environment(\.networkMonitor,  coordinator.container.networkMonitor)
        // Deep link handling
        .onOpenURL { url in
            coordinator.handle(deepLink: url)
        }
    }
}
