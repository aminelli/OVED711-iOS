// InfraDashboardView.swift
// InfraDemo
//
// Dashboard tecnica: mostra in tempo reale lo stato di tutti i componenti
// infrastrutturali (rete, circuit breaker, cache, breadcrumb trail, log).
// Utile durante lo sviluppo e il debugging.

import SwiftUI

// MARK: - InfraDashboardView

public struct InfraDashboardView: View {

    // MARK: - Dipendenze (init-based DI)

    private let container: DependencyContainer

    @Environment(\.networkMonitor) private var networkMonitor

    // MARK: - Stato locale

    @State private var breadcrumbs:   [Breadcrumb] = []
    @State private var recentLogs:    [String]     = []
    @State private var showFeatureFlags = false

    public init(container: DependencyContainer) {
        self.container = container
    }

    public var body: some View {
        NavigationStack {
            List {

                // MARK: Sezione: Stato rete
                Section("Connettività") {
                    networkStatusRow
                }

                // MARK: Sezione: Cache
                Section("Cache") {
                    Button("Svuota tutta la cache", role: .destructive) {
                        container.cacheManager.clearAll()
                    }
                    LabeledContent("NSCache", value: "LRU in-memory")
                    LabeledContent("URLCache", value: "HTTP su disco (100 MB)")
                }

                // MARK: Sezione: Retry Policy
                Section("Resilienza") {
                    LabeledContent("Max retry",       value: "3")
                    LabeledContent("Base delay",      value: "0.5s")
                    LabeledContent("Backoff",         value: "Esponenziale × 2 + jitter")
                    LabeledContent("Max delay",       value: "30s")
                    LabeledContent("Circuit Breaker", value: "Soglia: 3 fallimenti / 15s cooldown")
                }

                // MARK: Sezione: Breadcrumb Trail
                Section("Breadcrumb Trail (\(breadcrumbs.count))") {
                    if breadcrumbs.isEmpty {
                        Text("Nessun evento registrato.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    } else {
                        ForEach(breadcrumbs.reversed().prefix(10), id: \.timestamp) { crumb in
                            BreadcrumbRow(crumb: crumb)
                        }
                    }
                    Button("Aggiorna") { loadBreadcrumbs() }
                    Button("Pulisci trail", role: .destructive) {
                        Task { await container.breadcrumbTrail.clear() }
                        breadcrumbs = []
                    }
                }

                // MARK: Sezione: Log recenti (OSLog)
                Section("Log recenti") {
                    if recentLogs.isEmpty {
                        Text("Nessun log disponibile (richiede iOS 15+).")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    } else {
                        ForEach(recentLogs.suffix(5), id: \.self) { entry in
                            Text(entry)
                                .font(.system(.caption2, design: .monospaced))
                                .lineLimit(2)
                        }
                    }
                    Button("Ricarica log") { loadLogs() }
                }

                // MARK: Sezione: MetricKit
                Section("MetricKit") {
                    LabeledContent("Stato", value: "Registrato")
                    Text("Le metriche vengono consegnate ogni ~24h dal sistema.\nIn Xcode usa Instruments per il profiling in tempo reale.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Infrastruttura")
            .task {
                loadBreadcrumbs()
                loadLogs()
            }
        }
    }

    // MARK: - Network Status Row

    private var networkStatusRow: some View {
        HStack {
            Circle()
                .fill(networkMonitor.isConnected ? Color.green : Color.red)
                .frame(width: 10, height: 10)
            VStack(alignment: .leading) {
                Text(networkMonitor.isConnected ? "Connesso" : "Offline")
                    .font(.headline)
                Text(statusDescription)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var statusDescription: String {
        switch networkMonitor.status {
        case .connected(let iface):
            switch iface {
            case .wifi:          return "Wi-Fi"
            case .cellular:      return "Rete cellulare"
            case .wiredEthernet: return "Ethernet"
            case .other:         return "Interfaccia sconosciuta"
            }
        case .disconnected: return "Nessuna connessione"
        case .unknown:      return "Rilevamento in corso…"
        }
    }

    // MARK: - Data Loading

    private func loadBreadcrumbs() {
        Task {
            breadcrumbs = await container.breadcrumbTrail.snapshot()
        }
    }

    private func loadLogs() {
        if #available(iOS 15.0, *) {
            recentLogs = (try? LogReader.recentEntries(limit: 20)) ?? []
        }
    }
}

// MARK: - BreadcrumbRow

private struct BreadcrumbRow: View {
    let crumb: Breadcrumb

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack {
                Text(crumb.category)
                    .font(.caption.bold())
                    .foregroundStyle(color(for: crumb.level))
                Spacer()
                Text(crumb.timestamp, style: .time)
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
            }
            Text(crumb.message)
                .font(.caption)
                .lineLimit(2)
        }
    }

    private func color(for level: Breadcrumb.Level) -> Color {
        switch level {
        case .debug:    return .secondary
        case .info:     return .blue
        case .warning:  return .orange
        case .error:    return .red
        case .critical: return .purple
        }
    }
}
