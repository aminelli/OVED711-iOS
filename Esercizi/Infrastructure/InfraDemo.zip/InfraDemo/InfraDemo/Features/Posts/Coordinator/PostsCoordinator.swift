// PostsCoordinator.swift
// InfraDemo
//
// Coordinator per il modulo Posts.
// Il Coordinator è il "cervello" della navigazione nel pattern MVVM-C:
//   - Crea i ViewModel iniettando le dipendenze
//   - Decide DOVE navigare (decoupling tra ViewModel e viste figlio)
//   - Riduce la responsabilità del ViewModel alla sola logica di presentazione
//
// Vantaggi di MVVM-C rispetto a MVVM puro:
//   - La navigazione è testabile separatamente
//   - Il ViewModel non conosce le viste figlio (Principio di Responsabilità Singola)
//   - Flussi di navigazione complessi (deep link, flow condizionali) sono centralizzati

import SwiftUI
import Combine

// MARK: - PostsRoute

/// Destinazioni di navigazione del modulo Posts.
/// Usando un enum si ottiene l'esaustività a compile-time.
public enum PostsRoute: Hashable {
    case detail(post: Post)
    case author(userID: Int)
    case streaming
}

// MARK: - PostsCoordinator

/// Coordinator del modulo Posts.
/// `@MainActor` perché gestisce lo stato della navigazione SwiftUI.
@MainActor
public final class PostsCoordinator: ObservableObject {

    // MARK: - Stack di navigazione

    /// Path di NavigationStack: ogni elemento è una route.
    @Published public var path = NavigationPath()

    // MARK: - Dipendenze (iniettate dal Coordinator genitore)

    private let container: DependencyContainer

    // MARK: - Init

    public init(container: DependencyContainer) {
        self.container = container
    }

    // MARK: - Navigazione (API del coordinator)

    /// Naviga al dettaglio di un post.
    public func showDetail(post: Post) {
        path.append(PostsRoute.detail(post: post))
    }

    /// Naviga alla lista dei post dell'autore.
    public func showAuthor(userID: Int) {
        path.append(PostsRoute.author(userID: userID))
    }

    /// Naviga alla demo di streaming.
    public func showStreaming() {
        path.append(PostsRoute.streaming)
    }

    /// Torna alla schermata precedente.
    public func pop() {
        guard !path.isEmpty else { return }
        path.removeLast()
    }

    /// Torna alla root del modulo.
    public func popToRoot() {
        path = NavigationPath()
    }

    // MARK: - Factory per i ViewModel

    /// Crea un `PostsViewModel` con le dipendenze corrette.
    /// Il Coordinator è l'unico posto che conosce le implementazioni concrete.
    public func makePostsViewModel() -> PostsViewModel {
        PostsViewModel(
            fetchPostsUseCase: container.fetchPostsUseCase,
            coordinator: self
        )
    }

    public func makePostDetailViewModel(post: Post) -> PostDetailViewModel {
        PostDetailViewModel(
            post: post,
            fetchUserUseCase: container.fetchUserUseCase,
            coordinator: self
        )
    }
}

// MARK: - PostsCoordinatorView

/// Vista radice del modulo Posts: gestisce la NavigationStack.
public struct PostsCoordinatorView: View {

    @StateObject private var coordinator: PostsCoordinator

    public init(container: DependencyContainer) {
        _coordinator = StateObject(wrappedValue: PostsCoordinator(container: container))
    }

    public var body: some View {
        NavigationStack(path: $coordinator.path) {
            PostsView(viewModel: coordinator.makePostsViewModel())
                .navigationDestination(for: PostsRoute.self) { route in
                    destinationView(for: route)
                }
        }
        .environmentObject(coordinator)
    }

    @ViewBuilder
    private func destinationView(for route: PostsRoute) -> some View {
        switch route {
        case .detail(let post):
            PostDetailView(viewModel: coordinator.makePostDetailViewModel(post: post))
        case .author(let userID):
            // Reusa la lista post filtrata per autore
            Text("Post di utente #\(userID)")
                .navigationTitle("Autore #\(userID)")
        case .streaming:
            StreamingDemoView()
        }
    }
}
