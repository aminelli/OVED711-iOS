// PostsView.swift
// InfraDemo
//
// Vista principale del modulo Posts.
// Implementa:
//   - Paginazione infinita (carica la pagina successiva quando si raggiunge il fondo)
//   - Pull-to-refresh
//   - Stato di caricamento e gestione errori
//   - Banner offline (NWPathMonitor)
//   - Collegamento al Coordinator per la navigazione

import SwiftUI

// MARK: - PostsView

public struct PostsView: View {

    @StateObject var viewModel: PostsViewModel

    // Legge lo stato della rete dall'Environment (iniettato dal root)
    @Environment(\.networkMonitor) private var networkMonitor
    @Environment(\.featureFlags)   private var featureFlags

    public init(viewModel: PostsViewModel) {
        _viewModel = StateObject(wrappedValue: viewModel)
    }

    public var body: some View {
        Group {
            if viewModel.posts.isEmpty && viewModel.isLoading {
                // Schermata di caricamento iniziale
                ProgressView("Caricamento post…")
            } else if let error = viewModel.error, viewModel.posts.isEmpty {
                // Stato di errore senza dati precedenti
                ErrorView(error: error) {
                    viewModel.loadNextPage()
                }
            } else {
                postsList
            }
        }
        .navigationTitle("Post")
        .toolbar {
            // Bottone streaming (Feature Flag)
            if featureFlags[.streamingEnabled] {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        viewModel.didTapStreaming()
                    } label: {
                        Label("Streaming", systemImage: "dot.radiowaves.left.and.right")
                    }
                }
            }
        }
        .task {
            // Il Task viene annullato automaticamente quando la vista scompare
            viewModel.onAppear()
        }
        // Banner stato rete (Feature Flag)
        .safeAreaInset(edge: .top) {
            if featureFlags[.networkStatusBanner] && !networkMonitor.isConnected {
                OfflineBannerView()
            }
        }
    }

    // MARK: - Lista con paginazione infinita

    private var postsList: some View {
        List {
            ForEach(viewModel.posts) { post in
                PostRowView(post: post)
                    .contentShape(Rectangle())
                    .onTapGesture {
                        viewModel.didSelectPost(post)
                    }
                    // Trigger paginazione: quando l'ultimo elemento è visibile
                    .onAppear {
                        if post.id == viewModel.posts.last?.id {
                            viewModel.loadNextPage()
                        }
                    }
            }

            // Footer: spinner paginazione o fine lista
            if viewModel.isLoading {
                HStack {
                    Spacer()
                    ProgressView()
                    Spacer()
                }
                .listRowSeparator(.hidden)
            } else if !viewModel.hasMorePages {
                Text("Fine dei post")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity)
                    .listRowSeparator(.hidden)
            }
        }
        .listStyle(.plain)
        .refreshable {
            // Pull-to-refresh: il refreshable aspetta il completamento del Task
            await viewModel.refresh()
        }
    }
}

// MARK: - PostRowView

struct PostRowView: View {
    let post: Post

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(post.title.capitalized)
                .font(.headline)
                .lineLimit(2)
            Text(post.body)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .lineLimit(3)
            Text("Autore #\(post.userID)")
                .font(.caption)
                .foregroundStyle(.tertiary)
        }
        .padding(.vertical, 4)
    }
}

// MARK: - ErrorView

struct ErrorView: View {
    let error: NetworkError
    let retry: () -> Void

    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "exclamationmark.triangle.fill")
                .font(.largeTitle)
                .foregroundStyle(.orange)
            Text(error.errorDescription ?? "Errore sconosciuto")
                .multilineTextAlignment(.center)
            Button("Riprova", action: retry)
                .buttonStyle(.borderedProminent)
        }
        .padding()
    }
}

// MARK: - OfflineBannerView

struct OfflineBannerView: View {
    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "wifi.slash")
            Text("Nessuna connessione di rete")
                .font(.caption.bold())
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 6)
        .background(Color.orange)
        .foregroundStyle(.white)
    }
}
