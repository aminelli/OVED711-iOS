// PostDetailView.swift
// InfraDemo
//
// Vista di dettaglio di un post.
// Mostra il contenuto del post e carica l'autore in modo asincrono.

import SwiftUI

public struct PostDetailView: View {

    @StateObject var viewModel: PostDetailViewModel

    public init(viewModel: PostDetailViewModel) {
        _viewModel = StateObject(wrappedValue: viewModel)
    }

    public var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {

                // Titolo
                Text(viewModel.post.title.capitalized)
                    .font(.title2.bold())

                // Corpo
                Text(viewModel.post.body)
                    .font(.body)
                    .foregroundStyle(.secondary)

                Divider()

                // Sezione autore
                authorSection
            }
            .padding()
        }
        .navigationTitle("Post #\(viewModel.post.id)")
        .navigationBarTitleDisplayMode(.inline)
        .task {
            viewModel.loadAuthor()
        }
    }

    // MARK: - Sezione autore

    @ViewBuilder
    private var authorSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Autore")
                .font(.caption.uppercaseSmallCaps())
                .foregroundStyle(.secondary)

            if viewModel.isLoadingAuthor {
                HStack {
                    ProgressView()
                    Text("Caricamento autore…")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            } else if let author = viewModel.author {
                Button(action: viewModel.didTapAuthor) {
                    HStack {
                        Image(systemName: "person.circle.fill")
                            .font(.title2)
                            .foregroundStyle(.tint)
                        VStack(alignment: .leading) {
                            Text(author.name)
                                .font(.headline)
                            Text(author.email)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        Image(systemName: "chevron.right")
                            .foregroundStyle(.tertiary)
                    }
                }
                .buttonStyle(.plain)
            } else if let error = viewModel.error {
                Label(
                    error.errorDescription ?? "Errore caricamento autore",
                    systemImage: "exclamationmark.triangle"
                )
                .font(.caption)
                .foregroundStyle(.orange)
            }
        }
    }
}
