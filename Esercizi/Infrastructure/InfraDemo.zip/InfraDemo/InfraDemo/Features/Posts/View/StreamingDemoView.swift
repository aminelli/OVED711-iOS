// StreamingDemoView.swift
// InfraDemo
//
// Vista demo per lo streaming con AsyncSequence.
// Dimostra:
//   - AsyncThrowingStream consumato in SwiftUI
//   - Cancellazione del Task quando la vista scompare
//   - Aggiornamento progressivo della UI

import SwiftUI

// MARK: - StreamingDemoView

public struct StreamingDemoView: View {

    // MARK: - Stato UI

    @State private var lines:       [String] = []
    @State private var isStreaming: Bool     = false
    @State private var streamTask:  Task<Void, Never>?

    // Endpoint di streaming simulato (jsonplaceholder non supporta vero streaming,
    // ma la struttura è identica per un SSE/NDJSON reale).
    @Environment(\.dependencies) private var deps

    public var body: some View {
        VStack(alignment: .leading, spacing: 0) {

            // Header controlli
            HStack {
                Button(isStreaming ? "Stop" : "Avvia Streaming") {
                    if isStreaming {
                        stopStream()
                    } else {
                        startStream()
                    }
                }
                .buttonStyle(.borderedProminent)
                .tint(isStreaming ? .red : .blue)

                Spacer()

                if isStreaming {
                    ProgressView()
                }

                Button("Pulisci") { lines = [] }
                    .disabled(lines.isEmpty)
            }
            .padding()

            Divider()

            // Log delle righe ricevute
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 4) {
                        ForEach(Array(lines.enumerated()), id: \.offset) { idx, line in
                            Text(line)
                                .font(.system(.caption, design: .monospaced))
                                .padding(.horizontal)
                                .id(idx)
                        }
                    }
                    .padding(.vertical, 8)
                }
                .onChange(of: lines.count) { _, newCount in
                    // Auto-scroll all'ultima riga
                    if newCount > 0 {
                        withAnimation {
                            proxy.scrollTo(newCount - 1, anchor: .bottom)
                        }
                    }
                }
            }

            if lines.isEmpty && !isStreaming {
                Spacer()
                ContentUnavailableView(
                    "Avvia lo Streaming",
                    systemImage: "dot.radiowaves.left.and.right",
                    description: Text("Premi il bottone per avviare la ricezione asincrona dei dati.")
                )
                Spacer()
            }
        }
        .navigationTitle("AsyncSequence Streaming")
        .navigationBarTitleDisplayMode(.inline)
        // Annulla lo stream quando la vista scompare (Task cancellation)
        .onDisappear {
            stopStream()
        }
    }

    // MARK: - Streaming

    private func startStream() {
        isStreaming = true
        lines.append("▶ Stream avviato…")

        // Il Task viene salvato per poterlo annullare con .cancel()
        streamTask = Task { @MainActor in
            // Endpoint fittizio: in produzione sarebbe un endpoint SSE/NDJSON reale
            let endpoint = PostsEndpoint.list(page: 1, limit: 20)
            let stream   = deps.networkActor.stream(endpoint)

            do {
                for try await line in stream {
                    // Ogni iterazione aggiorna la UI (siamo già su @MainActor)
                    lines.append("← \(line.prefix(120))")
                }
                lines.append("✓ Stream completato.")
            } catch NetworkError.cancelled {
                lines.append("⊘ Stream annullato dall'utente.")
            } catch {
                lines.append("✗ Errore: \(error.localizedDescription)")
            }

            isStreaming = false
        }
    }

    private func stopStream() {
        // Annulla il Task: la cancellazione viene propagata all'AsyncThrowingStream
        streamTask?.cancel()
        streamTask = nil
        isStreaming = false
    }
}
