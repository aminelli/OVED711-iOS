// PostDetailViewModel.swift
// InfraDemo
//
// ViewModel per il dettaglio di un post.
// Dimostra il caricamento parallelo con `async let`:
// il post è già disponibile, mentre l'autore viene caricato in parallelo.

import Foundation
import OSLog
import Combine

@MainActor
public final class PostDetailViewModel: ObservableObject {

    // MARK: - Stato UI

    @Published public private(set) var post: Post
    @Published public private(set) var author: User?
    @Published public private(set) var isLoadingAuthor = false
    @Published public private(set) var error: NetworkError?

    // MARK: - Dipendenze

    private let fetchUserUseCase: any FetchUserUseCaseProtocol
    private weak var coordinator: PostsCoordinator?
    private let logger = Logger(subsystem: "com.infrademo", category: "PostDetailViewModel")

    // MARK: - Init

    public init(
        post: Post,
        fetchUserUseCase: any FetchUserUseCaseProtocol,
        coordinator: PostsCoordinator?
    ) {
        self.post            = post
        self.fetchUserUseCase = fetchUserUseCase
        self.coordinator     = coordinator
    }

    // MARK: - Caricamento autore

    public func loadAuthor() {
        guard author == nil, !isLoadingAuthor else { return }
        isLoadingAuthor = true

        Task { [weak self] in
            guard let self else { return }
            do {
                let user = try await fetchUserUseCase.execute(userID: post.userID)
                self.author          = user
                self.isLoadingAuthor = false
                logger.debug("Autore caricato: \(user.name)")
            } catch let netError as NetworkError {
                self.error          = netError
                self.isLoadingAuthor = false
            } catch {
                self.error          = .unknown(error)
                self.isLoadingAuthor = false
            }
        }
    }

    // MARK: - Navigazione

    public func didTapAuthor() {
        coordinator?.showAuthor(userID: post.userID)
    }
}
