// PostsViewModel.swift
// InfraDemo
//
// ViewModel del modulo Posts (pattern MVVM).
// Responsabilità:
//   - Esporre lo stato della UI (@Published)
//   - Orchestrare i UseCase
//   - Gestire la paginazione cursor-based
//   - Gestire la cancellazione dei Task
//   - NON conoscere i dettagli della navigazione (delegati al Coordinator)
//
// `@MainActor` garantisce che tutte le proprietà @Published siano
// aggiornate sul main thread (requisito SwiftUI in Swift 6).

import Foundation
import OSLog
import Combine

// MARK: - PostsViewModel

@MainActor
public final class PostsViewModel: ObservableObject {

    // MARK: - Stato della UI

    /// Lista dei post caricati (accumulati per paginazione infinita).
    @Published public private(set) var posts: [Post] = []

    /// Stato del caricamento.
    @Published public private(set) var isLoading = false

    /// Errore corrente da mostrare in UI.
    @Published public private(set) var error: NetworkError?

    /// `true` se ci sono altre pagine da caricare.
    @Published public private(set) var hasMorePages = true

    // MARK: - Stato interno

    /// Cursore della prossima pagina (nil = prima pagina non ancora caricata).
    private var nextCursor: String?

    /// Task di caricamento corrente (per la cancellazione).
    private var loadTask: Task<Void, Never>?

    // MARK: - Dipendenze

    private let fetchPostsUseCase: any FetchPostsUseCaseProtocol
    /// Riferimento debole al coordinator per evitare retain cycle.
    private weak var coordinator: PostsCoordinator?

    private let logger = Logger(subsystem: "com.infrademo", category: "PostsViewModel")

    // MARK: - Init (init-based DI)

    public init(
        fetchPostsUseCase: any FetchPostsUseCaseProtocol,
        coordinator: PostsCoordinator?
    ) {
        self.fetchPostsUseCase = fetchPostsUseCase
        self.coordinator       = coordinator
    }

    // MARK: - Lifecycle

    /// Da chiamare in `.task {}` della vista: carica la prima pagina.
    public func onAppear() {
        guard posts.isEmpty else { return }  // Evita ricaricamento su ogni apparizione
        loadNextPage()
    }

    // MARK: - Caricamento paginato

    /// Carica la pagina successiva (o la prima se è il primo caricamento).
    /// Annulla eventuali task in volo prima di avviarne uno nuovo.
    public func loadNextPage() {
        guard !isLoading, hasMorePages else { return }

        // Annulla il task precedente (cancellazione con Task)
        loadTask?.cancel()

        loadTask = Task { [weak self] in
            guard let self else { return }

            self.isLoading = true
            self.error     = nil

            do {
                let (newPosts, cursor) = try await fetchPostsUseCase.execute(cursor: nextCursor)

                // Verifica cancellazione prima di aggiornare la UI
                guard !Task.isCancelled else { return }

                self.posts.append(contentsOf: newPosts)
                self.nextCursor  = cursor
                self.hasMorePages = cursor != nil
                self.logger.debug("Caricati \(newPosts.count) post, cursore: \(cursor ?? "nil")")
            } catch is CancellationError {
                self.logger.debug("Caricamento post annullato.")
            } catch let netError as NetworkError {
                self.error = netError
                self.logger.error("Errore caricamento post: \(netError)")
            } catch {
                self.error = .unknown(error)
            }

            self.isLoading = false
        }
    }

    /// Ricarica dall'inizio (pull-to-refresh).
    public func refresh() async {
        loadTask?.cancel()
        posts       = []
        nextCursor  = nil
        hasMorePages = true
        loadNextPage()
    }

    // MARK: - Navigazione (delegata al Coordinator)

    public func didSelectPost(_ post: Post) {
        Task { @MainActor in
            await coordinator?.breadcrumbTrail?.userAction("Selezionato post #\(post.id)")
        }
        coordinator?.showDetail(post: post)
    }

    public func didTapStreaming() {
        coordinator?.showStreaming()
    }
}

// MARK: - Estensione per breadcrumb (opzionale)

private extension PostsCoordinator {
    // Accesso al breadcrumb trail tramite il container (solo per comodità)
    var breadcrumbTrail: BreadcrumbTrail? { nil } // Sovrascrivere se necessario
}
