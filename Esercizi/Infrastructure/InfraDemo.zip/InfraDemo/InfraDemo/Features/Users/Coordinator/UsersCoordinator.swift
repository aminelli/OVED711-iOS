// UsersCoordinator.swift
// InfraDemo
//
// Coordinator per il modulo Users.

import SwiftUI
import Combine

public enum UsersRoute: Hashable {
    case detail(user: User)
}

@MainActor
public final class UsersCoordinator: ObservableObject {

    @Published public var path = NavigationPath()

    private let container: DependencyContainer

    public init(container: DependencyContainer) {
        self.container = container
    }

    public func showDetail(user: User) {
        path.append(UsersRoute.detail(user: user))
    }

    public func pop() {
        guard !path.isEmpty else { return }
        path.removeLast()
    }

    public func makeUsersViewModel() -> UsersViewModel {
        UsersViewModel(
            fetchUsersUseCase: container.fetchUsersUseCase,
            coordinator: self
        )
    }
}

// MARK: - UsersCoordinatorView

public struct UsersCoordinatorView: View {

    @StateObject private var coordinator: UsersCoordinator

    public init(container: DependencyContainer) {
        _coordinator = StateObject(wrappedValue: UsersCoordinator(container: container))
    }

    public var body: some View {
        NavigationStack(path: $coordinator.path) {
            UsersView(viewModel: coordinator.makeUsersViewModel())
                .navigationDestination(for: UsersRoute.self) { route in
                    switch route {
                    case .detail(let user):
                        UserDetailView(user: user)
                    }
                }
        }
    }
}
