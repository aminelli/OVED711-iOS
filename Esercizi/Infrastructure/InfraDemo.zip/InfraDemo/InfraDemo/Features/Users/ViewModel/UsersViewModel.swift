// UsersViewModel.swift
// InfraDemo
//
// ViewModel per la lista utenti.
// Dimostra il caricamento con TaskGroup (più utenti in parallelo).

import Foundation
import OSLog
public import Combine

@MainActor
public final class UsersViewModel: ObservableObject {
    

    @Published public private(set) var users:     [User] = []
    @Published public private(set) var isLoading: Bool   = false
    @Published public private(set) var error:     NetworkError?

    private let fetchUsersUseCase: any FetchUsersUseCaseProtocol
    private weak var coordinator: UsersCoordinator?
    private let logger = Logger(subsystem: "com.infrademo", category: "UsersViewModel")

    public init(
        fetchUsersUseCase: any FetchUsersUseCaseProtocol,
        coordinator: UsersCoordinator?
    ) {
        self.fetchUsersUseCase = fetchUsersUseCase
        self.coordinator       = coordinator
    }

    public func onAppear() {
        guard users.isEmpty else { return }
        loadUsers()
    }

    public func loadUsers() {
        isLoading = true
        error     = nil

        Task { [weak self] in
            guard let self else { return }
            do {
                let result     = try await fetchUsersUseCase.execute()
                self.users     = result
                self.isLoading = false
                self.logger.debug("Caricati \(result.count) utenti")
            } catch let netError as NetworkError {
                self.error     = netError
                self.isLoading = false
            } catch {
                self.error     = .unknown(error)
                self.isLoading = false
            }
        }
    }

    public func didSelectUser(_ user: User) {
        coordinator?.showDetail(user: user)
    }
}
