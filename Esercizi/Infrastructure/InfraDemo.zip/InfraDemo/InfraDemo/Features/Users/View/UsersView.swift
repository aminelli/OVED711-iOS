// UsersView.swift
// InfraDemo
//
// Vista per la lista degli utenti.

import SwiftUI

public struct UsersView: View {

    @StateObject var viewModel: UsersViewModel

    public init(viewModel: UsersViewModel) {
        _viewModel = StateObject(wrappedValue: viewModel)
    }

    public var body: some View {
        Group {
            if viewModel.isLoading && viewModel.users.isEmpty {
                ProgressView("Caricamento utenti…")
            } else if let error = viewModel.error, viewModel.users.isEmpty {
                ErrorView(error: error) { viewModel.loadUsers() }
            } else {
                List(viewModel.users) { user in
                    UserRowView(user: user)
                        .contentShape(Rectangle())
                        .onTapGesture { viewModel.didSelectUser(user) }
                }
                .listStyle(.plain)
                .refreshable { viewModel.loadUsers() }
            }
        }
        .navigationTitle("Utenti")
        .task { viewModel.onAppear() }
    }
}

// MARK: - UserRowView

struct UserRowView: View {
    let user: User

    var body: some View {
        HStack(spacing: 12) {
            Circle()
                .fill(Color.accentColor.opacity(0.2))
                .frame(width: 44, height: 44)
                .overlay {
                    Text(user.name.prefix(1))
                        .font(.title3.bold())
                        .foregroundStyle(.tint)
                }

            VStack(alignment: .leading, spacing: 2) {
                Text(user.name)
                    .font(.headline)
                Text(user.email)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 4)
    }
}

// MARK: - UserDetailView

struct UserDetailView: View {
    let user: User

    var body: some View {
        List {
            Section("Profilo") {
                LabeledContent("Nome",     value: user.name)
                LabeledContent("Username", value: "@\(user.username)")
                LabeledContent("Email",    value: user.email)
                if let website = user.website {
                    LabeledContent("Sito", value: website)
                }
            }

            if let address = user.address {
                Section("Indirizzo") {
                    LabeledContent("Città",   value: address.city)
                    LabeledContent("Via",     value: address.street)
                    LabeledContent("CAP",     value: address.zipcode)
                }
            }
        }
        .navigationTitle(user.name)
        .navigationBarTitleDisplayMode(.large)
    }
}


