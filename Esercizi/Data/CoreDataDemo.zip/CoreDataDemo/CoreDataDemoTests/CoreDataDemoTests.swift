//
//  CoreDataDemoTests.swift
//  CoreDataDemoTests
//
//  Created by Antonio Minelli on 25/06/2026.
//

import Testing
@testable import CoreDataDemo

struct CoreDataDemoTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
        // Swift Testing Documentation
        // https://developer.apple.com/documentation/testing
    }

}
