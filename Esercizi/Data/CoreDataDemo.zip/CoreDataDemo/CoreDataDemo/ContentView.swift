//
//  ContentView.swift
//  CoreDataDemo
//
//  Punto di entrata delle view. Rimanda direttamente a MainTabView.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        MainTabView()
    }
}

#Preview {
    ContentView()
        .environment(\.managedObjectContext, PersistenceController.preview.viewContext)
}
