//
//  PersistenceController.swift
//  CoreDataDemo
//
//  Stack Core Data centralizzato dell'applicazione.
//  Dimostra: NSPersistentContainer, contesti background, batch operations,
//  migrazione leggera, undo/redo, merge policy e caricamento dati di esempio.
//

import CoreData
import Foundation

// MARK: - PersistenceController
/// Singleton che gestisce l'intero stack Core Data.
///
/// Responsabilità principali:
/// - Inizializzazione del NSPersistentContainer
/// - Configurazione del viewContext (thread principale)
/// - Fornitura di contesti background per operazioni pesanti
/// - Operazioni di batch insert/delete ad alte prestazioni
/// - Supporto undo/redo tramite UndoManager
/// - Migrazione leggera automatica tra versioni del modello
final class PersistenceController: @unchecked Sendable {

    // MARK: - Istanze Singleton
    /// Istanza condivisa per l'uso in produzione (dati reali su disco)
    static let shared = PersistenceController()

    /// Istanza di anteprima per SwiftUI Previews con store in memoria e dati di esempio.
    /// Usa `inMemory: true` per evitare di sporcare il database di produzione.
    static let preview: PersistenceController = {
        let controller = PersistenceController(inMemory: true)
        // Popola con dati di esempio per le Previews SwiftUI
        controller.loadSampleData()
        return controller
    }()

    // MARK: - Container Persistente
    /// Il container principale che gestisce il modello, il coordinatore e i contesti.
    let container: NSPersistentContainer

    // MARK: - Inizializzazione
    /// - Parameter inMemory: Se `true`, usa `/dev/null` come URL per store temporaneo.
    ///   Utile per test unitari e SwiftUI Previews.
    init(inMemory: Bool = false) {
        // Il nome deve corrispondere ESATTAMENTE al file .xcdatamodeld
        container = NSPersistentContainer(name: "CoreDataModel")

        if inMemory {
            // Store temporaneo in memoria: i dati NON vengono persistiti su disco
            container.persistentStoreDescriptions.first?.url = URL(fileURLWithPath: "/dev/null")
        }

        // MARK: Configurazione Store Description
        // Abilita migrazione leggera automatica (aggiunta/rimozione attributi opzionali)
        if let description = container.persistentStoreDescriptions.first {
            description.shouldMigrateStoreAutomatically = true
            description.shouldInferMappingModelAutomatically = true

            // Persistent History Tracking: traccia le modifiche nel tempo.
            // Necessario per NSPersistentCloudKitContainer e merge cross-process.
            description.setOption(
                true as NSNumber,
                forKey: NSPersistentHistoryTrackingKey
            )

            // Notifica il context di modifiche remote (es. da extension o widget)
            description.setOption(
                true as NSNumber,
                forKey: NSPersistentStoreRemoteChangeNotificationPostOptionKey
            )
        }

        // Carica il persistent store (può lanciare in caso di corruzione del DB)
        container.loadPersistentStores { storeDescription, error in
            if let error = error as NSError? {
                // NOTA: In produzione, presentare un alert all'utente e/o tentare il recovery.
                // fatalError va usato SOLO durante lo sviluppo.
                fatalError("Impossibile caricare il persistent store: \(error.localizedDescription)\nUserInfo: \(error.userInfo)")
            }
        }

        // MARK: Configurazione viewContext (Main Thread Context)
        let ctx = container.viewContext

        // Unisce automaticamente le modifiche salvate dai context background
        ctx.automaticallyMergesChangesFromParent = true

        // Merge policy: in caso di conflitto, le proprietà dell'oggetto in memoria
        // sovrascrivono quelle nel persistent store (strategia "last writer wins")
        ctx.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy

        // Abilita UndoManager per supporto Cmd+Z / Shake-to-undo su device
        ctx.undoManager = UndoManager()

        // Nome descrittivo per il debug nel Core Data Instruments
        ctx.name = "ViewContext-MainThread"

        // Se un fault non può essere risolto, elimina l'oggetto invece di crashare
        ctx.shouldDeleteInaccessibleFaults = true
    }

    // MARK: - Accesso Context

    /// Context del thread principale per operazioni legate all'interfaccia utente.
    /// Tutte le letture/scritture delle View devono usare questo context.
    var viewContext: NSManagedObjectContext {
        container.viewContext
    }

    /// Crea un nuovo context di background indipendente.
    /// Usare per operazioni pesanti (import dati, elaborazione batch) senza bloccare la UI.
    func newBackgroundContext() -> NSManagedObjectContext {
        let context = container.newBackgroundContext()
        // Stessa merge policy del viewContext per coerenza
        context.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
        // Si aggiorna automaticamente quando il viewContext salva
        context.automaticallyMergesChangesFromParent = true
        context.name = "BackgroundContext"
        return context
    }

    // MARK: - Salvataggio

    /// Salva il viewContext se contiene modifiche non salvate.
    /// Chiama questo metodo dal thread principale.
    func save() {
        let context = container.viewContext
        guard context.hasChanges else { return }

        do {
            try context.save()
        } catch {
            let nsError = error as NSError
            // Logga l'errore in modo strutturato
            print("[PersistenceController] Errore salvataggio viewContext: \(nsError.localizedDescription)")
            print("[PersistenceController] UserInfo: \(nsError.userInfo)")
        }
    }

    /// Salva un context arbitrario (tipicamente di background).
    /// Deve essere chiamato sul thread corretto del context (usa `context.perform { }`).
    func save(context: NSManagedObjectContext) {
        guard context.hasChanges else { return }

        do {
            try context.save()
        } catch {
            let nsError = error as NSError
            print("[PersistenceController] Errore salvataggio context: \(nsError.localizedDescription)")
        }
    }

    // MARK: - Operazioni Asincrone Background

    /// Esegue un blocco di operazioni Core Data in un context di background.
    /// Il blocco viene eseguito automaticamente sul thread corretto del context.
    ///
    /// - Parameter block: Closure che riceve il context background; salva esplicitamente se necessario.
    func performBackgroundTask(_ block: @escaping (NSManagedObjectContext) -> Void) {
        container.performBackgroundTask(block)
    }

    // MARK: - Batch Delete

    /// Elimina in modo efficiente tutti gli oggetti che soddisfano il predicato.
    ///
    /// NSBatchDeleteRequest bypassa il contesto e lavora direttamente sul SQLite store,
    /// quindi è molto più veloce di eliminare oggetto per oggetto. Richiede però
    /// di aggiornare manualmente il viewContext con gli ID eliminati.
    ///
    /// - Parameters:
    ///   - entityName: Nome dell'entità da eliminare (es. "Book")
    ///   - predicate: Filtro opzionale; se nil, elimina TUTTI gli oggetti dell'entità
    func batchDelete(entityName: String, predicate: NSPredicate? = nil) {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        fetchRequest.predicate = predicate

        let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        // Ritorna gli ObjectID degli oggetti eliminati per sincronizzare il viewContext
        deleteRequest.resultType = .resultTypeObjectIDs

        do {
            let result = try container.viewContext.execute(deleteRequest) as? NSBatchDeleteResult
            let deletedIDs = result?.result as? [NSManagedObjectID] ?? []

            // Propaga la cancellazione al viewContext in memoria
            let changes: [AnyHashable: Any] = [NSDeletedObjectsKey: deletedIDs]
            NSManagedObjectContext.mergeChanges(
                fromRemoteContextSave: changes,
                into: [container.viewContext]
            )
        } catch {
            print("[PersistenceController] Errore batch delete '\(entityName)': \(error.localizedDescription)")
        }
    }

    // MARK: - Batch Insert

    /// Inserisce in modo efficiente un array di dizionari come nuovi oggetti nel persistent store.
    ///
    /// NSBatchInsertRequest è disponibile da iOS 13 ed è molto più performante
    /// dell'inserimento oggetto per oggetto per grandi set di dati.
    ///
    /// - Parameters:
    ///   - entityName: Nome dell'entità da inserire (es. "Tag")
    ///   - objects: Array di dizionari `[attributeName: value]`
    func batchInsert(entityName: String, objects: [[String: Any]]) {
        guard !objects.isEmpty else { return }

        let batchInsert = NSBatchInsertRequest(entityName: entityName, objects: objects)
        batchInsert.resultType = .objectIDs

        do {
            let result = try container.viewContext.execute(batchInsert) as? NSBatchInsertResult
            let insertedIDs = result?.result as? [NSManagedObjectID] ?? []

            // Aggiorna il viewContext con i nuovi oggetti inseriti
            let changes: [AnyHashable: Any] = [NSInsertedObjectsKey: insertedIDs]
            NSManagedObjectContext.mergeChanges(
                fromRemoteContextSave: changes,
                into: [container.viewContext]
            )
        } catch {
            print("[PersistenceController] Errore batch insert '\(entityName)': \(error.localizedDescription)")
        }
    }

    // MARK: - Undo / Redo

    /// Annulla l'ultima operazione nel viewContext.
    /// Equivalente a Cmd+Z o "Shake to Undo" su device fisico.
    func undo() {
        container.viewContext.undoManager?.undo()
    }

    /// Ripete l'ultima operazione annullata nel viewContext.
    func redo() {
        container.viewContext.undoManager?.redo()
    }

    /// Verifica se ci sono operazioni da annullare
    var canUndo: Bool {
        container.viewContext.undoManager?.canUndo ?? false
    }

    /// Verifica se ci sono operazioni da rifare
    var canRedo: Bool {
        container.viewContext.undoManager?.canRedo ?? false
    }

    // MARK: - Query Aggregate

    /// Conta il numero di oggetti che soddisfano il predicato per un'entità.
    ///
    /// Usa `count(for:)` che esegue `SELECT COUNT(*)` SQL senza caricare oggetti in memoria.
    func count(entityName: String, predicate: NSPredicate? = nil) -> Int {
        let request = NSFetchRequest<NSManagedObject>(entityName: entityName)
        request.predicate = predicate

        do {
            return try container.viewContext.count(for: request)
        } catch {
            print("[PersistenceController] Errore count '\(entityName)': \(error)")
            return 0
        }
    }

    /// Calcola la somma di un attributo numerico per un'entità.
    ///
    /// Usa NSFetchRequest con resultType `.dictionaryResultType` e
    /// NSExpressionDescription per eseguire aggregazioni direttamente in SQL.
    func sum(attribute: String, entityName: String, predicate: NSPredicate? = nil) -> Double {
        let request = NSFetchRequest<NSDictionary>(entityName: entityName)
        request.resultType = .dictionaryResultType
        request.predicate = predicate

        // Crea l'espressione SUM(attribute)
        let expression = NSExpression(forKeyPath: attribute)
        let sumExpression = NSExpression(forFunction: "sum:", arguments: [expression])

        let description = NSExpressionDescription()
        description.name = "sumResult"
        description.expression = sumExpression
        description.expressionResultType = .doubleAttributeType

        request.propertiesToFetch = [description]

        do {
            let results = try container.viewContext.fetch(request)
            return results.first?["sumResult"] as? Double ?? 0
        } catch {
            print("[PersistenceController] Errore sum '\(attribute)' su '\(entityName)': \(error)")
            return 0
        }
    }

    /// Calcola la media di un attributo numerico per un'entità.
    func average(attribute: String, entityName: String, predicate: NSPredicate? = nil) -> Double {
        let request = NSFetchRequest<NSDictionary>(entityName: entityName)
        request.resultType = .dictionaryResultType
        request.predicate = predicate

        let expression = NSExpression(forKeyPath: attribute)
        let avgExpression = NSExpression(forFunction: "average:", arguments: [expression])

        let description = NSExpressionDescription()
        description.name = "avgResult"
        description.expression = avgExpression
        description.expressionResultType = .doubleAttributeType

        request.propertiesToFetch = [description]

        do {
            let results = try container.viewContext.fetch(request)
            return results.first?["avgResult"] as? Double ?? 0
        } catch {
            print("[PersistenceController] Errore average '\(attribute)' su '\(entityName)': \(error)")
            return 0
        }
    }

    // MARK: - Dati di Esempio

    /// Popola il database con dati significativi per dimostrare le funzionalità.
    /// Chiamato solo per preview e test; non usare in produzione.
    func loadSampleData() {
        let context = container.viewContext

        // ── TAG ─────────────────────────────────────────────
        let tagFiction       = Tag.create(name: "Fiction",          colorHex: "#FF6B6B", in: context)
        let tagSciFi         = Tag.create(name: "Science Fiction",  colorHex: "#4ECDC4", in: context)
        let tagClassics      = Tag.create(name: "Classics",         colorHex: "#45B7D1", in: context)
        let tagTechnology    = Tag.create(name: "Technology",       colorHex: "#96CEB4", in: context)
        let tagPhilosophy    = Tag.create(name: "Philosophy",       colorHex: "#FFEAA7", in: context)

        // ── AUTORI ──────────────────────────────────────────
        let orwell = Author.create(
            name: "George Orwell",
            biography: "Eric Arthur Blair, noto con lo pseudonimo George Orwell, fu un romanziere, saggista e critico inglese, famoso per le sue opere di critica sociale e politica.",
            birthDate: Calendar.current.date(from: DateComponents(year: 1903, month: 6, day: 25)),
            in: context
        )
        orwell.addToTags(tagFiction)
        orwell.addToTags(tagClassics)
        orwell.addToTags(tagPhilosophy)

        let asimov = Author.create(
            name: "Isaac Asimov",
            biography: "Isaac Asimov fu un autore americano e professore di biochimica, noto soprattutto per le sue opere di fantascienza e divulgazione scientifica.",
            birthDate: Calendar.current.date(from: DateComponents(year: 1920, month: 1, day: 2)),
            in: context
        )
        asimov.addToTags(tagSciFi)
        asimov.addToTags(tagTechnology)

        let pkDick = Author.create(
            name: "Philip K. Dick",
            biography: "Philip Kindred Dick fu uno scrittore americano di fantascienza le cui opere esplorano temi filosofici, sociali e politici sulla natura della realtà.",
            birthDate: Calendar.current.date(from: DateComponents(year: 1928, month: 12, day: 16)),
            in: context
        )
        pkDick.addToTags(tagSciFi)
        pkDick.addToTags(tagPhilosophy)

        let tolkien = Author.create(
            name: "J.R.R. Tolkien",
            biography: "John Ronald Reuel Tolkien fu uno scrittore, poeta e filologo inglese, autore de Lo Hobbit e Il Signore degli Anelli.",
            birthDate: Calendar.current.date(from: DateComponents(year: 1892, month: 1, day: 3)),
            in: context
        )
        tolkien.addToTags(tagFiction)

        // ── LIBRI ────────────────────────────────────────────
        let book1984 = Book.create(
            title: "Nineteen Eighty-Four",
            synopsis: "Un romanzo distopico ambientato in una società totalitaria dove il Grande Fratello controlla ogni aspetto della vita.",
            pageCount: 328, rating: 4.8,
            publishedDate: Calendar.current.date(from: DateComponents(year: 1949, month: 6, day: 8)),
            author: orwell, in: context
        )
        book1984.isRead = true
        book1984.addToTags(tagFiction); book1984.addToTags(tagClassics); book1984.addToTags(tagPhilosophy)

        let bookFarm = Book.create(
            title: "Animal Farm",
            synopsis: "Un'allegoria satirica della Rivoluzione Russa attraverso la storia di animali che si ribellano al loro fattore.",
            pageCount: 112, rating: 4.5,
            publishedDate: Calendar.current.date(from: DateComponents(year: 1945, month: 8, day: 17)),
            author: orwell, in: context
        )
        bookFarm.isRead = true
        bookFarm.addToTags(tagFiction); bookFarm.addToTags(tagClassics)

        let bookFoundation = Book.create(
            title: "Foundation",
            synopsis: "Un matematico scopre che la Galassia è destinata a crollare e lavora per ridurre i millenni bui.",
            pageCount: 255, rating: 4.7,
            publishedDate: Calendar.current.date(from: DateComponents(year: 1951, month: 5, day: 1)),
            author: asimov, in: context
        )
        bookFoundation.isRead = false
        bookFoundation.addToTags(tagSciFi)

        let bookRobots = Book.create(
            title: "I, Robot",
            synopsis: "Raccolta di nove racconti di fantascienza che esplorano la relazione tra esseri umani e robot intelligenti.",
            pageCount: 253, rating: 4.6,
            publishedDate: Calendar.current.date(from: DateComponents(year: 1950, month: 12, day: 2)),
            author: asimov, in: context
        )
        bookRobots.isRead = true
        bookRobots.addToTags(tagSciFi); bookRobots.addToTags(tagTechnology)

        let bookAndroid = Book.create(
            title: "Do Androids Dream of Electric Sheep?",
            synopsis: "In un futuro post-apocalittico, un cacciatore di taglie deve eliminare androidi fuggitivi, mentre si interroga sulla natura dell'empatia.",
            pageCount: 244, rating: 4.4,
            publishedDate: Calendar.current.date(from: DateComponents(year: 1968, month: 3, day: 1)),
            author: pkDick, in: context
        )
        bookAndroid.isRead = false
        bookAndroid.addToTags(tagSciFi); bookAndroid.addToTags(tagPhilosophy)

        let bookHobbit = Book.create(
            title: "The Hobbit",
            synopsis: "Lo hobbit Bilbo Baggins intraprende un'avventura inaspettata con un gruppo di nani per recuperare un tesoro custodito da un drago.",
            pageCount: 310, rating: 4.9,
            publishedDate: Calendar.current.date(from: DateComponents(year: 1937, month: 9, day: 21)),
            author: tolkien, in: context
        )
        bookHobbit.isRead = true
        bookHobbit.addToTags(tagFiction)

        // ── SESSIONI DI LETTURA ──────────────────────────────
        // Sessioni per "Nineteen Eighty-Four" (già letto)
        let s1 = ReadingSession.start(for: book1984, pagesRead: 80, notes: "Primo capitolo assorbente. La lingua neospeak è affascinante.", in: context)
        s1.startDate = Date().addingTimeInterval(-86400 * 14)
        s1.end(pagesRead: 80)
        s1.endDate = s1.startDate.addingTimeInterval(4800)

        let s2 = ReadingSession.start(for: book1984, pagesRead: 120, notes: "La storia d'amore con Julia aggiunge profondità.", in: context)
        s2.startDate = Date().addingTimeInterval(-86400 * 10)
        s2.end(pagesRead: 120)
        s2.endDate = s2.startDate.addingTimeInterval(7200)

        let s3 = ReadingSession.start(for: book1984, pagesRead: 128, notes: "Finale devastante. Un capolavoro assoluto.", in: context)
        s3.startDate = Date().addingTimeInterval(-86400 * 7)
        s3.end(pagesRead: 128)
        s3.endDate = s3.startDate.addingTimeInterval(6600)

        // Sessione per "Animal Farm" (già letto)
        let s4 = ReadingSession.start(for: bookFarm, pagesRead: 112, notes: "Letto in un pomeriggio solo. Allegoria potentissima.", in: context)
        s4.startDate = Date().addingTimeInterval(-86400 * 5)
        s4.end(pagesRead: 112)
        s4.endDate = s4.startDate.addingTimeInterval(5400)

        // Sessioni per "I, Robot" (già letto)
        let s5 = ReadingSession.start(for: bookRobots, pagesRead: 130, notes: "Le tre leggi della robotica sono un'idea brillante.", in: context)
        s5.startDate = Date().addingTimeInterval(-86400 * 3)
        s5.end(pagesRead: 130)
        s5.endDate = s5.startDate.addingTimeInterval(5000)

        let s6 = ReadingSession.start(for: bookRobots, pagesRead: 123, notes: "Il racconto finale è il più toccante.", in: context)
        s6.startDate = Date().addingTimeInterval(-86400 * 2)
        s6.end(pagesRead: 123)
        s6.endDate = s6.startDate.addingTimeInterval(4200)

        // Sessione in corso per "Foundation"
        let s7 = ReadingSession.start(for: bookFoundation, pagesRead: 45, notes: "Appena iniziato, il concetto di psicostoria è intrigante.", in: context)
        s7.startDate = Date().addingTimeInterval(-3600)
        // endDate = nil → sessione ancora in corso

        save()
    }
}
