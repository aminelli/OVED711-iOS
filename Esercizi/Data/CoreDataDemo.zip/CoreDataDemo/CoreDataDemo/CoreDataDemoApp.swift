//
//  CoreDataDemoApp.swift
//  CoreDataDemo
//
//  Punto di ingresso dell'applicazione.
//  Inizializza il PersistenceController e lo inietta nell'ambiente SwiftUI
//  tramite `.environment(\.managedObjectContext, ...)` per renderlo disponibile
//  a tutte le view figlie senza prop-drilling.
//

import SwiftUI
import CoreData

@main
struct CoreDataDemoApp: App {

    // MARK: - Stack Core Data
    /// Usa l'istanza condivisa del controller per i dati reali.
    /// Per preview o test si userebbe `PersistenceController.preview`.
    let persistenceController = PersistenceController.shared

    // MARK: - Scene
    var body: some Scene {
        WindowGroup {
            MainTabView()
                // Inietta il viewContext nell'ambiente SwiftUI.
                // Le view figlie possono accedervi con @Environment(\.managedObjectContext).
                .environment(\.managedObjectContext, persistenceController.viewContext)
        }
    }
}
