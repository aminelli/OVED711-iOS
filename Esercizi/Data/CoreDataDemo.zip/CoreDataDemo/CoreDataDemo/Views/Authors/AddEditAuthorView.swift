//
//  AddEditAuthorView.swift
//  CoreDataDemo
//
//  Form per creare o modificare un autore.
//

import SwiftUI
import CoreData

// MARK: - AddEditAuthorView
struct AddEditAuthorView: View {

    let author: Author?

    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) private var dismiss

    @State private var name         = ""
    @State private var biography    = ""
    @State private var birthDate    = Date()
    @State private var hasBirthDate = false

    @State private var showValidationAlert = false
    @State private var validationMessage   = ""

    init(author: Author? = nil) {
        self.author = author
    }

    var body: some View {
        Form {
            Section("Informazioni autore") {
                TextField("Nome e cognome *", text: $name)
                    .autocorrectionDisabled()

                TextField("Biografia", text: $biography, axis: .vertical)
                    .lineLimit(4...8)
            }

            Section("Data di nascita") {
                Toggle("Specifica data di nascita", isOn: $hasBirthDate)
                if hasBirthDate {
                    DatePicker(
                        "Data",
                        selection: $birthDate,
                        in: ...Date(),
                        displayedComponents: .date
                    )
                    .datePickerStyle(.wheel)
                }
            }
        }
        .navigationTitle(author == nil ? "Nuovo autore" : "Modifica autore")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Annulla") {
                    viewContext.rollback()
                    dismiss()
                }
            }
            ToolbarItem(placement: .confirmationAction) {
                Button("Salva") { saveAuthor() }
                    .fontWeight(.semibold)
            }
        }
        .onAppear { populateFields() }
        .alert("Dati non validi", isPresented: $showValidationAlert) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(validationMessage)
        }
    }

    private func populateFields() {
        guard let author else { return }
        name         = author.name
        biography    = author.biography ?? ""
        if let date = author.birthDate {
            birthDate    = date
            hasBirthDate = true
        }
    }

    private func saveAuthor() {
        let trimmed = name.trimmingCharacters(in: .whitespaces)
        guard !trimmed.isEmpty else {
            validationMessage   = "Il nome dell'autore non può essere vuoto."
            showValidationAlert = true
            return
        }

        let target: Author
        if let existing = author {
            target = existing
        } else {
            target = Author(context: viewContext)
            target.id = UUID()
        }

        target.name       = trimmed
        target.biography  = biography.isEmpty ? nil : biography
        target.birthDate  = hasBirthDate ? birthDate : nil

        do {
            try viewContext.save()
            dismiss()
        } catch {
            validationMessage   = (error as NSError).localizedDescription
            showValidationAlert = true
            viewContext.rollback()
        }
    }
}

#Preview {
    NavigationStack {
        AddEditAuthorView()
    }
    .environment(\.managedObjectContext, PersistenceController.preview.viewContext)
}
