//
//  AuthorsListView.swift
//  CoreDataDemo
//
//  Lista degli autori con sezioni alfabetiche.
//  Dimostra:
//  - @SectionedFetchRequest per raggruppare i risultati per sezione
//  - Navigazione verso il dettaglio autore
//  - Ricerca con NSPredicate dinamico
//

import SwiftUI
import CoreData

// MARK: - AuthorsListView
struct AuthorsListView: View {

    @Environment(\.managedObjectContext) private var viewContext

    // MARK: @SectionedFetchRequest
    /// Raggruppa gli autori per la prima lettera del nome.
    /// `sectionIdentifier` è il keyPath usato per creare le sezioni.
    /// Disponibile da iOS 15 come alternativa a NSFetchedResultsController con sezioni.
    @SectionedFetchRequest<String, Author>(
        sectionIdentifier: \.firstLetter,
        sortDescriptors: [SortDescriptor(\.name, order: .forward)],
        animation: .default
    )
    private var authorSections: SectionedFetchResults<String, Author>

    @State private var searchText  = ""
    @State private var showAddView = false

    var body: some View {
        List {
            ForEach(authorSections) { section in
                Section(header: Text(section.id).font(.headline)) {
                    ForEach(section) { author in
                        NavigationLink(destination: AuthorDetailView(author: author)) {
                            AuthorRowView(author: author)
                        }
                    }
                    .onDelete { offsets in
                        deleteAuthors(section: section, at: offsets)
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("Autori")
        .searchable(text: $searchText, prompt: "Cerca autore...")
        .onChange(of: searchText) { _, new in
            // Aggiorna il predicate della @SectionedFetchRequest in tempo reale
            authorSections.nsPredicate = new.isEmpty
                ? nil
                : NSPredicate(format: "name CONTAINS[cd] %@", new)
        }
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button { showAddView = true } label: {
                    Label("Aggiungi autore", systemImage: "plus")
                }
            }
        }
        .sheet(isPresented: $showAddView) {
            NavigationStack {
                AddEditAuthorView()
            }
        }
        .overlay {
            if authorSections.isEmpty {
                ContentUnavailableView {
                    Label("Nessun autore", systemImage: "person.slash")
                } description: {
                    Text(searchText.isEmpty
                         ? "Tocca + per aggiungere un autore."
                         : "Nessun risultato per \"\(searchText)\".")
                }
            }
        }
    }

    private func deleteAuthors(section: SectionedFetchResults<String, Author>.Section, at offsets: IndexSet) {
        offsets.map { section[$0] }.forEach(viewContext.delete)
        try? viewContext.save()
    }
}

// MARK: - Estensione per Sezioni Alfabetiche
extension Author {
    /// Ritorna la prima lettera maiuscola del nome per usarla come identificatore di sezione.
    /// Proprietà `@objc dynamic` è necessaria perché `@SectionedFetchRequest` usa KVO.
    @objc var firstLetter: String {
        let letter = name.prefix(1).uppercased()
        return letter.isEmpty ? "#" : letter
    }
}

// MARK: - AuthorRowView
struct AuthorRowView: View {
    @ObservedObject var author: Author

    var body: some View {
        HStack(spacing: 12) {
            // Avatar con iniziale
            Circle()
                .fill(LinearGradient(colors: [.indigo, .purple],
                                     startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width: 44, height: 44)
                .overlay {
                    Text(author.name.prefix(1).uppercased())
                        .font(.headline.bold())
                        .foregroundStyle(.white)
                }

            VStack(alignment: .leading, spacing: 2) {
                Text(author.name)
                    .font(.headline)

                HStack(spacing: 4) {
                    Text("\(author.bookCount) libri")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    if author.bookCount > 0 {
                        Text("·")
                            .foregroundStyle(.secondary)
                        Text(String(format: "★ %.1f", author.averageRating))
                            .font(.caption)
                            .foregroundStyle(.orange)
                    }
                }

                // Tags dell'autore (max 3)
                if !author.tagsArray.isEmpty {
                    HStack(spacing: 4) {
                        ForEach(author.tagsArray.prefix(3)) { tag in
                            TagChipView(tag: tag, compact: true)
                        }
                    }
                }
            }
        }
        .padding(.vertical, 2)
    }
}

#Preview {
    NavigationStack {
        AuthorsListView()
    }
    .environment(\.managedObjectContext, PersistenceController.preview.viewContext)
}
