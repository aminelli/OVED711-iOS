//
//  AuthorDetailView.swift
//  CoreDataDemo
//
//  Dettaglio di un autore con la lista dei suoi libri.
//  Dimostra la navigazione nelle relazioni Core Data.
//

import SwiftUI
import CoreData

// MARK: - AuthorDetailView
struct AuthorDetailView: View {

    @ObservedObject var author: Author
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) private var dismiss

    @State private var showEditAuthor    = false
    @State private var showDeleteConfirm = false
    @State private var showAddBook       = false

    var body: some View {
        List {
            // ── Sezione Profilo ───────────────────────────
            Section {
                authorHeaderView
            }

            // ── Sezione Statistiche ───────────────────────
            Section("Statistiche") {
                StatRowView(label: "Libri in biblioteca", value: "\(author.bookCount)")
                StatRowView(label: "Libri letti",         value: "\(author.readBooksCount)")
                StatRowView(label: "Rating medio",        value: String(format: "%.1f ★", author.averageRating))
                StatRowView(label: "Data di nascita",     value: author.formattedBirthDate)
            }

            // ── Sezione Tags ──────────────────────────────
            if !author.tagsArray.isEmpty {
                Section("Generi") {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(author.tagsArray) { tag in
                                TagChipView(tag: tag, compact: false)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                    .listRowInsets(EdgeInsets(top: 0, leading: 16, bottom: 0, trailing: 0))
                }
            }

            // ── Sezione Libri ─────────────────────────────
            // Accesso diretto alla relazione author → books
            Section {
                if author.booksArray.isEmpty {
                    Text("Nessun libro associato a questo autore.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(author.booksArray) { book in
                        NavigationLink(destination: BookDetailView(book: book)) {
                            BookRowView(book: book)
                        }
                    }
                }
            } header: {
                HStack {
                    Text("Libri (\(author.bookCount))")
                    Spacer()
                    Button {
                        showAddBook = true
                    } label: {
                        Image(systemName: "plus.circle.fill")
                    }
                    .buttonStyle(.plain)
                    .foregroundStyle(.blue)
                }
            }

            // ── Sezione Azioni ────────────────────────────
            Section {
                Button(role: .destructive) {
                    showDeleteConfirm = true
                } label: {
                    Label("Elimina autore", systemImage: "trash")
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle(author.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button("Modifica") { showEditAuthor = true }
            }
        }
        .sheet(isPresented: $showEditAuthor) {
            NavigationStack {
                AddEditAuthorView(author: author)
            }
        }
        .sheet(isPresented: $showAddBook) {
            NavigationStack {
                AddEditBookView()
                    .onAppear {
                        // Pre-seleziona l'autore corrente per il nuovo libro
                        // (gestito tramite binding nell'AddEditBookView)
                    }
            }
        }
        .confirmationDialog(
            "Eliminare \"\(author.name)\"?",
            isPresented: $showDeleteConfirm,
            titleVisibility: .visible
        ) {
            Button("Elimina", role: .destructive) {
                deleteAuthor()
            }
            Button("Annulla", role: .cancel) {}
        } message: {
            Text("Verranno eliminati anche tutti i suoi libri e le relative sessioni di lettura (cascata).")
        }
    }

    // MARK: - Componenti UI

    private var authorHeaderView: some View {
        HStack(spacing: 16) {
            // Avatar grande
            Circle()
                .fill(LinearGradient(colors: [.indigo, .purple],
                                     startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width: 70, height: 70)
                .overlay {
                    Text(author.name.prefix(1).uppercased())
                        .font(.largeTitle.bold())
                        .foregroundStyle(.white)
                }

            VStack(alignment: .leading, spacing: 4) {
                Text(author.name)
                    .font(.title3.bold())

                if let bio = author.biography, !bio.isEmpty {
                    Text(bio)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(3)
                }
            }
        }
        .padding(.vertical, 4)
    }

    // MARK: - Azioni

    private func deleteAuthor() {
        // Core Data elimina a cascata i libri e le sessioni (configurato nel modello)
        viewContext.delete(author)
        do {
            try viewContext.save()
            dismiss()
        } catch {
            print("Errore eliminazione autore: \(error)")
        }
    }
}

#Preview {
    let controller = PersistenceController.preview
    let author = try! controller.viewContext.fetch(Author.fetchRequest()).first!
    return NavigationStack {
        AuthorDetailView(author: author)
    }
    .environment(\.managedObjectContext, controller.viewContext)
}
