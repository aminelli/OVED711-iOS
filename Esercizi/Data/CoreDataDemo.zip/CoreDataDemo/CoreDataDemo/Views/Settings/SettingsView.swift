//
//  SettingsView.swift
//  CoreDataDemo
//
//  Vista impostazioni e demo avanzate Core Data.
//  Dimostra:
//  - Undo / Redo tramite UndoManager del viewContext
//  - Batch Delete (elimina tutti i record di un'entità)
//  - Batch Insert (inserisce molti record in un colpo solo)
//  - Operazioni su context di background
//  - Ispezione del persistent store (URL, tipo)
//  - Reset del database
//

import SwiftUI
import CoreData

// MARK: - SettingsView
struct SettingsView: View {

    @Environment(\.managedObjectContext) private var viewContext

    // MARK: Stato
    @State private var showResetConfirm     = false
    @State private var showBatchInsertAlert = false
    @State private var batchInsertCount     = 0
    @State private var operationMessage     = ""
    @State private var showOperationResult  = false
    @State private var isProcessing         = false

    // Contatori per verificare gli effetti delle operazioni
    @State private var bookCount    = 0
    @State private var authorCount  = 0
    @State private var sessionCount = 0

    let persistence = PersistenceController.shared

    var body: some View {
        List {
            // ── Sezione Undo/Redo ─────────────────────────
            undoRedoSection

            // ── Sezione Batch Operations ──────────────────
            batchOperationsSection

            // ── Sezione Background Context ────────────────
            backgroundSection

            // ── Sezione Informazioni Store ────────────────
            storeInfoSection

            // ── Sezione Pericolosa ────────────────────────
            dangerSection
        }
        .listStyle(.insetGrouped)
        .navigationTitle("Impostazioni & Demo")
        .onAppear { refreshCounts() }
        .alert("Operazione completata", isPresented: $showOperationResult) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(operationMessage)
        }
        .confirmationDialog(
            "Reset database",
            isPresented: $showResetConfirm,
            titleVisibility: .visible
        ) {
            Button("Elimina tutto", role: .destructive) {
                resetDatabase()
            }
            Button("Annulla", role: .cancel) {}
        } message: {
            Text("Verranno eliminati TUTTI i libri, gli autori, i tag e le sessioni di lettura. Questa operazione non può essere annullata.")
        }
    }

    // MARK: - Sezioni

    private var undoRedoSection: some View {
        Section {
            // Stato corrente dell'UndoManager
            HStack {
                Label("UndoManager attivo", systemImage: "arrow.uturn.backward.circle.fill")
                    .foregroundStyle(.blue)
                Spacer()
                Image(systemName: "checkmark.circle.fill")
                    .foregroundStyle(.green)
            }

            // Pulsante Annulla
            Button {
                persistence.undo()
                refreshCounts()
                showMessage("Operazione annullata (Undo eseguito).")
            } label: {
                Label("Annulla ultima operazione", systemImage: "arrow.uturn.backward")
            }
            .disabled(!persistence.canUndo)

            // Pulsante Ripeti
            Button {
                persistence.redo()
                refreshCounts()
                showMessage("Operazione ripetuta (Redo eseguito).")
            } label: {
                Label("Ripeti operazione annullata", systemImage: "arrow.uturn.forward")
            }
            .disabled(!persistence.canRedo)
        } header: {
            Text("Undo / Redo")
        } footer: {
            Text("Il viewContext ha un UndoManager attivo. Dopo ogni modifica puoi annullarla o ripeterla. Funziona con Cmd+Z su simulator.")
        }
    }

    private var batchOperationsSection: some View {
        Section {
            // Contatori correnti
            HStack {
                Label("Libri nel DB:", systemImage: "book")
                Spacer()
                Text("\(bookCount)").bold().foregroundStyle(.blue)
            }
            HStack {
                Label("Autori nel DB:", systemImage: "person")
                Spacer()
                Text("\(authorCount)").bold().foregroundStyle(.purple)
            }
            HStack {
                Label("Sessioni nel DB:", systemImage: "clock")
                Spacer()
                Text("\(sessionCount)").bold().foregroundStyle(.green)
            }

            // Batch Insert
            Button {
                performBatchInsert()
            } label: {
                HStack {
                    Label("Batch Insert 50 libri", systemImage: "arrow.down.doc.fill")
                    if isProcessing {
                        Spacer()
                        ProgressView()
                    }
                }
            }
            .disabled(isProcessing)

            // Batch Delete libri senza autore
            Button(role: .destructive) {
                batchDeleteOrphanBooks()
            } label: {
                Label("Batch Delete libri senza autore", systemImage: "trash.fill")
            }
            .disabled(isProcessing)

        } header: {
            Text("Batch Operations")
        } footer: {
            Text("NSBatchInsertRequest e NSBatchDeleteRequest lavorano direttamente sul SQLite store, bypassando il context. Sono ordini di grandezza più veloci per set di dati grandi.")
        }
    }

    private var backgroundSection: some View {
        Section {
            Button {
                performBackgroundOperation()
            } label: {
                HStack {
                    Label("Operazione Background", systemImage: "gearshape.2.fill")
                    if isProcessing {
                        Spacer()
                        ProgressView()
                    }
                }
            }
            .disabled(isProcessing)

        } header: {
            Text("Context Background")
        } footer: {
            Text("Usa Task + NSManagedObjectContext.perform(_:) per eseguire operazioni Core Data in background con Swift Concurrency. Dopo ogni `await` il Task ritorna su @MainActor automaticamente.")
        }
    }

    private var storeInfoSection: some View {
        Section("Informazioni Persistent Store") {
            if let storeURL = persistence.container.persistentStoreCoordinator
                .persistentStores.first?.url {
                VStack(alignment: .leading, spacing: 4) {
                    Text("URL Store")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Text(storeURL.lastPathComponent)
                        .font(.system(.caption, design: .monospaced))
                        .foregroundStyle(.primary)
                    Text(storeURL.deletingLastPathComponent().path)
                        .font(.system(.caption2, design: .monospaced))
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                }

                let storeType = persistence.container.persistentStoreCoordinator
                    .persistentStores.first?.type ?? "N/D"
                StatRowView(label: "Tipo store", value: storeType == "SQLite" ? "SQLite ✓" : storeType)

                StatRowView(
                    label: "Merge Policy",
                    value: "NSMergeByPropertyObjectTrump"
                )

                StatRowView(
                    label: "Auto-merge background",
                    value: "Attivo ✓"
                )

                StatRowView(
                    label: "Persistent History",
                    value: "Attivo ✓"
                )
            }
        }
    }

    private var dangerSection: some View {
        Section {
            Button(role: .destructive) {
                showResetConfirm = true
            } label: {
                Label("Reset completo database", systemImage: "exclamationmark.triangle.fill")
            }
        } header: {
            Text("Zona pericolosa")
        } footer: {
            Text("Il reset usa NSBatchDeleteRequest su tutte le entità e non può essere annullato con Undo.")
        }
    }

    // MARK: - Operazioni Core Data

    /// Aggiorna i contatori visualizzati.
    private func refreshCounts() {
        bookCount    = persistence.count(entityName: "Book")
        authorCount  = persistence.count(entityName: "Author")
        sessionCount = persistence.count(entityName: "ReadingSession")
    }

    /// Inserisce 50 libri dummy usando NSBatchInsertRequest.
    /// Dimostra come importare grandi quantità di dati in modo efficiente.
    private func performBatchInsert() {
        isProcessing = true

        // Prepara i dati da inserire come array di dizionari
        var bookDicts: [[String: Any]] = []
        for i in 1...50 {
            bookDicts.append([
                "id":         UUID(),
                "title":      "Libro Generato #\(bookCount + i)",
                "pageCount":  Int32.random(in: 100...800),
                "rating":     Double.random(in: 1.0...5.0),
                "isRead":     Bool.random(),
                "synopsis":   "Libro inserito con NSBatchInsertRequest per test performance."
            ])
        }

        // NSBatchInsertRequest non passa per il context: è molto più veloce
        persistence.batchInsert(entityName: "Book", objects: bookDicts)

        refreshCounts()
        isProcessing = false
        showMessage("Batch Insert completato: 50 libri inseriti.\nTotale libri: \(bookCount)")
    }

    /// Elimina tutti i libri senza autore usando NSBatchDeleteRequest con predicato.
    private func batchDeleteOrphanBooks() {
        isProcessing = true

        // Predicato: libri la cui relazione "author" è nil
        let predicate = NSPredicate(format: "author == nil")
        persistence.batchDelete(entityName: "Book", predicate: predicate)

        refreshCounts()
        isProcessing = false
        showMessage("Batch Delete completato: eliminati tutti i libri senza autore.\nLibri rimasti: \(bookCount)")
    }

    /// Dimostra l'uso di un context di background con Swift Concurrency.
    ///
    /// PERCHÉ async/await invece di DispatchQueue.main.async:
    /// In Swift 6 strict concurrency, `DispatchQueue.main.async { self... }` dentro una
    /// closure non-isolated causa errori di tipo "Main actor-isolated property cannot be
    /// mutated from a non-isolated context". `Task { }` eredita l'attore del chiamante
    /// (@MainActor), quindi dopo ogni `await` si ritorna automaticamente su @MainActor.
    private func performBackgroundOperation() {
        isProcessing = true

        // Task eredita @MainActor dal contesto del chiamante (SettingsView è @MainActor).
        // Possiamo usare `await` per sospendere su thread background e riprendere su @MainActor.
        Task {
            let bgContext = PersistenceController.shared.newBackgroundContext()
            var resultMessage = ""

            do {
                // NSManagedObjectContext.perform(_:) è async dal iOS 15:
                // sospende il Task, esegue il blocco sulla coda del context, poi riprende.
                let updatedCount = try await bgContext.perform {
                    let request = Book.fetchRequest()
                    request.predicate = NSPredicate(format: "synopsis == nil")
                    request.fetchLimit = 10

                    let booksToUpdate = try bgContext.fetch(request)
                    for book in booksToUpdate {
                        book.synopsis = "Sinossi aggiornata in background alle \(Date().formatted(date: .omitted, time: .shortened))."
                    }
                    if bgContext.hasChanges {
                        try bgContext.save()
                        // Il viewContext si aggiorna automaticamente (automaticallyMergesChangesFromParent)
                    }
                    return booksToUpdate.count
                }
                resultMessage = "Operazione background completata: \(updatedCount) libri aggiornati."
            } catch {
                resultMessage = "Errore operazione background: \(error.localizedDescription)"
            }

            // Qui siamo tornati su @MainActor: è sicuro accedere a @State e chiamare metodi
            self.isProcessing = false
            self.showMessage(resultMessage)
            self.refreshCounts()
        }
    }

    /// Elimina tutti i record del database usando batch delete su ogni entità.
    private func resetDatabase() {
        // Elimina in ordine per rispettare le dipendenze (foglie prima)
        persistence.batchDelete(entityName: "ReadingSession")
        persistence.batchDelete(entityName: "Book")
        persistence.batchDelete(entityName: "Author")
        persistence.batchDelete(entityName: "Tag")

        refreshCounts()
        showMessage("Database resettato. Tutte le entità sono state eliminate.")
    }

    private func showMessage(_ message: String) {
        operationMessage    = message
        showOperationResult = true
    }
}

#Preview {
    NavigationStack {
        SettingsView()
    }
    .environment(\.managedObjectContext, PersistenceController.preview.viewContext)
}
