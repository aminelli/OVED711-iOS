//
//  BookDetailView.swift
//  CoreDataDemo
//
//  Dettaglio di un libro con le sue sessioni di lettura.
//  Dimostra:
//  - Navigazione nelle relazioni Core Data (book → sessions, book → author)
//  - Aggiornamento in-place di attributi
//  - Gestione sessioni di lettura (relazione uno-a-molti)
//  - @NSFetchedResultsController via @FetchRequest filtrato per libro
//

import SwiftUI
import CoreData

// MARK: - BookDetailView
struct BookDetailView: View {

    // MARK: Dipendenze
    @ObservedObject var book: Book
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) private var dismiss

    // MARK: Stato Locale
    @State private var showEditBook         = false
    @State private var showAddSession       = false
    @State private var showDeleteConfirm    = false

    var body: some View {
        List {
            // ── Sezione Intestazione ──────────────────────
            Section {
                bookHeaderView
            }

            // ── Sezione Autore ────────────────────────────
            if let author = book.author {
                Section("Autore") {
                    NavigationLink(destination: AuthorDetailView(author: author)) {
                        HStack {
                            Image(systemName: "person.circle.fill")
                                .font(.title2)
                                .foregroundStyle(.blue)
                            VStack(alignment: .leading) {
                                Text(author.name)
                                    .font(.headline)
                                Text("\(author.bookCount) libri in biblioteca")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                }
            }

            // ── Sezione Tag ───────────────────────────────
            if !book.tagsArray.isEmpty {
                Section("Categorie") {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(book.tagsArray) { tag in
                                TagChipView(tag: tag, compact: false)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                    .listRowInsets(EdgeInsets(top: 0, leading: 16, bottom: 0, trailing: 0))
                }
            }

            // ── Sezione Progressione Lettura ──────────────
            Section("Progressione") {
                readingProgressView
            }

            // ── Sezione Sessioni di Lettura ───────────────
            // Dimostra accesso alla relazione uno-a-molti book → readingSessions
            Section {
                if book.readingSessionsArray.isEmpty {
                    Text("Nessuna sessione registrata.")
                        .foregroundStyle(.secondary)
                        .font(.subheadline)
                } else {
                    ForEach(book.readingSessionsArray) { session in
                        ReadingSessionRowView(session: session)
                    }
                    .onDelete(perform: deleteSessions)
                }
            } header: {
                HStack {
                    Text("Sessioni di lettura (\(book.readingSessionsArray.count))")
                    Spacer()
                    Button {
                        showAddSession = true
                    } label: {
                        Image(systemName: "plus.circle.fill")
                    }
                    .buttonStyle(.plain)
                    .foregroundStyle(.blue)
                }
            }

            // ── Sezione Statistiche Lettura ───────────────
            if !book.readingSessionsArray.isEmpty {
                Section("Statistiche lettura") {
                    readingStatsView
                }
            }

            // ── Sezione Azioni Pericolose ─────────────────
            Section {
                Button(role: .destructive) {
                    showDeleteConfirm = true
                } label: {
                    Label("Elimina libro", systemImage: "trash")
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle(book.title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button("Modifica") {
                    showEditBook = true
                }
            }
        }
        .sheet(isPresented: $showEditBook) {
            NavigationStack {
                AddEditBookView(book: book)
            }
        }
        .sheet(isPresented: $showAddSession) {
            NavigationStack {
                AddReadingSessionView(book: book)
            }
        }
        .confirmationDialog(
            "Eliminare \"\(book.title)\"?",
            isPresented: $showDeleteConfirm,
            titleVisibility: .visible
        ) {
            Button("Elimina", role: .destructive) {
                deleteBook()
            }
            Button("Annulla", role: .cancel) {}
        } message: {
            Text("L'operazione non può essere annullata. Verranno eliminate anche tutte le sessioni di lettura.")
        }
    }

    // MARK: - Componenti UI

    private var bookHeaderView: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top) {
                // Placeholder copertina
                RoundedRectangle(cornerRadius: 8)
                    .fill(LinearGradient(colors: [.blue.opacity(0.6), .purple.opacity(0.6)],
                                        startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 70, height: 100)
                    .overlay {
                        Image(systemName: "book.closed.fill")
                            .font(.largeTitle)
                            .foregroundStyle(.white)
                    }

                VStack(alignment: .leading, spacing: 6) {
                    Text(book.title)
                        .font(.title3.bold())

                    // Rating interattivo con stelle
                    HStack(spacing: 4) {
                        ForEach(1...5, id: \.self) { star in
                            Image(systemName: Double(star) <= book.rating ? "star.fill" : "star")
                                .foregroundStyle(.orange)
                                .onTapGesture {
                                    updateRating(Double(star))
                                }
                        }
                        Text(String(format: "%.1f", book.rating))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    if book.publishedDate != nil {
                        Label(book.publicationYear, systemImage: "calendar")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    Label("\(book.pageCount) pagine", systemImage: "doc.text")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(.leading, 8)
            }

            if let synopsis = book.synopsis, !synopsis.isEmpty {
                Divider()
                Text(synopsis)
                    .font(.body)
                    .foregroundStyle(.primary)
            }

            // Toggle stato lettura - aggiorna Core Data in tempo reale
            Toggle(isOn: Binding(
                get: { book.isRead },
                set: { newValue in
                    book.isRead = newValue
                    try? viewContext.save()
                }
            )) {
                Label(book.isRead ? "Libro letto ✓" : "Da leggere", systemImage: book.statusIcon)
                    .foregroundStyle(book.isRead ? .green : .secondary)
            }
        }
        .padding(.vertical, 4)
    }

    private var readingProgressView: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("\(book.totalPagesRead) / \(book.pageCount) pagine")
                    .font(.subheadline)
                Spacer()
                Text(String(format: "%.0f%%", book.readingProgress * 100))
                    .font(.subheadline.bold())
                    .foregroundStyle(.blue)
            }

            ProgressView(value: book.readingProgress)
                .tint(book.isRead ? .green : .blue)
                .scaleEffect(x: 1, y: 1.5)

            if book.totalReadingDuration > 0 {
                Label("Tempo totale: \(book.formattedTotalReadingTime)",
                      systemImage: "clock")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 4)
    }

    private var readingStatsView: some View {
        VStack(spacing: 8) {
            let sessions = book.readingSessionsArray
            let completedSessions = sessions.filter { !$0.isInProgress }
            let avgPages = completedSessions.isEmpty ? 0 :
                Double(sessions.reduce(0) { $0 + $1.pagesRead }) / Double(completedSessions.count)
            let avgSpeed = completedSessions.isEmpty ? 0 :
                completedSessions.reduce(0) { $0 + $1.readingSpeedPagesPerHour } / Double(completedSessions.count)

            StatRowView(label: "Sessioni completate", value: "\(completedSessions.count)")
            StatRowView(label: "Media pagine/sessione", value: String(format: "%.0f", avgPages))
            StatRowView(label: "Velocità media", value: String(format: "%.0f pag/h", avgSpeed))
        }
    }

    // MARK: - Azioni

    /// Aggiorna il rating del libro salvando immediatamente nel persistent store.
    private func updateRating(_ newRating: Double) {
        book.rating = newRating
        try? viewContext.save()
    }

    /// Elimina le sessioni selezionate (swipe-to-delete dalla lista sessioni).
    private func deleteSessions(at offsets: IndexSet) {
        let sessionsToDelete = offsets.map { book.readingSessionsArray[$0] }
        sessionsToDelete.forEach(viewContext.delete)
        try? viewContext.save()
    }

    /// Elimina il libro corrente e torna alla lista.
    private func deleteBook() {
        viewContext.delete(book)
        do {
            try viewContext.save()
            dismiss()
        } catch {
            print("Errore eliminazione libro: \(error)")
        }
    }
}

// MARK: - ReadingSessionRowView
/// Riga compatta per una sessione di lettura.
struct ReadingSessionRowView: View {
    @ObservedObject var session: ReadingSession

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                // Badge "In corso" se la sessione è attiva
                if session.isInProgress {
                    Label("In corso", systemImage: "circle.fill")
                        .font(.caption.bold())
                        .foregroundStyle(.orange)
                } else {
                    Text(session.formattedStartDate)
                        .font(.subheadline.bold())
                }
                Spacer()
                Text("\(session.pagesRead) pag.")
                    .font(.subheadline)
                    .foregroundStyle(.blue)
            }

            HStack {
                Label(session.formattedDuration, systemImage: "clock")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                if !session.isInProgress {
                    Text("·")
                        .foregroundStyle(.secondary)
                    Text(String(format: "%.0f pag/h", session.readingSpeedPagesPerHour))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            if let notes = session.notes, !notes.isEmpty {
                Text(notes)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
                    .italic()
            }
        }
        .padding(.vertical, 2)
    }
}

// MARK: - StatRowView
/// Riga semplice label + valore per le statistiche.
struct StatRowView: View {
    let label: String
    let value: String

    var body: some View {
        HStack {
            Text(label)
                .foregroundStyle(.secondary)
            Spacer()
            Text(value)
                .bold()
        }
        .font(.subheadline)
    }
}

#Preview {
    let controller = PersistenceController.preview
    let book = try! controller.viewContext.fetch(Book.fetchRequest()).first!
    return NavigationStack {
        BookDetailView(book: book)
    }
    .environment(\.managedObjectContext, controller.viewContext)
}
