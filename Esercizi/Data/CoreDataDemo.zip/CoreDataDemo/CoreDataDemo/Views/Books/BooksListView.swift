//
//  BooksListView.swift
//  CoreDataDemo
//
//  Lista principale dei libri con ricerca, filtro e ordinamento.
//  Dimostra:
//  - @FetchRequest con SortDescriptor e NSPredicate dinamici
//  - Modifica del fetch request in runtime (sort/filter)
//  - Swipe-to-delete
//  - Navigazione verso il dettaglio
//

import SwiftUI
import CoreData

// MARK: - Opzioni di Ordinamento
/// Enum che rappresenta i criteri disponibili per ordinare i libri.
enum BookSortOption: String, CaseIterable, Identifiable {
    case titleAsc    = "Titolo (A→Z)"
    case titleDesc   = "Titolo (Z→A)"
    case ratingDesc  = "Rating (decrescente)"
    case dateDesc    = "Data pubblicazione (recente)"
    case pageCount   = "Numero pagine"

    var id: String { rawValue }
}

// MARK: - BooksListView
/// Vista principale della libreria libri.
struct BooksListView: View {

    // MARK: Ambiente
    @Environment(\.managedObjectContext) private var viewContext

    // MARK: @FetchRequest
    /// @FetchRequest è il modo dichiarativo SwiftUI per eseguire fetch Core Data.
    /// Aggiorna automaticamente la view quando i dati cambiano nel persistent store.
    @FetchRequest(
        sortDescriptors: [SortDescriptor(\.title, order: .forward)],
        animation: .default
    )
    private var books: FetchedResults<Book>

    // MARK: Stato Locale
    @State private var searchText       = ""
    @State private var sortOption       = BookSortOption.titleAsc
    @State private var filterReadStatus = FilterStatus.all
    @State private var showAddBook      = false

    // MARK: - Corpo
    var body: some View {
        List {
            // ── Sezione filtri rapidi ──────────────────────
            filterSection

            // ── Lista libri filtrata ───────────────────────
            if books.isEmpty {
                emptyStateView
            } else {
                ForEach(books) { book in
                    NavigationLink(destination: BookDetailView(book: book)) {
                        BookRowView(book: book)
                    }
                }
                .onDelete(perform: deleteBooks)
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("Libreria")
        .navigationBarTitleDisplayMode(.large)
        .searchable(
            text: $searchText,
            placement: .navigationBarDrawer(displayMode: .always),
            prompt: "Cerca per titolo o autore..."
        )
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button { showAddBook = true } label: {
                    Label("Aggiungi libro", systemImage: "plus")
                }
            }
            ToolbarItem(placement: .topBarLeading) {
                sortMenu
            }
        }
        .sheet(isPresented: $showAddBook) {
            NavigationStack {
                AddEditBookView()
            }
        }
        // Aggiorna il fetch request ogni volta che cambiano ricerca, sort o filtro
        .onChange(of: searchText)      { _, _ in updateFetchRequest() }
        .onChange(of: sortOption)      { _, _ in updateFetchRequest() }
        .onChange(of: filterReadStatus){ _, _ in updateFetchRequest() }
    }

    // MARK: - Componenti UI

    private var filterSection: some View {
        Section {
            Picker("Stato lettura", selection: $filterReadStatus) {
                ForEach(FilterStatus.allCases) { status in
                    Text(status.label).tag(status)
                }
            }
            .pickerStyle(.segmented)
        }
        .listRowBackground(Color.clear)
        .listRowInsets(EdgeInsets(top: 4, leading: 0, bottom: 4, trailing: 0))
    }

    private var sortMenu: some View {
        Menu {
            Picker("Ordina per", selection: $sortOption) {
                ForEach(BookSortOption.allCases) { option in
                    Text(option.rawValue).tag(option)
                }
            }
        } label: {
            Label("Ordina", systemImage: "arrow.up.arrow.down")
        }
    }

    private var emptyStateView: some View {
        ContentUnavailableView {
            Label("Nessun libro trovato", systemImage: "books.vertical")
        } description: {
            if !searchText.isEmpty {
                Text("Nessun risultato per \"\(searchText)\"")
            } else {
                Text("Tocca + per aggiungere il primo libro.")
            }
        }
        .listRowBackground(Color.clear)
    }

    // MARK: - Logica Core Data

    /// Aggiorna dinamicamente il fetch request con i nuovi predicati e sort.
    /// Questo è un pattern avanzato: modifica `NSFetchRequest` in runtime
    /// invece di ricreare la view o usare filtri in memoria.
    private func updateFetchRequest() {
        // ── Sort descriptors ──────────────────────────────
        let sortDescriptors: [SortDescriptor<Book>]
        switch sortOption {
        case .titleAsc:
            sortDescriptors = [SortDescriptor(\.title, order: .forward)]
        case .titleDesc:
            sortDescriptors = [SortDescriptor(\.title, order: .reverse)]
        case .ratingDesc:
            sortDescriptors = [SortDescriptor(\.rating, order: .reverse)]
        case .dateDesc:
            sortDescriptors = [SortDescriptor(\.publishedDate, order: .reverse)]
        case .pageCount:
            sortDescriptors = [SortDescriptor(\.pageCount, order: .reverse)]
        }
        books.sortDescriptors = sortDescriptors

        // ── Predicati (NSPredicate) ───────────────────────
        var predicates: [NSPredicate] = []

        // Filtro per testo di ricerca: cerca nel titolo O nel nome dell'autore
        if !searchText.isEmpty {
            let titlePredicate  = NSPredicate(format: "title CONTAINS[cd] %@", searchText)
            let authorPredicate = NSPredicate(format: "author.name CONTAINS[cd] %@", searchText)
            // NSCompoundPredicate con OR: almeno una delle condizioni deve essere vera
            predicates.append(NSCompoundPredicate(orPredicateWithSubpredicates: [titlePredicate, authorPredicate]))
        }

        // Filtro per stato lettura
        switch filterReadStatus {
        case .read:    predicates.append(NSPredicate(format: "isRead == YES"))
        case .unread:  predicates.append(NSPredicate(format: "isRead == NO"))
        case .all:     break
        }

        // Combina tutti i predicati con AND (tutte le condizioni devono essere vere)
        books.nsPredicate = predicates.isEmpty
            ? nil
            : NSCompoundPredicate(andPredicateWithSubpredicates: predicates)
    }

    /// Elimina i libri selezionati (chiamato dallo swipe-to-delete).
    private func deleteBooks(at offsets: IndexSet) {
        // Raggruppa le eliminazioni in un gruppo undo con nome descrittivo
        viewContext.undoManager?.beginUndoGrouping()
        viewContext.undoManager?.setActionName("Elimina libro")

        offsets.map { books[$0] }.forEach(viewContext.delete)

        do {
            try viewContext.save()
        } catch {
            print("Errore eliminazione libro: \(error)")
        }

        viewContext.undoManager?.endUndoGrouping()
    }
}

// MARK: - Filtro Stato Lettura
enum FilterStatus: String, CaseIterable, Identifiable {
    case all    = "Tutti"
    case read   = "Letti"
    case unread = "Da leggere"

    var id: String { rawValue }
    var label: String { rawValue }
}

// MARK: - BookRowView
/// Riga compatta per la lista libri.
struct BookRowView: View {
    let book: Book

    var body: some View {
        HStack(spacing: 12) {
            // Icona di stato lettura
            Image(systemName: book.statusIcon)
                .font(.title2)
                .foregroundStyle(book.isRead ? .green : (book.totalPagesRead > 0 ? .orange : .secondary))
                .frame(width: 32)

            VStack(alignment: .leading, spacing: 3) {
                Text(book.title)
                    .font(.headline)
                    .lineLimit(1)

                if let authorName = book.author?.name {
                    Text(authorName)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                HStack(spacing: 6) {
                    // Rating con stelle
                    Text(book.ratingDescription)
                        .font(.caption)
                        .foregroundStyle(.orange)

                    Text("·")
                        .foregroundStyle(.secondary)

                    Text("\(book.pageCount) pag.")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    // Tag chips (max 2 visualizzati)
                    ForEach(book.tagsArray.prefix(2)) { tag in
                        TagChipView(tag: tag, compact: true)
                    }
                }
            }
        }
        .padding(.vertical, 2)
    }
}

#Preview {
    NavigationStack {
        BooksListView()
    }
    .environment(\.managedObjectContext, PersistenceController.preview.viewContext)
}
