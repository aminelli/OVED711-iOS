//
//  AddEditBookView.swift
//  CoreDataDemo
//
//  Form per creare o modificare un libro.
//  Dimostra:
//  - Creazione e modifica di NSManagedObject nel viewContext
//  - Gestione della relazione book → author tramite picker
//  - Gestione della relazione book → tags (molti-a-molti)
//  - Validazione dell'input prima del salvataggio
//  - Rollback del context in caso di annullamento (context.rollback())
//

import SwiftUI
import CoreData

// MARK: - AddEditBookView
struct AddEditBookView: View {

    // MARK: Modalità: nuovo o modifica
    /// Se `book` è nil, stiamo creando un nuovo libro.
    /// Se `book` è valorizzato, stiamo modificando un libro esistente.
    let book: Book?

    // MARK: Ambiente
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) private var dismiss

    // MARK: Fetch per i picker
    @FetchRequest(
        sortDescriptors: [SortDescriptor(\.name)],
        animation: .none
    )
    private var authors: FetchedResults<Author>

    @FetchRequest(
        sortDescriptors: [SortDescriptor(\.name)],
        animation: .none
    )
    private var allTags: FetchedResults<Tag>

    // MARK: Stato del form
    @State private var title        = ""
    @State private var synopsis     = ""
    @State private var pageCount    = ""
    @State private var rating       = 3.0
    @State private var isRead       = false
    @State private var publishedDate: Date = Date()
    @State private var hasPublishedDate = false
    @State private var selectedAuthor: Author?
    @State private var selectedTags: Set<Tag> = []

    // MARK: Validazione
    @State private var showValidationAlert = false
    @State private var validationMessage   = ""

    // MARK: Init
    init(book: Book? = nil) {
        self.book = book
    }

    var body: some View {
        Form {
            // ── Sezione Informazioni Base ─────────────────
            Section("Informazioni libro") {
                TextField("Titolo *", text: $title)
                    .autocorrectionDisabled()

                TextField("Sinossi", text: $synopsis, axis: .vertical)
                    .lineLimit(3...6)
            }

            // ── Sezione Dettagli ──────────────────────────
            Section("Dettagli") {
                HStack {
                    Text("Pagine")
                    Spacer()
                    TextField("es. 320", text: $pageCount)
                        .keyboardType(.numberPad)
                        .multilineTextAlignment(.trailing)
                        .frame(width: 80)
                }

                VStack(alignment: .leading) {
                    Text("Rating: \(String(format: "%.1f", rating)) ★")
                    Slider(value: $rating, in: 0...5, step: 0.5)
                        .tint(.orange)
                }

                Toggle("Libro letto", isOn: $isRead)

                Toggle("Data di pubblicazione", isOn: $hasPublishedDate)
                if hasPublishedDate {
                    DatePicker(
                        "Data",
                        selection: $publishedDate,
                        in: ...Date(),
                        displayedComponents: .date
                    )
                    .datePickerStyle(.compact)
                }
            }

            // ── Sezione Autore ────────────────────────────
            // Picker per la relazione molti-a-uno book → author
            Section("Autore") {
                if authors.isEmpty {
                    Text("Nessun autore disponibile. Aggiungine uno prima.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                } else {
                    Picker("Seleziona autore", selection: $selectedAuthor) {
                        Text("Nessuno").tag(Optional<Author>.none)
                        ForEach(authors) { author in
                            Text(author.name).tag(Optional(author))
                        }
                    }
                }
            }

            // ── Sezione Tag ───────────────────────────────
            // Multi-selezione per la relazione molti-a-molti book → tags
            if !allTags.isEmpty {
                Section("Categorie (molti-a-molti)") {
                    ForEach(allTags) { tag in
                        HStack {
                            Circle()
                                .fill(tag.color)
                                .frame(width: 12, height: 12)
                            Text(tag.name)
                            Spacer()
                            if selectedTags.contains(tag) {
                                Image(systemName: "checkmark")
                                    .foregroundStyle(.blue)
                            }
                        }
                        .contentShape(Rectangle())
                        .onTapGesture {
                            toggleTag(tag)
                        }
                    }
                }
            }
        }
        .navigationTitle(book == nil ? "Nuovo libro" : "Modifica libro")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Annulla") {
                    cancelEdit()
                }
            }
            ToolbarItem(placement: .confirmationAction) {
                Button("Salva") {
                    saveBook()
                }
                .fontWeight(.semibold)
            }
        }
        .onAppear {
            populateFields()
        }
        .alert("Dati non validi", isPresented: $showValidationAlert) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(validationMessage)
        }
    }

    // MARK: - Logica

    /// Popola i campi del form se stiamo modificando un libro esistente.
    private func populateFields() {
        guard let book else { return }

        title           = book.title
        synopsis        = book.synopsis ?? ""
        pageCount       = book.pageCount > 0 ? String(book.pageCount) : ""
        rating          = book.rating
        isRead          = book.isRead
        selectedAuthor  = book.author

        if let date = book.publishedDate {
            publishedDate    = date
            hasPublishedDate = true
        }

        // Popola i tag selezionati dalla relazione molti-a-molti
        selectedTags = Set(book.tagsArray)
    }

    /// Aggiunge o rimuove un tag dalla selezione corrente.
    private func toggleTag(_ tag: Tag) {
        if selectedTags.contains(tag) {
            selectedTags.remove(tag)
        } else {
            selectedTags.insert(tag)
        }
    }

    /// Salva il libro nel persistent store o aggiorna quello esistente.
    private func saveBook() {
        // ── Validazione ───────────────────────────────────
        let trimmedTitle = title.trimmingCharacters(in: .whitespaces)
        guard !trimmedTitle.isEmpty else {
            validationMessage = "Il titolo del libro non può essere vuoto."
            showValidationAlert = true
            return
        }

        let pages = Int32(pageCount) ?? 0
        guard pages >= 0 else {
            validationMessage = "Il numero di pagine deve essere un numero positivo."
            showValidationAlert = true
            return
        }

        // ── Crea o aggiorna l'oggetto Core Data ───────────
        let targetBook: Book
        if let existing = book {
            // MODIFICA: opera sull'oggetto esistente nel context
            targetBook = existing
        } else {
            // CREAZIONE: inserisce un nuovo oggetto nel context
            targetBook = Book(context: viewContext)
            targetBook.id = UUID()
        }

        // Assegna i valori
        targetBook.title         = trimmedTitle
        targetBook.synopsis      = synopsis.isEmpty ? nil : synopsis
        targetBook.pageCount     = pages
        targetBook.rating        = rating
        targetBook.isRead        = isRead
        targetBook.publishedDate = hasPublishedDate ? publishedDate : nil
        targetBook.author        = selectedAuthor

        // ── Gestione relazione molti-a-molti con Tag ──────
        // Rimuove tutti i tag precedenti poi aggiunge quelli selezionati
        if let currentTags = targetBook.tags {
            targetBook.removeFromTags(currentTags)
        }
        selectedTags.forEach { targetBook.addToTags($0) }

        // ── Salvataggio ───────────────────────────────────
        do {
            try viewContext.save()
            dismiss()
        } catch {
            let nsError = error as NSError
            validationMessage = nsError.localizedDescription
            showValidationAlert = true
            // Rollback per evitare di lasciare il context in uno stato inconsistente
            viewContext.rollback()
        }
    }

    /// Annulla le modifiche e chiude il form.
    /// Usa rollback() per scartare le modifiche non salvate del context.
    private func cancelEdit() {
        // rollback() annulla tutte le modifiche non ancora salvate nel context.
        // È più sicuro di discard() in quanto ripristina l'ultimo stato salvato.
        viewContext.rollback()
        dismiss()
    }
}

#Preview {
    NavigationStack {
        AddEditBookView()
    }
    .environment(\.managedObjectContext, PersistenceController.preview.viewContext)
}
