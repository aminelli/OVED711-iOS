//
//  AddReadingSessionView.swift
//  CoreDataDemo
//
//  Form per registrare una nuova sessione di lettura.
//  Dimostra la creazione di un oggetto correlato (relazione uno-a-molti).
//

import SwiftUI
import CoreData

// MARK: - AddReadingSessionView
struct AddReadingSessionView: View {

    let book: Book

    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) private var dismiss

    @State private var startDate    = Date().addingTimeInterval(-3600) // 1 ora fa
    @State private var endDate      = Date()
    @State private var pagesRead    = ""
    @State private var notes        = ""
    @State private var isInProgress = false

    var body: some View {
        Form {
            Section("Dettagli sessione per: \(book.title)") {
                DatePicker("Inizio", selection: $startDate, displayedComponents: [.date, .hourAndMinute])
                Toggle("Sessione in corso", isOn: $isInProgress)
                if !isInProgress {
                    DatePicker("Fine", selection: $endDate, in: startDate..., displayedComponents: [.date, .hourAndMinute])
                }
            }

            Section("Pagine lette") {
                HStack {
                    Text("Pagine lette in questa sessione")
                    Spacer()
                    TextField("0", text: $pagesRead)
                        .keyboardType(.numberPad)
                        .multilineTextAlignment(.trailing)
                        .frame(width: 60)
                }

                if !pagesRead.isEmpty, let pages = Int(pagesRead), book.pageCount > 0 {
                    let previousPages = Int(book.totalPagesRead)
                    let totalAfter = min(previousPages + pages, Int(book.pageCount))
                    let progress = Double(totalAfter) / Double(book.pageCount)

                    VStack(alignment: .leading, spacing: 4) {
                        Text("Progresso dopo questa sessione")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        ProgressView(value: progress)
                            .tint(.blue)
                        Text(String(format: "%.0f%% (%d / %d pagine)", progress * 100, totalAfter, book.pageCount))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 4)
                }
            }

            Section("Note (opzionali)") {
                TextField("Aggiungi note sulla sessione...", text: $notes, axis: .vertical)
                    .lineLimit(3...5)
            }

            if !isInProgress {
                Section {
                    let duration = endDate.timeIntervalSince(startDate)
                    let hours = Int(duration) / 3600
                    let minutes = (Int(duration) % 3600) / 60
                    Label("Durata: \(hours > 0 ? "\(hours)h " : "")\(minutes) min",
                          systemImage: "clock")
                        .foregroundStyle(.secondary)
                }
            }
        }
        .navigationTitle("Nuova sessione")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Annulla") { dismiss() }
            }
            ToolbarItem(placement: .confirmationAction) {
                Button("Salva") { saveSession() }
                    .fontWeight(.semibold)
                    .disabled(pagesRead.isEmpty)
            }
        }
    }

    private func saveSession() {
        let pages = Int32(pagesRead) ?? 0

        // Crea il nuovo oggetto ReadingSession nel context
        let session = ReadingSession(context: viewContext)
        session.id         = UUID()
        session.startDate  = startDate
        session.endDate    = isInProgress ? nil : endDate
        session.pagesRead  = pages
        session.notes      = notes.isEmpty ? nil : notes
        session.book       = book  // Imposta la relazione verso il libro

        do {
            try viewContext.save()
            dismiss()
        } catch {
            print("Errore salvataggio sessione: \(error)")
            viewContext.rollback()
        }
    }
}

#Preview {
    let controller = PersistenceController.preview
    let book = try! controller.viewContext.fetch(Book.fetchRequest()).first!
    return NavigationStack {
        AddReadingSessionView(book: book)
    }
    .environment(\.managedObjectContext, controller.viewContext)
}
