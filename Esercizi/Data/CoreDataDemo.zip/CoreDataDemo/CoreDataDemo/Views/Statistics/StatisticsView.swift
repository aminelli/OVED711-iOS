//
//  StatisticsView.swift
//  CoreDataDemo
//
//  Vista statistiche avanzate della libreria.
//  Dimostra:
//  - NSFetchRequest con resultType = .dictionaryResultType (query aggregate)
//  - NSExpression per SUM, AVG, COUNT, MAX, MIN
//  - NSFetchRequest con propertiesToGroupBy (GROUP BY SQL)
//  - Calcoli eseguiti direttamente nel persistent store (non in memoria)
//  - Aggiornamento reattivo tramite NotificationCenter (NSManagedObjectContextDidSave)
//

import SwiftUI
import CoreData
import Combine

// MARK: - LibraryStatistics
/// Model che raccoglie tutte le statistiche della libreria.
struct LibraryStatistics {
    var totalBooks          = 0
    var readBooks           = 0
    var unreadBooks         = 0
    var totalAuthors        = 0
    var totalTags           = 0
    var totalReadingSessions = 0
    var totalPagesRead      = 0
    var averageRating       = 0.0
    var totalReadingTime    = 0.0    // in secondi
    var topRatedBooks: [Book] = []
    var mostReadAuthor: String = "-"
    var booksByRatingRange: [(range: String, count: Int)] = []
}

// MARK: - StatisticsViewModel
/// ViewModel che calcola le statistiche usando query Core Data avanzate.
/// Usa NSFetchRequest con tipi di risultato diversi per dimostrare le capacità SQL di Core Data.
@MainActor
final class StatisticsViewModel: ObservableObject {

    @Published var stats = LibraryStatistics()
    @Published var isLoading = false

    private let context: NSManagedObjectContext

    /// Task che osserva le notifiche di salvataggio usando AsyncSequence (Swift 6 Concurrency-safe).
    /// Sostituisce il pattern @objc selector + NotificationCenter che causa errori di
    /// actor-isolation in Swift 6: un metodo @MainActor non può essere chiamato via ObjC
    /// senza attraversare i confini dell'attore in modo non verificabile dal compilatore.
    private var observerTask: Task<Void, Never>?

    init(context: NSManagedObjectContext) {
        self.context = context
        // AsyncSequence di notifiche: il loop `for await` gira su @MainActor
        // perché il Task viene creato in un contesto @MainActor (l'init della classe).
        observerTask = Task { [weak self] in
            for await _ in NotificationCenter.default.notifications(
                named: .NSManagedObjectContextDidSave,
                object: context
            ) {
                self?.refresh()
            }
        }
        refresh()
    }

    deinit {
        // Cancella il Task per evitare memory leak
        observerTask?.cancel()
    }

    /// Ricalcola tutte le statistiche. Eseguito sul main thread.
    func refresh() {
        isLoading = true
        var newStats = LibraryStatistics()

        // ── 1. Conteggi semplici con count(for:) ──────────
        // Usa SELECT COUNT(*) SQL senza caricare oggetti in memoria
        newStats.totalBooks    = (try? context.count(for: Book.fetchRequest())) ?? 0
        newStats.totalAuthors  = (try? context.count(for: Author.fetchRequest())) ?? 0
        newStats.totalTags     = (try? context.count(for: Tag.fetchRequest())) ?? 0

        let readRequest = Book.fetchRequest()
        readRequest.predicate = NSPredicate(format: "isRead == YES")
        newStats.readBooks   = (try? context.count(for: readRequest)) ?? 0
        newStats.unreadBooks = newStats.totalBooks - newStats.readBooks

        let sessionRequest = ReadingSession.fetchRequest()
        newStats.totalReadingSessions = (try? context.count(for: sessionRequest)) ?? 0

        // ── 2. SUM di pagine lette (query aggregata) ───────
        // NSFetchRequest con .dictionaryResultType esegue aggregazioni SQL native
        newStats.totalPagesRead = Int(aggregateValue(
            function: "sum:",
            attribute: "pagesRead",
            entity: "ReadingSession"
        ))

        // ── 3. Media rating (AVG) ──────────────────────────
        newStats.averageRating = aggregateValue(
            function: "average:",
            attribute: "rating",
            entity: "Book",
            predicate: NSPredicate(format: "isRead == YES")
        )

        // ── 4. Top 3 libri per rating ──────────────────────
        let topRequest = Book.fetchRequest()
        topRequest.sortDescriptors = [NSSortDescriptor(key: "rating", ascending: false)]
        topRequest.fetchLimit = 3  // LIMIT 3 SQL
        topRequest.predicate  = NSPredicate(format: "isRead == YES")
        newStats.topRatedBooks = (try? context.fetch(topRequest)) ?? []

        // ── 5. Autore con più libri (GROUP BY + COUNT) ─────
        newStats.mostReadAuthor = fetchMostProductiveAuthor()

        // ── 6. Distribuzione libri per fascia di rating ────
        newStats.booksByRatingRange = fetchBooksGroupedByRatingRange()

        stats = newStats
        isLoading = false
    }

    // MARK: - Metodi Helper per Query Aggregate

    /// Esegue una funzione aggregata (sum, average, min, max, count) su un attributo.
    /// Equivale a `SELECT function(attribute) FROM entity WHERE predicate`
    private func aggregateValue(
        function: String,
        attribute: String,
        entity: String,
        predicate: NSPredicate? = nil
    ) -> Double {
        // Costruisce un NSFetchRequest di tipo dizionario
        let request = NSFetchRequest<NSDictionary>(entityName: entity)
        request.resultType = .dictionaryResultType
        request.predicate  = predicate

        // NSExpression per la funzione aggregata
        let attrExpr = NSExpression(forKeyPath: attribute)
        let aggExpr  = NSExpression(forFunction: function, arguments: [attrExpr])

        // NSExpressionDescription descrive la colonna risultante
        let desc = NSExpressionDescription()
        desc.name = "result"
        desc.expression = aggExpr
        desc.expressionResultType = .doubleAttributeType

        request.propertiesToFetch = [desc]

        do {
            let results = try context.fetch(request)
            return results.first?["result"] as? Double ?? 0
        } catch {
            print("Errore query aggregata [\(function) \(attribute)]: \(error)")
            return 0
        }
    }

    /// Trova l'autore con più libri usando GROUP BY e ORDER BY COUNT.
    /// Equivale a:
    /// SELECT author.name, COUNT(title) FROM Book GROUP BY author ORDER BY COUNT(title) DESC LIMIT 1
    private func fetchMostProductiveAuthor() -> String {
        let request = NSFetchRequest<NSDictionary>(entityName: "Book")
        request.resultType = .dictionaryResultType

        // Proprietà da raggruppare (GROUP BY)
        let authorNameExpr = NSExpression(forKeyPath: "author.name")
        let authorNameDesc = NSExpressionDescription()
        authorNameDesc.name = "authorName"
        authorNameDesc.expression = authorNameExpr
        authorNameDesc.expressionResultType = .stringAttributeType

        // COUNT dei libri per autore
        let countExpr = NSExpression(forFunction: "count:", arguments: [NSExpression(forKeyPath: "title")])
        let countDesc = NSExpressionDescription()
        countDesc.name = "bookCount"
        countDesc.expression = countExpr
        countDesc.expressionResultType = .integer32AttributeType

        request.propertiesToFetch    = [authorNameDesc, countDesc]
        request.propertiesToGroupBy  = ["author.name"]    // GROUP BY
        request.sortDescriptors      = [NSSortDescriptor(key: "bookCount", ascending: false)]
        request.fetchLimit           = 1                  // LIMIT 1

        do {
            let results = try context.fetch(request)
            return results.first?["authorName"] as? String ?? "-"
        } catch {
            print("Errore fetchMostProductiveAuthor: \(error)")
            return "-"
        }
    }

    /// Raggruppa i libri per fascia di rating usando predicati individuali.
    private func fetchBooksGroupedByRatingRange() -> [(range: String, count: Int)] {
        let ranges: [(label: String, predicate: NSPredicate)] = [
            ("★★★★★ (5)",     NSPredicate(format: "rating >= 4.5")),
            ("★★★★ (4-4.5)",  NSPredicate(format: "rating >= 3.5 AND rating < 4.5")),
            ("★★★ (3-3.5)",   NSPredicate(format: "rating >= 2.5 AND rating < 3.5")),
            ("★★ (< 3)",      NSPredicate(format: "rating < 2.5 AND rating > 0")),
        ]

        return ranges.compactMap { range in
            let request = Book.fetchRequest()
            request.predicate = range.predicate
            let count = (try? context.count(for: request)) ?? 0
            // Esclude le fasce con zero libri per un grafico più pulito
            return count > 0 ? (range: range.label, count: count) : nil
        }
    }
}

// MARK: - StatisticsView
struct StatisticsView: View {

    @Environment(\.managedObjectContext) private var viewContext
    @StateObject private var viewModel: StatisticsViewModel

    /// Riceve il context esplicitamente dal chiamante (MainTabView) che ha
    /// accesso all'@Environment. Non è possibile leggere @Environment in init().
    init(context: NSManagedObjectContext) {
        _viewModel = StateObject(wrappedValue: StatisticsViewModel(context: context))
    }

    var body: some View {
        List {
            if viewModel.isLoading {
                ProgressView("Calcolo statistiche...")
                    .listRowBackground(Color.clear)
            } else {
                overviewSection
                readingSection
                topBooksSection
                distributionSection
                advancedSection
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("Statistiche")
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button {
                    viewModel.refresh()
                } label: {
                    Image(systemName: "arrow.clockwise")
                }
            }
        }
        .onAppear {
            // Ricrea il viewModel con il context corretto dell'ambiente
            viewModel.refresh()
        }
    }

    // MARK: - Sezioni

    private var overviewSection: some View {
        Section("Panoramica libreria") {
            StatCardGrid(items: [
                StatCard(title: "Libri",    value: "\(viewModel.stats.totalBooks)",   icon: "books.vertical.fill", color: .blue),
                StatCard(title: "Autori",   value: "\(viewModel.stats.totalAuthors)", icon: "person.2.fill",       color: .purple),
                StatCard(title: "Tag",      value: "\(viewModel.stats.totalTags)",    icon: "tag.fill",            color: .orange),
                StatCard(title: "Sessioni", value: "\(viewModel.stats.totalReadingSessions)", icon: "clock.fill",  color: .green),
            ])
        }
    }

    private var readingSection: some View {
        Section("Progressione lettura") {
            // Barra di progresso lettura
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Letti: \(viewModel.stats.readBooks) / \(viewModel.stats.totalBooks)")
                    Spacer()
                    let pct = viewModel.stats.totalBooks > 0
                        ? Double(viewModel.stats.readBooks) / Double(viewModel.stats.totalBooks)
                        : 0
                    Text(String(format: "%.0f%%", pct * 100))
                        .bold()
                        .foregroundStyle(.green)
                }
                .font(.subheadline)

                ProgressView(value: viewModel.stats.totalBooks > 0
                             ? Double(viewModel.stats.readBooks) / Double(viewModel.stats.totalBooks)
                             : 0)
                .tint(.green)
                .scaleEffect(x: 1, y: 2)
            }
            .padding(.vertical, 4)

            StatRowView(label: "Pagine totali lette",
                        value: "\(viewModel.stats.totalPagesRead)")
            StatRowView(label: "Rating medio (letti)",
                        value: String(format: "%.2f ★", viewModel.stats.averageRating))
            StatRowView(label: "Autore più prolifico",
                        value: viewModel.stats.mostReadAuthor)
        }
    }

    private var topBooksSection: some View {
        Section("Top libri per rating") {
            if viewModel.stats.topRatedBooks.isEmpty {
                Text("Nessun libro letto ancora.")
                    .foregroundStyle(.secondary)
                    .font(.subheadline)
            } else {
                ForEach(Array(viewModel.stats.topRatedBooks.enumerated()), id: \.element.id) { index, book in
                    HStack(spacing: 12) {
                        Text("\(index + 1)")
                            .font(.headline.bold())
                            .foregroundStyle(.secondary)
                            .frame(width: 20)

                        VStack(alignment: .leading, spacing: 2) {
                            Text(book.title)
                                .font(.subheadline.bold())
                            Text(book.author?.name ?? "Autore sconosciuto")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }

                        Spacer()

                        Text(String(format: "%.1f ★", book.rating))
                            .font(.subheadline.bold())
                            .foregroundStyle(.orange)
                    }
                }
            }
        }
    }

    private var distributionSection: some View {
        Section("Distribuzione per rating") {
            if viewModel.stats.booksByRatingRange.isEmpty {
                Text("Nessun dato disponibile.")
                    .foregroundStyle(.secondary)
            } else {
                ForEach(viewModel.stats.booksByRatingRange, id: \.range) { item in
                    HStack {
                        Text(item.range)
                            .font(.caption)
                            .frame(width: 110, alignment: .leading)

                        GeometryReader { geo in
                            let maxCount = viewModel.stats.booksByRatingRange.map(\.count).max() ?? 1
                            let width = geo.size.width * CGFloat(item.count) / CGFloat(maxCount)
                            RoundedRectangle(cornerRadius: 4)
                                .fill(.orange.gradient)
                                .frame(width: max(width, 4))
                        }
                        .frame(height: 20)

                        Text("\(item.count)")
                            .font(.caption.bold())
                            .frame(width: 24, alignment: .trailing)
                    }
                }
            }
        }
    }

    private var advancedSection: some View {
        Section {
            VStack(alignment: .leading, spacing: 8) {
                Label("Query SQL avanzate utilizzate:", systemImage: "cylinder.split.1x2")
                    .font(.subheadline.bold())

                VStack(alignment: .leading, spacing: 4) {
                    codeTag("SELECT COUNT(*)")
                    codeTag("SELECT SUM(pagesRead)")
                    codeTag("SELECT AVG(rating) WHERE isRead=YES")
                    codeTag("SELECT author.name, COUNT(*) GROUP BY author.name")
                    codeTag("ORDER BY rating DESC LIMIT 3")
                }
            }
            .padding(.vertical, 4)
        } header: {
            Text("Tecniche Core Data dimostrate")
        } footer: {
            Text("Tutte le aggregazioni vengono eseguite direttamente nel SQLite store tramite NSFetchRequest con resultType .dictionaryResultType, senza caricare oggetti in memoria.")
                .font(.caption)
        }
    }

    private func codeTag(_ text: String) -> some View {
        Text(text)
            .font(.system(.caption, design: .monospaced))
            .foregroundStyle(.green)
            .padding(.horizontal, 8)
            .padding(.vertical, 3)
            .background(.black.opacity(0.8))
            .clipShape(RoundedRectangle(cornerRadius: 6))
    }
}

// MARK: - StatCard / StatCardGrid
struct StatCard: Identifiable {
    let id = UUID()
    let title: String
    let value: String
    let icon: String
    let color: Color
}

struct StatCardGrid: View {
    let items: [StatCard]

    var body: some View {
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
            ForEach(items) { item in
                VStack(spacing: 6) {
                    Image(systemName: item.icon)
                        .font(.title2)
                        .foregroundStyle(item.color)
                    Text(item.value)
                        .font(.title.bold())
                    Text(item.title)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 12)
                .background(item.color.opacity(0.1))
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
        }
        .listRowBackground(Color.clear)
        .listRowInsets(EdgeInsets(top: 4, leading: 0, bottom: 4, trailing: 0))
    }
}

#Preview {
    NavigationStack {
        StatisticsView(context: PersistenceController.preview.viewContext)
    }
    .environment(\.managedObjectContext, PersistenceController.preview.viewContext)
}
