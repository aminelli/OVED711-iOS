//
//  TagsView.swift
//  CoreDataDemo
//
//  Gestione dei tag con relazione molti-a-molti.
//  Dimostra:
//  - CRUD completo su Tag
//  - Visualizzazione degli elementi correlati (libri + autori per ogni tag)
//  - Color picker personalizzato
//  - NSPredicate su relazioni
//

import SwiftUI
import CoreData

// MARK: - TagsView
struct TagsView: View {

    @Environment(\.managedObjectContext) private var viewContext

    @FetchRequest(
        sortDescriptors: [SortDescriptor(\.name)],
        animation: .default
    )
    private var tags: FetchedResults<Tag>

    @State private var showAddTag       = false
    @State private var tagToEdit: Tag?

    var body: some View {
        List {
            if tags.isEmpty {
                ContentUnavailableView {
                    Label("Nessun tag", systemImage: "tag.slash")
                } description: {
                    Text("Tocca + per creare il primo tag.")
                }
                .listRowBackground(Color.clear)
            } else {
                ForEach(tags) { tag in
                    TagDetailRow(tag: tag)
                        .swipeActions(edge: .trailing) {
                            Button(role: .destructive) {
                                deleteTag(tag)
                            } label: {
                                Label("Elimina", systemImage: "trash")
                            }

                            Button {
                                tagToEdit = tag
                            } label: {
                                Label("Modifica", systemImage: "pencil")
                            }
                            .tint(.blue)
                        }
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("Tag")
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button { showAddTag = true } label: {
                    Label("Aggiungi tag", systemImage: "plus")
                }
            }
        }
        .sheet(isPresented: $showAddTag) {
            NavigationStack {
                AddEditTagView()
            }
        }
        .sheet(item: $tagToEdit) { tag in
            NavigationStack {
                AddEditTagView(tag: tag)
            }
        }
    }

    private func deleteTag(_ tag: Tag) {
        viewContext.delete(tag)
        try? viewContext.save()
    }
}

// MARK: - TagDetailRow
/// Mostra un tag con i contatori di libri e autori associati.
struct TagDetailRow: View {
    @ObservedObject var tag: Tag

    var body: some View {
        HStack(spacing: 12) {
            // Indicatore colore
            Circle()
                .fill(tag.color)
                .frame(width: 20, height: 20)
                .shadow(color: tag.color.opacity(0.5), radius: 3)

            VStack(alignment: .leading, spacing: 4) {
                Text(tag.name)
                    .font(.headline)

                HStack(spacing: 8) {
                    Label("\(tag.books?.count ?? 0) libri", systemImage: "book")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    Label("\(tag.authors?.count ?? 0) autori", systemImage: "person")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            Spacer()

            // Badge con numero totale elementi
            if tag.totalItemCount > 0 {
                Text("\(tag.totalItemCount)")
                    .font(.caption.bold())
                    .padding(.horizontal, 8)
                    .padding(.vertical, 3)
                    .background(tag.color.opacity(0.2))
                    .foregroundStyle(tag.color)
                    .clipShape(Capsule())
            }
        }
        .padding(.vertical, 2)
    }
}

// MARK: - AddEditTagView
struct AddEditTagView: View {

    let tag: Tag?

    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) private var dismiss

    @State private var name     = ""
    @State private var colorHex = "#007AFF"

    // Palette di colori predefiniti
    private let colorPresets = [
        "#FF6B6B", "#FF8E53", "#FFC300", "#96CEB4",
        "#4ECDC4", "#45B7D1", "#007AFF", "#5856D6",
        "#AF52DE", "#FF2D55", "#34C759", "#8E8E93"
    ]

    @State private var showValidation = false

    init(tag: Tag? = nil) {
        self.tag = tag
    }

    var body: some View {
        Form {
            Section("Nome del tag") {
                HStack {
                    Circle()
                        .fill(colorFromHex(colorHex))
                        .frame(width: 24, height: 24)
                    TextField("Nome tag *", text: $name)
                }
            }

            Section("Colore") {
                LazyVGrid(columns: Array(repeating: .init(.flexible()), count: 6), spacing: 12) {
                    ForEach(colorPresets, id: \.self) { hex in
                        Circle()
                            .fill(colorFromHex(hex))
                            .frame(width: 36, height: 36)
                            .overlay {
                                if colorHex == hex {
                                    Image(systemName: "checkmark")
                                        .font(.caption.bold())
                                        .foregroundStyle(.white)
                                }
                            }
                            .onTapGesture { colorHex = hex }
                            .shadow(color: colorFromHex(hex).opacity(0.4), radius: 3)
                    }
                }
                .padding(.vertical, 4)

                HStack {
                    Text("Hex:")
                    TextField("#RRGGBB", text: $colorHex)
                        .autocorrectionDisabled()
                        .textInputAutocapitalization(.characters)
                        .font(.system(.body, design: .monospaced))
                }
            }

            Section {
                HStack {
                    Spacer()
                    // Anteprima inline: non usa Core Data per evitare oggetti fantasma nel context
                    HStack(spacing: 6) {
                        Circle()
                            .fill(colorFromHex(colorHex))
                            .frame(width: 8, height: 8)
                        Text(name.isEmpty ? "Esempio" : name)
                            .font(.caption)
                            .foregroundStyle(colorFromHex(colorHex))
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(colorFromHex(colorHex).opacity(0.12))
                    .clipShape(Capsule())
                    Spacer()
                }
            } header: {
                Text("Anteprima")
            }
        }
        .navigationTitle(tag == nil ? "Nuovo tag" : "Modifica tag")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Annulla") {
                    viewContext.rollback()
                    dismiss()
                }
            }
            ToolbarItem(placement: .confirmationAction) {
                Button("Salva") { saveTag() }
                    .fontWeight(.semibold)
            }
        }
        .onAppear {
            if let tag {
                name     = tag.name
                colorHex = tag.colorHex
            }
        }
        .alert("Nome obbligatorio", isPresented: $showValidation) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("Il nome del tag non può essere vuoto.")
        }
    }

    private func colorFromHex(_ hex: String) -> Color {
        var h = hex.hasPrefix("#") ? String(hex.dropFirst()) : hex
        guard h.count == 6 else { return .blue }
        var rgb: UInt64 = 0
        Scanner(string: h).scanHexInt64(&rgb)
        return Color(
            red:   Double((rgb & 0xFF0000) >> 16) / 255.0,
            green: Double((rgb & 0x00FF00) >> 8)  / 255.0,
            blue:  Double( rgb & 0x0000FF)         / 255.0
        )
    }

    private func saveTag() {
        let trimmed = name.trimmingCharacters(in: .whitespaces)
        guard !trimmed.isEmpty else {
            showValidation = true
            return
        }

        let target: Tag
        if let existing = tag {
            target = existing
        } else {
            target = Tag(context: viewContext)
            target.id = UUID()
        }
        target.name     = trimmed
        target.colorHex = colorHex

        do {
            try viewContext.save()
            dismiss()
        } catch {
            print("Errore salvataggio tag: \(error)")
            viewContext.rollback()
        }
    }
}

// MARK: - TagChipView
/// Vista compatta riutilizzabile per mostrare un tag come "chip" colorata.
struct TagChipView: View {
    let tag: Tag
    let compact: Bool

    var body: some View {
        HStack(spacing: 4) {
            Circle()
                .fill(tag.color)
                .frame(width: compact ? 6 : 8, height: compact ? 6 : 8)
            Text(tag.name)
                .font(compact ? .caption2 : .caption)
                .foregroundStyle(tag.color)
        }
        .padding(.horizontal, compact ? 6 : 8)
        .padding(.vertical, compact ? 2 : 4)
        .background(tag.color.opacity(0.12))
        .clipShape(Capsule())
    }
}

#Preview {
    NavigationStack {
        TagsView()
    }
    .environment(\.managedObjectContext, PersistenceController.preview.viewContext)
}
