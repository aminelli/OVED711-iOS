//
//  MainTabView.swift
//  CoreDataDemo
//
//  View principale con la barra di navigazione a schede.
//  Ogni scheda dimostra un aspetto diverso di Core Data.
//

import SwiftUI

// MARK: - MainTabView
/// Contenitore principale con navigazione a schede.
/// Ogni tab rappresenta una sezione funzionale dell'app.
struct MainTabView: View {

    /// Necessario per passare il context a StatisticsView nel suo init.
    /// @Environment non è accessibile negli init delle View, quindi
    /// MainTabView funge da ponte tra l'ambiente e StatisticsView.
    @Environment(\.managedObjectContext) private var viewContext

    var body: some View {
        TabView {
            // ── Scheda 1: Libri ─────────────────────────────
            // Dimostra: @FetchRequest, ricerca, filtri, ordinamento, CRUD
            NavigationStack {
                BooksListView()
            }
            .tabItem {
                Label("Libri", systemImage: "books.vertical.fill")
            }

            // ── Scheda 2: Autori ─────────────────────────────
            // Dimostra: relazioni, navigazione nidificata, @SectionedFetchRequest
            NavigationStack {
                AuthorsListView()
            }
            .tabItem {
                Label("Autori", systemImage: "person.2.fill")
            }

            // ── Scheda 3: Tag ────────────────────────────────
            // Dimostra: relazione molti-a-molti, color picker
            NavigationStack {
                TagsView()
            }
            .tabItem {
                Label("Tag", systemImage: "tag.fill")
            }

            // ── Scheda 4: Statistiche ────────────────────────
            // Dimostra: query aggregate (COUNT, SUM, AVG), NSFetchRequest dictionary result.
            // StatisticsView riceve il context esplicitamente perché non può leggerlo nel suo init.
            NavigationStack {
                StatisticsView(context: viewContext)
            }
            .tabItem {
                Label("Statistiche", systemImage: "chart.bar.fill")
            }

            // ── Scheda 5: Impostazioni ───────────────────────
            // Dimostra: batch operations, undo/redo, reset database
            NavigationStack {
                SettingsView()
            }
            .tabItem {
                Label("Impostazioni", systemImage: "gearshape.fill")
            }
        }
    }
}

#Preview {
    MainTabView()
        .environment(\.managedObjectContext, PersistenceController.preview.viewContext)
}
