//
//  ReadingSession+CoreDataProperties.swift
//  CoreDataDemo
//
//  Proprietà e accessor generati per l'entità ReadingSession.
//

import Foundation
import CoreData

// MARK: - Proprietà Core Data
extension ReadingSession {

    @nonobjc class func fetchRequest() -> NSFetchRequest<ReadingSession> {
        return NSFetchRequest<ReadingSession>(entityName: "ReadingSession")
    }

    // MARK: Attributi
    /// Data e ora di fine sessione (nil se la sessione è ancora in corso)
    @NSManaged var endDate: Date?
    /// Identificatore univoco della sessione
    @NSManaged var id: UUID?
    /// Appunti opzionali presi durante la lettura
    @NSManaged var notes: String?
    /// Numero di pagine lette in questa sessione
    @NSManaged var pagesRead: Int32
    /// Data e ora di inizio sessione
    @NSManaged var startDate: Date

    // MARK: Relazioni
    /// Libro a cui appartiene questa sessione
    @NSManaged var book: Book?
}

// MARK: - Conformità a Identifiable
extension ReadingSession: Identifiable {}

// MARK: - Proprietà Calcolate
extension ReadingSession {

    /// Durata della sessione in secondi
    /// Se la sessione è ancora in corso, usa la data attuale come fine
    var duration: TimeInterval {
        let end = endDate ?? Date()
        return end.timeIntervalSince(startDate)
    }

    /// Indica se la sessione è ancora in corso (nessuna data di fine)
    var isInProgress: Bool {
        endDate == nil
    }

    /// Stringa formattata della durata della sessione
    var formattedDuration: String {
        let hours = Int(duration) / 3600
        let minutes = (Int(duration) % 3600) / 60

        if hours > 0 {
            return "\(hours)h \(minutes)m"
        } else if minutes > 0 {
            return "\(minutes) min"
        } else {
            return "< 1 min"
        }
    }

    /// Stringa formattata della data di inizio per la visualizzazione in lista
    var formattedStartDate: String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        formatter.locale = Locale.current
        return formatter.string(from: startDate)
    }

    /// Velocità di lettura in pagine per ora
    var readingSpeedPagesPerHour: Double {
        let hours = duration / 3600
        guard hours > 0 else { return 0 }
        return Double(pagesRead) / hours
    }
}
