//
//  Author+CoreDataClass.swift
//  CoreDataDemo
//
//  Classe NSManagedObject generata manualmente per l'entità Author.
//  Dimostra come estendere le classi Core Data con logica di business.
//

import Foundation
import CoreData

// MARK: - Classe Author
/// Rappresenta un autore nella libreria personale.
/// Mantiene relazioni con i libri scritti e i tag assegnati.
@objc(Author)
class Author: NSManagedObject {

    // MARK: - Factory Method
    /// Crea e configura un nuovo autore nel context specificato.
    /// Utilizza il pattern factory per garantire che tutti i campi obbligatori siano impostati.
    @discardableResult
    static func create(
        name: String,
        biography: String? = nil,
        birthDate: Date? = nil,
        in context: NSManagedObjectContext
    ) -> Author {
        let author = Author(context: context)
        author.id = UUID()  // Genera un identificatore univoco
        author.name = name
        author.biography = biography
        author.birthDate = birthDate
        return author
    }

    // MARK: - Validazione
    /// Verifica che i dati obbligatori siano presenti prima del salvataggio.
    /// Core Data chiama `validateForInsert()` e `validateForUpdate()` automaticamente.
    override func validateForInsert() throws {
        try super.validateForInsert()
        try validateAuthorData()
    }

    override func validateForUpdate() throws {
        try super.validateForUpdate()
        try validateAuthorData()
    }

    /// Logica di validazione comune per inserimento e aggiornamento.
    private func validateAuthorData() throws {
        // Il nome non può essere vuoto o composto solo da spazi
        guard !name.trimmingCharacters(in: .whitespaces).isEmpty else {
            let userInfo: [String: Any] = [
                NSLocalizedDescriptionKey: "Il nome dell'autore non può essere vuoto.",
                NSValidationObjectErrorKey: self,
                NSValidationKeyErrorKey: "name"
            ]
            throw NSError(domain: NSCocoaErrorDomain, code: NSValidationMissingMandatoryPropertyError, userInfo: userInfo)
        }
    }
}
