//
//  Book+CoreDataProperties.swift
//  CoreDataDemo
//
//  Proprietà e accessor generati per l'entità Book.
//

import Foundation
import CoreData

// MARK: - Proprietà Core Data
extension Book {

    /// Fetch request tipizzata per SwiftUI @FetchRequest e NSFetchedResultsController
    @nonobjc class func fetchRequest() -> NSFetchRequest<Book> {
        return NSFetchRequest<Book>(entityName: "Book")
    }

    // MARK: Attributi
    /// Dati binari della copertina (external binary storage per file grandi)
    @NSManaged var coverImageData: Data?
    /// Identificatore univoco
    @NSManaged var id: UUID?
    /// Indica se il libro è stato letto
    @NSManaged var isRead: Bool
    /// Numero di pagine del libro
    @NSManaged var pageCount: Int32
    /// Data di pubblicazione originale
    @NSManaged var publishedDate: Date?
    /// Rating da 0.0 a 5.0
    @NSManaged var rating: Double
    /// Sinossi/descrizione del libro
    @NSManaged var synopsis: String?
    /// Titolo del libro (campo obbligatorio)
    @NSManaged var title: String

    // MARK: Relazioni
    /// Relazione molti-a-uno verso Author
    @NSManaged var author: Author?
    /// Relazione uno-a-molti verso ReadingSession (eliminazione a cascata)
    @NSManaged var readingSessions: NSSet?
    /// Relazione molti-a-molti verso Tag
    @NSManaged var tags: NSSet?
}

// MARK: - Conformità a Identifiable
extension Book: Identifiable {}

// MARK: - Accessor Relazione ReadingSessions
extension Book {

    @objc(addReadingSessionsObject:)
    @NSManaged func addToReadingSessions(_ value: ReadingSession)

    @objc(removeReadingSessionsObject:)
    @NSManaged func removeFromReadingSessions(_ value: ReadingSession)

    @objc(addReadingSessions:)
    @NSManaged func addToReadingSessions(_ values: NSSet)

    @objc(removeReadingSessions:)
    @NSManaged func removeFromReadingSessions(_ values: NSSet)
}

// MARK: - Accessor Relazione Tags
extension Book {

    @objc(addTagsObject:)
    @NSManaged func addToTags(_ value: Tag)

    @objc(removeTagsObject:)
    @NSManaged func removeFromTags(_ value: Tag)

    @objc(addTags:)
    @NSManaged func addToTags(_ values: NSSet)

    @objc(removeTags:)
    @NSManaged func removeFromTags(_ values: NSSet)
}

// MARK: - Proprietà Calcolate
extension Book {

    /// Restituisce le sessioni di lettura come array ordinato per data di inizio (più recente prima)
    var readingSessionsArray: [ReadingSession] {
        let set = readingSessions as? Set<ReadingSession> ?? []
        return set.sorted { $0.startDate > $1.startDate }
    }

    /// Restituisce i tag come array ordinato alfabeticamente
    var tagsArray: [Tag] {
        let set = tags as? Set<Tag> ?? []
        return set.sorted { $0.name < $1.name }
    }

    /// Numero totale di pagine lette in tutte le sessioni
    var totalPagesRead: Int32 {
        readingSessionsArray.reduce(0) { $0 + $1.pagesRead }
    }

    /// Durata totale di lettura in secondi (somma delle sessioni completate)
    var totalReadingDuration: TimeInterval {
        readingSessionsArray.compactMap { session -> TimeInterval? in
            guard let end = session.endDate else { return nil }
            return end.timeIntervalSince(session.startDate)
        }.reduce(0, +)
    }

    /// Stringa formattata della durata totale di lettura
    var formattedTotalReadingTime: String {
        let hours = Int(totalReadingDuration) / 3600
        let minutes = (Int(totalReadingDuration) % 3600) / 60
        if hours > 0 {
            return "\(hours)h \(minutes)m"
        } else {
            return "\(minutes)m"
        }
    }

    /// Anno di pubblicazione come stringa
    var publicationYear: String {
        guard let date = publishedDate else { return "Anno sconosciuto" }
        let calendar = Calendar.current
        return String(calendar.component(.year, from: date))
    }

    /// Percentuale di completamento lettura (pagine lette / pagine totali)
    var readingProgress: Double {
        guard pageCount > 0 else { return isRead ? 1.0 : 0.0 }
        let progress = Double(totalPagesRead) / Double(pageCount)
        return min(progress, 1.0)
    }

    /// Icona SF Symbols in base allo stato di lettura
    var statusIcon: String {
        if isRead { return "checkmark.circle.fill" }
        if totalPagesRead > 0 { return "book.circle.fill" }
        return "circle"
    }

    /// Stringa formattata del rating con stelle
    var ratingDescription: String {
        let stars = Int(rating)
        return String(repeating: "★", count: stars) + String(repeating: "☆", count: 5 - stars)
    }
}
