//
//  Tag+CoreDataProperties.swift
//  CoreDataDemo
//
//  Proprietà e accessor generati per l'entità Tag.
//

import Foundation
import CoreData
import SwiftUI

// MARK: - Proprietà Core Data
extension Tag {

    @nonobjc class func fetchRequest() -> NSFetchRequest<Tag> {
        return NSFetchRequest<Tag>(entityName: "Tag")
    }

    // MARK: Attributi
    /// Colore del tag in formato esadecimale (es. "#FF6B6B")
    @NSManaged var colorHex: String
    /// Identificatore univoco
    @NSManaged var id: UUID?
    /// Nome del tag (campo obbligatorio)
    @NSManaged var name: String

    // MARK: Relazioni
    /// Relazione molti-a-molti verso Author
    @NSManaged var authors: NSSet?
    /// Relazione molti-a-molti verso Book
    @NSManaged var books: NSSet?
}

// MARK: - Conformità a Identifiable
extension Tag: Identifiable {}

// MARK: - Accessor Relazione Authors
extension Tag {

    @objc(addAuthorsObject:)
    @NSManaged func addToAuthors(_ value: Author)

    @objc(removeAuthorsObject:)
    @NSManaged func removeFromAuthors(_ value: Author)

    @objc(addAuthors:)
    @NSManaged func addToAuthors(_ values: NSSet)

    @objc(removeAuthors:)
    @NSManaged func removeFromAuthors(_ values: NSSet)
}

// MARK: - Accessor Relazione Books
extension Tag {

    @objc(addBooksObject:)
    @NSManaged func addToBooks(_ value: Book)

    @objc(removeBooksObject:)
    @NSManaged func removeFromBooks(_ value: Book)

    @objc(addBooks:)
    @NSManaged func addToBooks(_ values: NSSet)

    @objc(removeBooks:)
    @NSManaged func removeFromBooks(_ values: NSSet)
}

// MARK: - Proprietà Calcolate
extension Tag {

    /// Restituisce i libri come array ordinato per titolo
    var booksArray: [Book] {
        let set = books as? Set<Book> ?? []
        return set.sorted { $0.title < $1.title }
    }

    /// Restituisce gli autori come array ordinato per nome
    var authorsArray: [Author] {
        let set = authors as? Set<Author> ?? []
        return set.sorted { $0.name < $1.name }
    }

    /// Numero totale di elementi (libri + autori) associati al tag
    var totalItemCount: Int {
        (books?.count ?? 0) + (authors?.count ?? 0)
    }

    /// Converte il codice colore esadecimale in un oggetto SwiftUI Color.
    /// Supporta formati: "#RRGGBB" e "#RRGGBBAA"
    var color: Color {
        var hex = colorHex.trimmingCharacters(in: .whitespacesAndNewlines)
        hex = hex.hasPrefix("#") ? String(hex.dropFirst()) : hex

        guard hex.count == 6 || hex.count == 8 else {
            return .blue  // Colore di fallback
        }

        var rgbValue: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&rgbValue)

        if hex.count == 6 {
            return Color(
                red: Double((rgbValue & 0xFF0000) >> 16) / 255.0,
                green: Double((rgbValue & 0x00FF00) >> 8) / 255.0,
                blue: Double(rgbValue & 0x0000FF) / 255.0
            )
        } else {
            return Color(
                red: Double((rgbValue & 0xFF000000) >> 24) / 255.0,
                green: Double((rgbValue & 0x00FF0000) >> 16) / 255.0,
                blue: Double((rgbValue & 0x0000FF00) >> 8) / 255.0,
                opacity: Double(rgbValue & 0x000000FF) / 255.0
            )
        }
    }
}
