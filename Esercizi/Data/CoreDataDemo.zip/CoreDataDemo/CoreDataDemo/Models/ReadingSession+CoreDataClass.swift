//
//  ReadingSession+CoreDataClass.swift
//  CoreDataDemo
//
//  Classe NSManagedObject per l'entità ReadingSession.
//  Registra ogni sessione di lettura con durata e pagine lette.
//

import Foundation
import CoreData

// MARK: - Classe ReadingSession
/// Rappresenta una sessione di lettura di un libro.
/// Dimostra la relazione uno-a-molti da Book a ReadingSession.
@objc(ReadingSession)
class ReadingSession: NSManagedObject {

    // MARK: - Factory Method
    /// Avvia una nuova sessione di lettura per il libro specificato.
    @discardableResult
    static func start(
        for book: Book,
        pagesRead: Int32 = 0,
        notes: String? = nil,
        in context: NSManagedObjectContext
    ) -> ReadingSession {
        let session = ReadingSession(context: context)
        session.id = UUID()
        session.startDate = Date()
        session.pagesRead = pagesRead
        session.notes = notes
        session.book = book
        return session
    }

    /// Conclude la sessione impostando la data di fine.
    func end(pagesRead: Int32? = nil) {
        endDate = Date()
        if let pages = pagesRead {
            self.pagesRead = pages
        }
    }
}
