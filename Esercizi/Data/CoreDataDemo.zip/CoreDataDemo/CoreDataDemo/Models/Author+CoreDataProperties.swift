//
//  Author+CoreDataProperties.swift
//  CoreDataDemo
//
//  Proprietà e accessor generati per l'entità Author.
//  Separare proprietà e classe è la convenzione Apple per le subclassi NSManagedObject.
//

import Foundation
import CoreData

// MARK: - Proprietà Core Data
extension Author {

    /// Fetch request tipizzata per l'entità Author.
    /// Utilizzata da @FetchRequest nelle view SwiftUI.
    @nonobjc class func fetchRequest() -> NSFetchRequest<Author> {
        return NSFetchRequest<Author>(entityName: "Author")
    }

    // MARK: Attributi
    /// Biografia facoltativa dell'autore
    @NSManaged var biography: String?
    /// Data di nascita facoltativa
    @NSManaged var birthDate: Date?
    /// Identificatore univoco universale (UUID)
    @NSManaged var id: UUID?
    /// Nome dell'autore (campo obbligatorio)
    @NSManaged var name: String
    /// Dati binari dell'immagine profilo (archiviati esternamente se > soglia)
    @NSManaged var profileImageData: Data?

    // MARK: Relazioni
    /// Relazione uno-a-molti verso Book (eliminazione a cascata)
    @NSManaged var books: NSSet?
    /// Relazione molti-a-molti verso Tag
    @NSManaged var tags: NSSet?
}

// MARK: - Conformità a Identifiable
/// Abilita l'uso diretto in SwiftUI List e ForEach senza esplicitare `.id`
extension Author: Identifiable {}

// MARK: - Accessor Relazione Books
extension Author {

    /// Aggiunge un singolo libro alla collezione dell'autore
    @objc(addBooksObject:)
    @NSManaged func addToBooks(_ value: Book)

    /// Rimuove un singolo libro dalla collezione dell'autore
    @objc(removeBooksObject:)
    @NSManaged func removeFromBooks(_ value: Book)

    /// Aggiunge un insieme di libri alla collezione dell'autore
    @objc(addBooks:)
    @NSManaged func addToBooks(_ values: NSSet)

    /// Rimuove un insieme di libri dalla collezione dell'autore
    @objc(removeBooks:)
    @NSManaged func removeFromBooks(_ values: NSSet)
}

// MARK: - Accessor Relazione Tags
extension Author {

    /// Aggiunge un singolo tag all'autore
    @objc(addTagsObject:)
    @NSManaged func addToTags(_ value: Tag)

    /// Rimuove un singolo tag dall'autore
    @objc(removeTagsObject:)
    @NSManaged func removeFromTags(_ value: Tag)

    /// Aggiunge un insieme di tag all'autore
    @objc(addTags:)
    @NSManaged func addToTags(_ values: NSSet)

    /// Rimuove un insieme di tag dall'autore
    @objc(removeTags:)
    @NSManaged func removeFromTags(_ values: NSSet)
}

// MARK: - Proprietà Calcolate
extension Author {

    /// Restituisce i libri come array Swift tipizzato, ordinato alfabeticamente per titolo.
    /// Le relazioni Core Data sono NSSet; questa proprietà fornisce un accesso più comodo.
    var booksArray: [Book] {
        let set = books as? Set<Book> ?? []
        return set.sorted { $0.title < $1.title }
    }

    /// Restituisce i tag come array Swift tipizzato, ordinato alfabeticamente.
    var tagsArray: [Tag] {
        let set = tags as? Set<Tag> ?? []
        return set.sorted { $0.name < $1.name }
    }

    /// Numero totale di libri scritti da questo autore
    var bookCount: Int {
        books?.count ?? 0
    }

    /// Numero di libri già letti
    var readBooksCount: Int {
        booksArray.filter { $0.isRead }.count
    }

    /// Stringa formattata della data di nascita per la visualizzazione
    var formattedBirthDate: String {
        guard let date = birthDate else { return "Data non disponibile" }
        let formatter = DateFormatter()
        formatter.dateStyle = .long
        formatter.locale = Locale.current
        return formatter.string(from: date)
    }

    /// Rating medio di tutti i libri dell'autore
    var averageRating: Double {
        let bks = booksArray
        guard !bks.isEmpty else { return 0 }
        return bks.reduce(0) { $0 + $1.rating } / Double(bks.count)
    }
}
