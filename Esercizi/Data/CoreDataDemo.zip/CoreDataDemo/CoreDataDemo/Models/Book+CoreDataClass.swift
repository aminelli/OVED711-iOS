//
//  Book+CoreDataClass.swift
//  CoreDataDemo
//
//  Classe NSManagedObject per l'entità Book.
//  Dimostra validazione personalizzata e factory method.
//

import Foundation
import CoreData

// MARK: - Classe Book
/// Rappresenta un libro nella libreria personale.
/// Mantiene relazioni con l'autore, i tag e le sessioni di lettura.
@objc(Book)
class Book: NSManagedObject {

    // MARK: - Factory Method
    /// Crea un nuovo libro nel context specificato.
    @discardableResult
    static func create(
        title: String,
        synopsis: String? = nil,
        pageCount: Int32 = 0,
        rating: Double = 0.0,
        publishedDate: Date? = nil,
        author: Author? = nil,
        in context: NSManagedObjectContext
    ) -> Book {
        let book = Book(context: context)
        book.id = UUID()
        book.title = title
        book.synopsis = synopsis
        book.pageCount = pageCount
        book.rating = rating
        book.isRead = false
        book.publishedDate = publishedDate
        book.author = author
        return book
    }

    // MARK: - Validazione Core Data
    /// Valida il libro prima dell'inserimento nel persistent store.
    override func validateForInsert() throws {
        try super.validateForInsert()
        try validateBookData()
    }

    override func validateForUpdate() throws {
        try super.validateForUpdate()
        try validateBookData()
    }

    /// Regole di validazione: titolo non vuoto, rating tra 0 e 5, pagine >= 0.
    private func validateBookData() throws {
        guard !title.trimmingCharacters(in: .whitespaces).isEmpty else {
            let userInfo: [String: Any] = [
                NSLocalizedDescriptionKey: "Il titolo del libro non può essere vuoto.",
                NSValidationKeyErrorKey: "title"
            ]
            throw NSError(domain: NSCocoaErrorDomain, code: NSValidationMissingMandatoryPropertyError, userInfo: userInfo)
        }

        guard rating >= 0.0 && rating <= 5.0 else {
            let userInfo: [String: Any] = [
                NSLocalizedDescriptionKey: "Il rating deve essere compreso tra 0.0 e 5.0.",
                NSValidationKeyErrorKey: "rating"
            ]
            throw NSError(domain: NSCocoaErrorDomain, code: NSValidationNumberTooLargeError, userInfo: userInfo)
        }

        guard pageCount >= 0 else {
            let userInfo: [String: Any] = [
                NSLocalizedDescriptionKey: "Il numero di pagine non può essere negativo.",
                NSValidationKeyErrorKey: "pageCount"
            ]
            throw NSError(domain: NSCocoaErrorDomain, code: NSValidationNumberTooSmallError, userInfo: userInfo)
        }
    }
}
