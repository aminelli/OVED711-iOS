//
//  Tag+CoreDataClass.swift
//  CoreDataDemo
//
//  Classe NSManagedObject per l'entità Tag.
//  I tag vengono usati per classificare sia libri che autori (relazione molti-a-molti).
//

import Foundation
import CoreData
import SwiftUI

// MARK: - Classe Tag
/// Rappresenta un'etichetta/categoria assegnabile a libri e autori.
/// Dimostra la relazione molti-a-molti tra entità.
@objc(Tag)
class Tag: NSManagedObject {

    // MARK: - Factory Method
    @discardableResult
    static func create(
        name: String,
        colorHex: String = "#007AFF",
        in context: NSManagedObjectContext
    ) -> Tag {
        let tag = Tag(context: context)
        tag.id = UUID()
        tag.name = name
        tag.colorHex = colorHex
        return tag
    }

    // MARK: - Validazione
    override func validateForInsert() throws {
        try super.validateForInsert()
        guard !name.trimmingCharacters(in: .whitespaces).isEmpty else {
            let userInfo: [String: Any] = [
                NSLocalizedDescriptionKey: "Il nome del tag non può essere vuoto.",
                NSValidationKeyErrorKey: "name"
            ]
            throw NSError(domain: NSCocoaErrorDomain, code: NSValidationMissingMandatoryPropertyError, userInfo: userInfo)
        }
    }
}
