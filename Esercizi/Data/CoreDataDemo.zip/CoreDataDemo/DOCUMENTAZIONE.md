# CoreDataDemo — Documentazione Tecnica

> **Progetto:** CoreDataDemo  
> **Piattaforma:** iOS 26+  
> **Linguaggio:** Swift 6.3  
> **Framework:** Core Data + SwiftUI  
> **Autore:** Antonio Minelli  
> **Data:** Giugno 2026  

---

## Indice

1. [Panoramica del progetto](#panoramica)
2. [Architettura](#architettura)
3. [Modello dati Core Data](#modello-dati)
4. [Stack Core Data](#stack-core-data)
5. [Funzionalità dimostrate](#funzionalita)
6. [Struttura dei file](#struttura-file)
7. [Pattern e best practices](#best-practices)
8. [Guida rapida all'uso](#guida-uso)

---

## 1. Panoramica del progetto {#panoramica}

CoreDataDemo è un'applicazione iOS che dimostra in modo esaustivo l'uso avanzato di **Core Data** con **SwiftUI** e **Swift 6**. L'app simula una libreria personale di libri con autori, categorie (tag) e sessioni di lettura.

### Obiettivi dimostrativi

| Funzionalità Core Data | Dove è implementata |
|---|---|
| CRUD completo | `AddEditBookView`, `AddEditAuthorView`, `AddEditTagView` |
| `@FetchRequest` con sort e predicate dinamici | `BooksListView` |
| `@SectionedFetchRequest` con sezioni alfabetiche | `AuthorsListView` |
| Relazioni 1-a-molti (Author → Books) | `Author+CoreDataProperties`, `AuthorDetailView` |
| Relazioni molti-a-molti (Book ↔ Tag) | `Tag+CoreDataProperties`, `AddEditBookView` |
| Eliminazione a cascata | Modello dati (deletionRule: Cascade) |
| Query aggregate (SUM, AVG, COUNT, GROUP BY) | `StatisticsView`, `PersistenceController` |
| `NSBatchInsertRequest` | `SettingsView.performBatchInsert()` |
| `NSBatchDeleteRequest` | `SettingsView.batchDeleteOrphanBooks()` |
| Context di background | `SettingsView.performBackgroundOperation()` |
| Undo / Redo con `UndoManager` | `PersistenceController`, `SettingsView` |
| Merge policy | `PersistenceController` (NSMergeByPropertyObjectTrump) |
| Migrazione leggera automatica | `PersistenceController` (shouldMigrateStoreAutomatically) |
| Persistent History Tracking | `PersistenceController` |
| Validazione dati (`validateForInsert`) | `Author`, `Book`, `Tag` |
| External Binary Storage | `Author.profileImageData`, `Book.coverImageData` |
| `NSExpressionDescription` per aggregazioni | `StatisticsView.aggregateValue()` |
| `propertiesToGroupBy` (GROUP BY SQL) | `StatisticsView.fetchMostProductiveAuthor()` |
| `NSCompoundPredicate` (AND/OR) | `BooksListView.updateFetchRequest()` |

---

## 2. Architettura {#architettura}

L'applicazione segue il pattern **MVVM** adattato per Core Data con SwiftUI:

```
CoreDataDemoApp
    └── MainTabView
            ├── BooksListView         ← @FetchRequest + filtri dinamici
            │       └── BookDetailView ← @ObservedObject, relazioni
            │               └── AddEditBookView
            │               └── AddReadingSessionView
            ├── AuthorsListView       ← @SectionedFetchRequest
            │       └── AuthorDetailView
            │               └── AddEditAuthorView
            ├── TagsView              ← @FetchRequest, molti-a-molti
            │       └── AddEditTagView
            ├── StatisticsView        ← @StateObject (StatisticsViewModel)
            └── SettingsView          ← Batch ops, Undo/Redo
```

### Flusso dati

```
Persistent Store (SQLite)
        ↕  NSPersistentContainer
NSManagedObjectContext (viewContext — Main Thread)
        ↕  @FetchRequest / @ObservedObject / @StateObject
SwiftUI Views (Main Actor)
```

---

## 3. Modello Dati Core Data {#modello-dati}

Il modello è definito in `CoreDataDemo.xcdatamodeld` e contiene 4 entità.

### Entità Author

```
Author
├── id: UUID
├── name: String  [obbligatorio]
├── biography: String?
├── birthDate: Date?
├── profileImageData: Binary? [External Storage]
├── books: [Book]  →  relazione 1-molti (Cascade delete)
└── tags: [Tag]   ↔   relazione molti-molti
```

### Entità Book

```
Book
├── id: UUID
├── title: String  [obbligatorio]
├── synopsis: String?
├── pageCount: Int32
├── rating: Double (0.0–5.0)
├── isRead: Bool
├── publishedDate: Date?
├── coverImageData: Binary? [External Storage]
├── author: Author?  →  relazione molti-1
├── readingSessions: [ReadingSession]  →  1-molti (Cascade delete)
└── tags: [Tag]  ↔  molti-molti
```

### Entità ReadingSession

```
ReadingSession
├── id: UUID
├── startDate: Date  [obbligatorio]
├── endDate: Date?  (nil = sessione in corso)
├── pagesRead: Int32
├── notes: String?
└── book: Book  →  relazione molti-1
```

### Entità Tag

```
Tag
├── id: UUID
├── name: String  [obbligatorio]
├── colorHex: String  (default: "#007AFF")
├── books: [Book]  ↔  molti-molti
└── authors: [Author]  ↔  molti-molti
```

### Diagramma relazioni

```
Author ──1────────────── ∞── Book ──1──────────────∞── ReadingSession
  │                           │
  └──────∞── Tag ──∞──────────┘
            (molti-a-molti)
```

---

## 4. Stack Core Data {#stack-core-data}

### PersistenceController

Il `PersistenceController` è un singleton che gestisce l'intero stack.

```swift
// Accesso all'istanza condivisa
let persistence = PersistenceController.shared

// Istanza in-memory per preview e test
let preview = PersistenceController.preview
```

#### NSPersistentContainer configurazione

```swift
container.loadPersistentStores { ... }

// Migrazione leggera automatica
description.shouldMigrateStoreAutomatically = true
description.shouldInferMappingModelAutomatically = true

// Persistent History Tracking
description.setOption(true, forKey: NSPersistentHistoryTrackingKey)
```

#### viewContext configurazione

```swift
context.automaticallyMergesChangesFromParent = true   // Merge auto da background
context.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy  // Last writer wins
context.undoManager = UndoManager()                   // Supporto Undo/Redo
context.shouldDeleteInaccessibleFaults = true         // Sicurezza fault
```

---

## 5. Funzionalità Dimostrate {#funzionalita}

### 5.1 CRUD con @FetchRequest

SwiftUI `@FetchRequest` aggiorna automaticamente la view quando i dati cambiano:

```swift
@FetchRequest(
    sortDescriptors: [SortDescriptor(\.title, order: .forward)],
    animation: .default
)
private var books: FetchedResults<Book>
```

Modifica dinamica in runtime (es. cambio di ordinamento o filtro):

```swift
books.sortDescriptors = [SortDescriptor(\.rating, order: .reverse)]
books.nsPredicate = NSPredicate(format: "isRead == YES")
```

### 5.2 @SectionedFetchRequest con sezioni alfabetiche

```swift
@SectionedFetchRequest<String, Author>(
    sectionIdentifier: \.firstLetter,
    sortDescriptors: [SortDescriptor(\.name)]
)
private var authorSections: SectionedFetchResults<String, Author>
```

La proprietà `firstLetter` è `@objc dynamic` per il supporto KVO richiesto da Core Data.

### 5.3 NSCompoundPredicate (AND / OR)

```swift
let titlePredicate  = NSPredicate(format: "title CONTAINS[cd] %@", searchText)
let authorPredicate = NSPredicate(format: "author.name CONTAINS[cd] %@", searchText)

// OR: almeno una delle condizioni deve essere vera
let orPredicate = NSCompoundPredicate(orPredicateWithSubpredicates: [titlePredicate, authorPredicate])

// AND: tutte le condizioni devono essere vere
let andPredicate = NSCompoundPredicate(andPredicateWithSubpredicates: [orPredicate, readPredicate])
```

### 5.4 Query Aggregate con NSFetchRequest

Core Data supporta aggregazioni eseguite direttamente in SQLite:

```swift
let request = NSFetchRequest<NSDictionary>(entityName: "Book")
request.resultType = .dictionaryResultType

// Crea l'espressione SUM(rating)
let expr = NSExpression(forFunction: "average:", arguments: [
    NSExpression(forKeyPath: "rating")
])

let desc = NSExpressionDescription()
desc.name = "avgRating"
desc.expression = expr
desc.expressionResultType = .doubleAttributeType

request.propertiesToFetch = [desc]
```

### 5.5 GROUP BY con NSFetchRequest

Equivalente SQL: `SELECT author.name, COUNT(*) FROM Book GROUP BY author.name`:

```swift
request.resultType = .dictionaryResultType
request.propertiesToFetch   = [authorNameDesc, countDesc]
request.propertiesToGroupBy = ["author.name"]
request.sortDescriptors     = [NSSortDescriptor(key: "bookCount", ascending: false)]
```

### 5.6 NSBatchInsertRequest

Per importare grandi quantità di dati senza passare per il context:

```swift
let objects: [[String: Any]] = bookDicts  // Array di dizionari
let batchInsert = NSBatchInsertRequest(entityName: "Book", objects: objects)
batchInsert.resultType = .objectIDs

let result = try context.execute(batchInsert) as? NSBatchInsertResult
let ids = result?.result as? [NSManagedObjectID] ?? []

// Sincronizza il viewContext con i nuovi oggetti
NSManagedObjectContext.mergeChanges(
    fromRemoteContextSave: [NSInsertedObjectsKey: ids],
    into: [viewContext]
)
```

### 5.7 NSBatchDeleteRequest

Per eliminare molti oggetti senza caricarli in memoria:

```swift
let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Book")
fetchRequest.predicate = NSPredicate(format: "author == nil")

let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
deleteRequest.resultType = .resultTypeObjectIDs

let result = try context.execute(deleteRequest) as? NSBatchDeleteResult
let deletedIDs = result?.result as? [NSManagedObjectID] ?? []

// Propaga la cancellazione al viewContext
NSManagedObjectContext.mergeChanges(
    fromRemoteContextSave: [NSDeletedObjectsKey: deletedIDs],
    into: [viewContext]
)
```

### 5.8 Context di Background

```swift
// Esegue il blocco su un thread background dedicato
container.performBackgroundTask { bgContext in
    // Fetch, modifica, salva
    let books = try bgContext.fetch(request)
    books.forEach { $0.synopsis = "..." }
    try bgContext.save()  // Il viewContext si aggiorna automaticamente
}
```

### 5.9 Undo / Redo

```swift
// Configura l'UndoManager sul viewContext
context.undoManager = UndoManager()

// Raggruppa le azioni per un singolo undo
context.undoManager?.beginUndoGrouping()
context.undoManager?.setActionName("Elimina libro")
context.delete(book)
context.undoManager?.endUndoGrouping()

// Annulla
context.undoManager?.undo()

// Ripeti
context.undoManager?.redo()
```

### 5.10 Validazione Personalizzata

```swift
override public func validateForInsert() throws {
    try super.validateForInsert()
    guard !name.trimmingCharacters(in: .whitespaces).isEmpty else {
        throw NSError(
            domain: NSCocoaErrorDomain,
            code: NSValidationMissingMandatoryPropertyError,
            userInfo: [NSLocalizedDescriptionKey: "Il nome non può essere vuoto."]
        )
    }
}
```

### 5.11 External Binary Storage

Gli attributi `Binary Data` con `Allows External Storage` abilitato vengono archiviati automaticamente come file separati quando superano ~1MB:

```
// Nel modello .xcdatamodel:
<attribute name="coverImageData" attributeType="Binary" allowsExternalBinaryDataStorage="YES"/>
```

Core Data gestisce automaticamente la soglia e l'archiviazione esterna.

### 5.12 Migrazione Leggera Automatica

La migrazione leggera gestisce automaticamente:
- Aggiunta di nuovi attributi opzionali
- Rimozione di attributi
- Rinomina di entità/attributi (con mapping model)

```swift
description.shouldMigrateStoreAutomatically = true
description.shouldInferMappingModelAutomatically = true
```

---

## 6. Struttura dei File {#struttura-file}

```
CoreDataDemo/
├── CoreDataDemoApp.swift               ← Entry point, injection @Environment
├── ContentView.swift                   ← Wrapper per MainTabView
│
├── CoreDataDemo.xcdatamodeld/          ← Modello Core Data
│   └── CoreDataDemo.xcdatamodel/
│       └── contents                   ← XML del modello
│
├── Persistence/
│   └── PersistenceController.swift    ← Stack Core Data, batch ops, undo
│
├── Models/                            ← NSManagedObject subclasses (manuale)
│   ├── Author+CoreDataClass.swift
│   ├── Author+CoreDataProperties.swift
│   ├── Book+CoreDataClass.swift
│   ├── Book+CoreDataProperties.swift
│   ├── Tag+CoreDataClass.swift
│   ├── Tag+CoreDataProperties.swift
│   ├── ReadingSession+CoreDataClass.swift
│   └── ReadingSession+CoreDataProperties.swift
│
└── Views/
    ├── MainTabView.swift
    ├── Books/
    │   ├── BooksListView.swift        ← @FetchRequest dinamico, search, filter
    │   ├── BookDetailView.swift       ← Relazioni, rating, progress
    │   ├── AddEditBookView.swift      ← CRUD, picker autore, multi-tag
    │   └── AddReadingSessionView.swift
    ├── Authors/
    │   ├── AuthorsListView.swift      ← @SectionedFetchRequest
    │   ├── AuthorDetailView.swift
    │   └── AddEditAuthorView.swift
    ├── Tags/
    │   └── TagsView.swift             ← Molti-a-molti, color picker
    ├── Statistics/
    │   └── StatisticsView.swift       ← Query aggregate, GROUP BY
    └── Settings/
        └── SettingsView.swift         ← Batch ops, undo/redo, info store
```

---

## 7. Pattern e Best Practices {#best-practices}

### Pattern Factory per NSManagedObject

Evita di dimenticare campi obbligatori centralizzando la creazione:

```swift
static func create(name: String, in context: NSManagedObjectContext) -> Author {
    let author = Author(context: context)
    author.id   = UUID()  // Sempre assegna un UUID
    author.name = name
    return author
}
```

### Separazione Class / Properties

Apple raccomanda di separare le subclassi in due file:
- `Entity+CoreDataClass.swift` — logica di business, factory, validazione
- `Entity+CoreDataProperties.swift` — `@NSManaged` properties, accessor relazioni

### Proprietà calcolate type-safe per le relazioni

Le relazioni Core Data sono `NSSet`; le computed properties le espongono come `Array<T>`:

```swift
var booksArray: [Book] {
    let set = books as? Set<Book> ?? []
    return set.sorted { $0.title < $1.title }
}
```

### Rollback su Annullamento Form

Quando l'utente annulla un form, usa `rollback()` per scartare le modifiche pendenti:

```swift
Button("Annulla") {
    viewContext.rollback()  // Scarta tutte le modifiche non salvate
    dismiss()
}
```

### Aggiornamento viewContext dopo Batch Operations

Le batch operations bypassano il context; è necessario sincronizzare manualmente:

```swift
NSManagedObjectContext.mergeChanges(
    fromRemoteContextSave: [NSDeletedObjectsKey: deletedIDs],
    into: [container.viewContext]
)
```

### Iniezione del Context via @Environment

Il context viene iniettato dalla radice dell'app ed è disponibile in tutta la gerarchia:

```swift
// In CoreDataDemoApp
.environment(\.managedObjectContext, persistenceController.viewContext)

// In qualsiasi view figlia
@Environment(\.managedObjectContext) private var viewContext
```

### Conformità a Sendable per Swift 6

In Swift 6, `NSManagedObject` non è `Sendable`. Il `PersistenceController` viene marcato `@unchecked Sendable` perché la thread safety è garantita da Core Data internamente:

```swift
final class PersistenceController: @unchecked Sendable { ... }
```

---

## 8. Guida Rapida all'Uso {#guida-uso}

### Primo avvio

L'app parte vuota. Puoi:
1. Aggiungere autori dalla scheda **Autori** → `+`
2. Aggiungere libri dalla scheda **Libri** → `+`
3. Associare tag dalla scheda **Tag** (crea prima i tag)
4. Registrare sessioni di lettura dal dettaglio di un libro

### Preview Xcode

I canvas SwiftUI usano `PersistenceController.preview` che carica automaticamente dati di esempio (4 autori, 6 libri, 5 tag, 7 sessioni).

### Testare le funzionalità avanzate

| Funzionalità | Come testarla |
|---|---|
| Undo/Redo | Scheda Impostazioni → sezione Undo/Redo |
| Batch Insert | Scheda Impostazioni → "Batch Insert 50 libri" |
| Batch Delete | Scheda Impostazioni → "Batch Delete libri senza autore" |
| Background context | Scheda Impostazioni → "Operazione Background" |
| Query aggregate | Scheda Statistiche |
| Filtri e ricerca | Scheda Libri → barra di ricerca + filtro stato |
| Sezioni alfabetiche | Scheda Autori |
| Relazione molti-a-molti | Aggiungi/modifica libro → seleziona più tag |
| Eliminazione cascata | Elimina un autore → i suoi libri vengono eliminati |

---

## Note tecniche

- Il modello Core Data usa `codeGenerationType="manual"` per permettere il controllo totale delle subclassi.
- Tutti i `@NSManaged` accessor sono nel file `+CoreDataProperties.swift` per rispettare la convenzione Apple.
- Le view usano `@ObservedObject` per gli `NSManagedObject` già esistenti (non `@StateObject`).
- Il `PersistenceController` registra listener per `NSManagedObjectContextDidSave` nella `StatisticsView` per aggiornare automaticamente le statistiche.
- Il modello sfrutta `allowsExternalBinaryDataStorage = YES` per immagini di profilo e copertine libri.

---

*Documentazione generata per CoreDataDemo — iOS 26 / Swift 6.3 / Xcode 26*
