//
// FeatureFlagService.swift
// CoreKit
//
// Protocollo e implementazione del servizio di gestione feature flag.
//
// PRINCIPIO: Dependency Inversion
// I componenti che dipendono dai flag devono dipendere dal PROTOCOLLO,
// non dall'implementazione concreta. Questo permette di sostituire il
// servizio con mock durante i test o con implementazioni remote in produzione.
//

import Foundation

// MARK: - Protocollo

/// Contratto del servizio per la gestione dei feature flag.
///
/// In un'app reale esisterebbero più implementazioni di questo protocollo:
/// - `LocalFeatureFlagService`: valori hardcoded per sviluppo
/// - `RemoteFeatureFlagService`: valori da Firebase Remote Config / LaunchDarkly
/// - `MockFeatureFlagService`: valori configurabili per unit test
public protocol FeatureFlagServiceProtocol: AnyObject {

    /// Restituisce il valore corrente per la feature flag specificata.
    /// Se non è presente un override, viene restituito il `defaultValue` del flag.
    /// - Parameter flag: La feature flag da interrogare
    /// - Returns: Il valore configurato o il valore di default del flag
    func value<T>(for flag: FeatureFlag<T>) -> T

    /// Verifica se un flag booleano è abilitato.
    /// Metodo di convenienza che evita il boilerplate del cast esplicito.
    /// - Parameter flag: Il flag booleano da verificare
    /// - Returns: `true` se il flag è abilitato, `false` altrimenti
    func isEnabled(_ flag: FeatureFlag<Bool>) -> Bool
}

// MARK: - Implementazione Concreta

/// Implementazione del servizio feature flag basata su un dizionario di override.
///
/// Supporta la modifica a runtime dei valori per facilitare:
/// - Il testing manuale durante lo sviluppo
/// - La demo di un pannello debug in-app
/// - Il reset rapido delle configurazioni
///
/// Conformance a `@unchecked Sendable` perché l'accesso al dizionario
/// interno è protetto da `NSLock` (thread-safe ma non verificabile dal compiler).
///
/// In produzione si sostituirebbe questa classe con:
/// ```swift
/// class FirebaseFeatureFlagService: FeatureFlagServiceProtocol {
///     func value<T>(for flag: FeatureFlag<T>) -> T {
///         remoteConfig[flag.key].as(T.self) ?? flag.defaultValue
///     }
/// }
/// ```
public final class FeatureFlagService: FeatureFlagServiceProtocol, @unchecked Sendable {

    // MARK: - Stato Interno

    /// Dizionario degli override. La chiave è il `key` del FeatureFlag.
    private var overrides: [String: Any]

    /// Lock per garantire accesso thread-safe al dizionario degli override
    private let lock = NSLock()

    // MARK: - Inizializzazione

    /// Crea un nuovo servizio con un dizionario opzionale di override iniziali.
    /// - Parameter overrides: Dizionario chiave-valore per sovrascrivere i valori di default.
    ///   Chiavi non trovate usano automaticamente il `defaultValue` del flag.
    public init(overrides: [String: Any] = [:]) {
        self.overrides = overrides
    }

    // MARK: - FeatureFlagServiceProtocol

    public func value<T>(for flag: FeatureFlag<T>) -> T {
        lock.withLock {
            overrides[flag.key] as? T ?? flag.defaultValue
        }
    }

    public func isEnabled(_ flag: FeatureFlag<Bool>) -> Bool {
        value(for: flag)
    }

    // MARK: - Modifica Runtime (per debug e testing)

    /// Imposta il valore di un flag a runtime.
    /// Utile per il pannello debug in-app o per i test di integrazione.
    /// - Parameters:
    ///   - value: Nuovo valore da impostare
    ///   - flag: Il flag da modificare
    public func setValue<T>(_ value: T, for flag: FeatureFlag<T>) {
        lock.withLock {
            overrides[flag.key] = value
        }
    }

    /// Inverte il valore corrente di un flag booleano.
    /// Utile per i Toggle nell'interfaccia del pannello debug.
    /// - Parameter flag: Il flag booleano da invertire
    public func toggle(_ flag: FeatureFlag<Bool>) {
        let current = isEnabled(flag)
        setValue(!current, for: flag)
    }
}
