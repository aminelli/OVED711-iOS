//
// DependencyContainer.swift
// CoreKit
//
// Contenitore IoC (Inversion of Control) generico per la Dependency Injection.
//
// NOTA ARCHITETTURALE:
// In questo progetto demo, il Composition Root è implementato direttamente
// in AppDependencyContainer (layer app) che costruisce il grafo delle dipendenze
// in modo esplicito e type-safe. Questo DependencyContainer generico è incluso
// per mostrare il pattern alternativo basato su reflection-style lookup.
//
// In progetti più grandi si potrebbe usare:
// - Swinject, Needle, Factory (librerie DI per Swift)
// - Un approccio basato su Environment di SwiftUI
// - Questo contenitore generico con chiavi per tipo
//

import Foundation

// MARK: - Protocollo

/// Protocollo per i contenitori di dipendenze.
/// Definisce l'interfaccia minima per registrare e risolvere le dipendenze.
///
/// Usare il protocollo invece della classe concreta permette di
/// sostituire l'implementazione nei test o per ambienti diversi.
public protocol DependencyContainerProtocol: AnyObject {

    /// Registra una factory che verrà invocata ad ogni risoluzione.
    /// La factory viene chiamata lazily (al momento della risoluzione, non della registrazione).
    /// - Parameters:
    ///   - type: Il tipo (solitamente un protocollo) da registrare
    ///   - factory: Closure che crea e restituisce un'istanza del tipo
    func register<T>(_ type: T.Type, factory: @escaping () -> T)

    /// Risolve e restituisce un'istanza del tipo specificato.
    /// - Parameter type: Il tipo da risolvere
    /// - Returns: L'istanza creata dalla factory, o `nil` se il tipo non è registrato
    func resolve<T>(_ type: T.Type) -> T?
}

// MARK: - Implementazione

/// Contenitore IoC thread-safe basato su un registro di factory.
///
/// Le dipendenze vengono create su richiesta (lazy initialization).
/// Ogni chiamata a `resolve` crea una NUOVA istanza (transient scope).
///
/// Per un singleton scope, la factory dovrebbe catturare e riutilizzare
/// l'istanza:
/// ```swift
/// var sharedService: MyService?
/// container.register(MyServiceProtocol.self) {
///     if sharedService == nil { sharedService = MyService() }
///     return sharedService!
/// }
/// ```
public final class DependencyContainer: DependencyContainerProtocol {

    /// Registro delle factory, indicizzato per l'`ObjectIdentifier` del tipo
    private var factories: [ObjectIdentifier: () -> Any] = [:]

    /// Lock per garantire thread-safety durante registrazione e risoluzione
    private let lock = NSLock()

    public init() {}

    public func register<T>(_ type: T.Type, factory: @escaping () -> T) {
        lock.withLock {
            factories[ObjectIdentifier(type)] = factory
        }
    }

    public func resolve<T>(_ type: T.Type) -> T? {
        lock.withLock {
            factories[ObjectIdentifier(type)]?() as? T
        }
    }
}
