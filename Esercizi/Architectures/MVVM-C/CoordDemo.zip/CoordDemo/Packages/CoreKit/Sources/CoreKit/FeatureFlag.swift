//
// FeatureFlag.swift
// CoreKit
//
// Definisce il tipo generico FeatureFlag<T> e il namespace AppFeatureFlags
// con tutti i flag dell'applicazione centralizzati in un unico punto.
//
// PATTERN: Typed Feature Flags
// Usando un tipo generico parametrico evitiamo magic string e garantiamo
// la sicurezza dei tipi a compile time.
//

import Foundation

// MARK: - Tipo Base

/// Rappresenta una singola feature flag tipizzata.
///
/// Il parametro generico `T` definisce il tipo di valore del flag:
/// - `Bool` per feature on/off
/// - `String` per varianti di testo
/// - `Int` per configurazioni numeriche
///
/// Esempio:
/// ```swift
/// let flag = FeatureFlag<Bool>(key: "show_banner", defaultValue: false)
/// let isEnabled = service.isEnabled(flag)
/// ```
public struct FeatureFlag<T: Sendable>: Sendable {

    /// Chiave univoca del flag, usata come identificatore nel servizio
    public let key: String

    /// Valore di default del flag, usato quando non è presente un override.
    /// Permette di far funzionare l'app anche senza configurazione esplicita.
    public let defaultValue: T

    /// Descrizione human-readable del flag (per il pannello debug)
    public let description: String

    /// Crea una nuova feature flag con chiave, valore di default e descrizione
    /// - Parameters:
    ///   - key: Identificatore univoco del flag (usare snake_case)
    ///   - defaultValue: Valore usato in assenza di configurazione esplicita
    ///   - description: Descrizione leggibile per scopi di debug
    public init(key: String, defaultValue: T, description: String = "") {
        self.key = key
        self.defaultValue = defaultValue
        self.description = description
    }
}

// MARK: - Namespace dei Flag dell'Applicazione

/// Namespace centralizzato per tutte le feature flag dell'applicazione.
///
/// L'uso di un `enum` senza casi garantisce che non possa essere istanziato
/// e funge da namespace puro (analogo a uno static class in altri linguaggi).
///
/// Aggiungere nuovi flag qui è l'UNICO punto di modifica necessario per
/// introdurre una nuova feature flag nell'applicazione.
public enum AppFeatureFlags {

    /// Controlla la visibilità del nome dell'autore nella lista dei post.
    /// Utile per testare layout con e senza metadati aggiuntivi.
    public static let showPostAuthor = FeatureFlag<Bool>(
        key: "show_post_author",
        defaultValue: true,
        description: "Mostra il nome dell'autore nella lista post"
    )

    /// Abilita o disabilita la navigazione alla vista di dettaglio del post.
    /// Con il flag disabilitato, il tap sulla riga non provoca navigazione.
    public static let enableDetailView = FeatureFlag<Bool>(
        key: "enable_detail_view",
        defaultValue: true,
        description: "Abilita la navigazione al dettaglio del post"
    )

    /// Attiva il nuovo layout sperimentale per la vista di dettaglio.
    /// Disabilitato di default perché ancora in fase di sviluppo.
    public static let useNewDetailLayout = FeatureFlag<Bool>(
        key: "use_new_detail_layout",
        defaultValue: false,
        description: "Usa il nuovo layout per il dettaglio post (sperimentale)"
    )

    /// Lista di tutti i flag booleani disponibili, usata dal pannello debug
    public static let allBoolFlags: [FeatureFlag<Bool>] = [
        showPostAuthor,
        enableDetailView,
        useNewDetailLayout
    ]
}
