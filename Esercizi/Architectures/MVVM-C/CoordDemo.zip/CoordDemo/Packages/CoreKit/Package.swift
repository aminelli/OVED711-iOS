// swift-tools-version: 6.0
//
// Package.swift - CoreKit
//
// Modulo CoreKit: infrastrutture condivise dell'applicazione.
// Fornisce il sistema di Feature Flag e il contenitore IoC per la
// Dependency Injection. Non ha dipendenze esterne (è il layer più interno
// dopo Domain).
//
// Dipendenze:
//   CoreKit → (nessuna dipendenza esterna)

import PackageDescription

let package = Package(
    name: "CoreKit",
    platforms: [
        // Requisito minimo per @Observable (Observation framework)
        .iOS(.v17)
    ],
    products: [
        // Libreria pubblica importabile dagli altri moduli e dall'app
        .library(name: "CoreKit", targets: ["CoreKit"]),
    ],
    targets: [
        .target(
            name: "CoreKit",
            path: "Sources/CoreKit"
        ),
        .testTarget(
            name: "CoreKitTests",
            dependencies: ["CoreKit"],
            path: "Tests/CoreKitTests"
        ),
    ]
)
