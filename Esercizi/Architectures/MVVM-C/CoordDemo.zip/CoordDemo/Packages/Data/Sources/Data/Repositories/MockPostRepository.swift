//
// MockPostRepository.swift
// Data
//
// Implementazione mock del PostRepositoryProtocol.
//
// Scopo di questa classe:
// 1. Permettere lo sviluppo dell'app senza un backend reale
// 2. Fornire dati stabili e controllati per i test
// 3. Simulare la latenza di rete per un comportamento realistico
// 4. Fungere da documentazione vivente della struttura dei dati attesi
//
// In produzione questa classe verrebbe sostituita da:
//   NetworkPostRepository: chiama un'API REST
//   CoreDataPostRepository: legge da un database locale
//   CachedPostRepository: decorator che aggiunge cache alla versione network
//
// Grazie alla Dependency Inversion (protocollo nel Domain layer),
// NESSUN componente esterno al Data layer deve essere modificato
// per passare dal Mock all'implementazione reale.
//

import Foundation
import Domain

/// Implementazione mock del `PostRepositoryProtocol`.
///
/// Fornisce dati locali predefiniti che illustrano i concetti di
/// Clean Architecture e MVVM-C discussi nel progetto.
///
/// Conformance a `Sendable`: questa classe ha solo proprietà `let`
/// immutabili di tipo `Sendable` (array di struct Sendable), quindi
/// è intrinsecamente thread-safe e può conformare a `Sendable`.
public final class MockPostRepository: PostRepositoryProtocol, Sendable {

    // MARK: - Dati Mock

    /// Post di esempio: ognuno tratta un aspetto dell'architettura dimostrata
    private let posts: [Post] = [
        Post(
            id: 1,
            title: "Clean Architecture in iOS",
            body: "La Clean Architecture separa le responsabilità in layer distinti: Domain, Data e Presentation. Ogni layer ha una responsabilità precisa e dipende solo dai layer più interni.",
            userId: 1
        ),
        Post(
            id: 2,
            title: "Pattern MVVM-C",
            body: "Il pattern MVVM con Coordinator separa la logica di navigazione dalla View e dal ViewModel. Il Coordinator è l'unico responsabile del flusso di navigazione.",
            userId: 1
        ),
        Post(
            id: 3,
            title: "Swift 6 Concurrency",
            body: "Swift 6 introduce un modello di concorrenza robusto basato su async/await, actor e Sendable. Il compilatore verifica l'isolamento dei dati a compile time.",
            userId: 2
        ),
        Post(
            id: 4,
            title: "Dependency Injection",
            body: "L'iniezione delle dipendenze migliora la testabilità e riduce l'accoppiamento. Il Composition Root è l'unico punto in cui si assembla il grafo delle dipendenze.",
            userId: 2
        ),
        Post(
            id: 5,
            title: "Feature Flags",
            body: "I feature flag permettono di attivare funzionalità a runtime senza nuovi rilasci. Con flag tipizzati e un servizio centralizzato, la gestione è type-safe e scalabile.",
            userId: 3
        ),
        Post(
            id: 6,
            title: "Swift Package Manager",
            body: "SPM permette di organizzare il codice in moduli con confini espliciti. Ogni pacchetto espone solo le API pubbliche necessarie, riducendo l'accoppiamento e migliorando i tempi di build.",
            userId: 3
        ),
    ]

    /// Utenti di esempio associati ai post
    private let users: [User] = [
        User(id: 1, name: "Alice Martin", email: "alice@example.com"),
        User(id: 2, name: "Bob Johnson", email: "bob@example.com"),
        User(id: 3, name: "Carol White", email: "carol@example.com"),
    ]

    public init() {}

    // MARK: - PostRepositoryProtocol

    public func fetchPosts() async throws -> [Post] {
        // Simulazione di latenza di rete realistica (300-500ms)
        try await Task.sleep(for: .milliseconds(400))
        return posts
    }

    public func fetchPost(id: Int) async throws -> Post {
        try await Task.sleep(for: .milliseconds(200))
        guard let post = posts.first(where: { $0.id == id }) else {
            throw RepositoryError.notFound(id: id)
        }
        return post
    }

    public func fetchUser(id: Int) async throws -> User {
        try await Task.sleep(for: .milliseconds(150))
        guard let user = users.first(where: { $0.id == id }) else {
            throw RepositoryError.notFound(id: id)
        }
        return user
    }
}
