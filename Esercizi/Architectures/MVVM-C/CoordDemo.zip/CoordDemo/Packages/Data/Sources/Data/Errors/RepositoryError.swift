//
// RepositoryError.swift
// Data
//
// Errori specifici del layer Data.
//
// NOTA: Questi errori vivono nel Data layer (non nel Domain) perché
// sono specifici delle operazioni di I/O. Il Domain layer non conosce
// questi tipi: i Use Case propagano l'errore come `Error` generico.
// Il ViewModel decide come presentarlo all'utente.
//

import Foundation

/// Errori che possono verificarsi durante le operazioni del repository.
///
/// Conformando a `LocalizedError`, questi errori producono messaggi
/// leggibili dall'utente tramite `error.localizedDescription`.
///
/// Conformando a `Sendable`, possono essere propagati attraverso
/// contesti `async` senza problemi di concorrenza in Swift 6.
public enum RepositoryError: LocalizedError, Sendable {

    /// La risorsa richiesta non è stata trovata nel data source
    case notFound(id: Int)

    /// Si è verificato un errore durante la comunicazione di rete
    case networkError(String)

    /// I dati ricevuti non sono nel formato atteso (JSON malformato, schema cambiato, ecc.)
    case invalidData

    // MARK: - LocalizedError

    public var errorDescription: String? {
        switch self {
        case .notFound(let id):
            return "Risorsa con id \(id) non trovata."
        case .networkError(let message):
            return "Errore di rete: \(message)"
        case .invalidData:
            return "I dati ricevuti non sono validi o non sono nel formato atteso."
        }
    }

    public var failureReason: String? {
        switch self {
        case .notFound:
            return "L'elemento potrebbe essere stato eliminato o non essere mai esistito."
        case .networkError:
            return "Verifica la connessione a internet e riprova."
        case .invalidData:
            return "Il server potrebbe aver restituito una risposta inattesa."
        }
    }
}
