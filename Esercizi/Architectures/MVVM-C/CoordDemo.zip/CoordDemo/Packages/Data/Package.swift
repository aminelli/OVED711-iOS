// swift-tools-version: 6.0
//
// Package.swift - Data
//
// Modulo Data: implementazioni concrete dei repository definiti nel Domain.
// Questo modulo è responsabile di COME i dati vengono recuperati e persistiti,
// non di COSA i dati significano (quello è compito del Domain).
//
// Contiene:
//   - Implementazioni mock/reali dei repository
//   - DTO (Data Transfer Object) per la serializzazione
//   - Data sources (network, database locale, cache)
//   - Mappatori DTO → Entità di dominio
//
// Dipendenze:
//   Data → Domain (per i protocolli e le entità)
//   Data → (nessuna dipendenza da CoreKit o Presentation)

import PackageDescription

let package = Package(
    name: "Data",
    platforms: [
        .iOS(.v17)
    ],
    products: [
        .library(name: "Data", targets: ["Data"]),
    ],
    dependencies: [
        // Il modulo Data dipende dal Domain per i protocolli e le entità.
        // Questa è l'unica dipendenza consentita verso l'interno.
        .package(path: "../Domain"),
    ],
    targets: [
        .target(
            name: "Data",
            dependencies: ["Domain"],
            path: "Sources/Data"
        ),
        .testTarget(
            name: "DataTests",
            dependencies: ["Data", "Domain"],
            path: "Tests/DataTests"
        ),
    ]
)
