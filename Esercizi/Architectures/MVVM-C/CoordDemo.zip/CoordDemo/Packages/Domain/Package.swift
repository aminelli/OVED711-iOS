// swift-tools-version: 6.0
//
// Package.swift - Domain
//
// Modulo Domain: cuore della business logic (layer più interno).
// Contiene entità di dominio, protocolli dei repository e casi d'uso.
//
// REGOLA FONDAMENTALE: questo modulo NON ha dipendenze esterne.
// Non conosce UIKit, SwiftUI, CoreKit, Data, né framework di terze parti.
// Questa purezza garantisce:
//   - Massima testabilità (nessun mock di framework)
//   - Portabilità (funziona su iOS, macOS, watchOS, ecc.)
//   - Longevità (resiste ai cambi di framework)
//
// Dipendenze:
//   Domain → (nessuna dipendenza)

import PackageDescription

let package = Package(
    name: "Domain",
    platforms: [
        .iOS(.v17)
    ],
    products: [
        .library(name: "Domain", targets: ["Domain"]),
    ],
    targets: [
        .target(
            name: "Domain",
            path: "Sources/Domain"
        ),
        .testTarget(
            name: "DomainTests",
            dependencies: ["Domain"],
            path: "Tests/DomainTests"
        ),
    ]
)
