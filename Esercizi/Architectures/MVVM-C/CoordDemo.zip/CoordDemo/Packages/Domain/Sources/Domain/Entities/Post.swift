//
// Post.swift
// Domain
//
// Entità di dominio che rappresenta un post/articolo.
//
// Le entità del Domain layer:
// - Sono tipi di valore puri (struct) senza dipendenze esterne
// - Incapsulano le invarianti di business
// - Conformano a Sendable per la compatibilità con Swift 6 Concurrency
// - Conformano a Hashable per poter essere usate in NavigationStack (AppRoute)
//

import Foundation

/// Entità di dominio che rappresenta un articolo o post pubblicato.
///
/// Questa struct è al centro dell'architettura: tutti i layer (Data, Presentation)
/// lavorano con questo tipo o con wrapper che lo contengono.
///
/// L'uso di `struct` (tipo di valore) garantisce:
/// - Semantica di uguaglianza basata sul contenuto (non sull'identità)
/// - Thread-safety implicita (copiata, non condivisa per riferimento)
/// - Immutabilità per default (tutte le proprietà sono `let`)
public struct Post: Identifiable, Hashable, Sendable {

    /// Identificatore univoco del post
    public let id: Int

    /// Titolo del post
    public let title: String

    /// Corpo testuale completo del post
    public let body: String

    /// Identificatore dell'utente autore del post.
    /// Usato per recuperare le informazioni sull'autore tramite il repository.
    public let userId: Int

    public init(id: Int, title: String, body: String, userId: Int) {
        self.id = id
        self.title = title
        self.body = body
        self.userId = userId
    }
}
