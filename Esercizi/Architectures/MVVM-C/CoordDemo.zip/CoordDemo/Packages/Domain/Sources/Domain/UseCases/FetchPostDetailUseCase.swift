//
// FetchPostDetailUseCase.swift
// Domain
//
// Caso d'uso per il recupero del dettaglio di un post con informazioni sull'autore.
//
// Dimostra come un Use Case possa aggregare dati da più chiamate al repository
// per produrre una risposta arricchita e coerente per il layer di presentazione.
//

import Foundation

// MARK: - Aggregato di Risposta

/// Aggregato di dominio che combina un post con le informazioni sull'autore.
///
/// Questo tipo rappresenta la "risposta" del caso d'uso: non è
/// un'entità di dominio pura, ma un aggregato costruito per soddisfare
/// le esigenze del layer di presentazione mantenendo la logica nel Domain.
///
/// Pattern: "Query Result" o "Output DTO del Domain"
public struct PostDetail: Equatable, Sendable {

    /// Il post principale
    public let post: Post

    /// L'autore del post, recuperato separatamente tramite userId
    public let author: User

    public init(post: Post, author: User) {
        self.post = post
        self.author = author
    }
}

// MARK: - Protocollo

/// Protocollo del caso d'uso per il recupero del dettaglio di un post
public protocol FetchPostDetailUseCaseProtocol: Sendable {

    /// Esegue il recupero del dettaglio completo di un post.
    /// - Parameter postId: Identificatore del post da recuperare
    /// - Returns: Aggregato contenente post e autore
    /// - Throws: `RepositoryError.notFound` se il post o l'utente non esistono
    func execute(postId: Int) async throws -> PostDetail
}

// MARK: - Implementazione

/// Implementazione del caso d'uso per il dettaglio del post.
///
/// Recupera il post e poi il relativo autore. Le due operazioni sono
/// sequenziali perché la seconda dipende dal risultato della prima
/// (lo `userId` è contenuto nel post).
///
/// Se in futuro il repository esporrà un endpoint che restituisce
/// direttamente il `PostDetail`, questo use case dovrà essere il
/// SOLO punto da modificare: nessun ViewModel cambierà.
public final class FetchPostDetailUseCase: FetchPostDetailUseCaseProtocol {

    private let repository: PostRepositoryProtocol

    public init(repository: PostRepositoryProtocol) {
        self.repository = repository
    }

    public func execute(postId: Int) async throws -> PostDetail {
        // Prima recuperiamo il post per ottenere lo userId dell'autore
        let post = try await repository.fetchPost(id: postId)

        // Poi recuperiamo l'autore usando l'id ottenuto dal post
        let author = try await repository.fetchUser(id: post.userId)

        // Costruiamo e restituiamo l'aggregato
        return PostDetail(post: post, author: author)
    }
}
