//
// PostRepositoryProtocol.swift
// Domain
//
// Definisce il contratto del repository per post e utenti.
//
// PRINCIPIO CHIAVE - Dependency Inversion:
// Il protocollo VIVE nel Domain layer, ma l'IMPLEMENTAZIONE sta nel Data layer.
//
// Questo inverte la dipendenza tradizionale:
//   Tradizionale:  Domain → Data (il Domain dipende dal Data)
//   Clean Arch:    Data → Domain (il Data dipende dal Domain)
//
// Il Domain non sa CHI implementerà questo protocollo, né COME.
// Potrebbe essere un database locale, un'API REST, un servizio GraphQL:
// il Domain è completamente indifferente.
//

import Foundation

/// Contratto del repository per la gestione di post e utenti.
///
/// La presenza del protocollo nel Domain layer è il meccanismo che
/// implementa il "Dependency Inversion Principle" (lettera D di SOLID):
///
/// - I moduli di alto livello (Domain/UseCases) non dipendono da
///   moduli di basso livello (Data/Networking)
/// - Entrambi dipendono da astrazioni (questo protocollo)
/// - Le astrazioni non dipendono dai dettagli
///
/// Conformance a `Sendable`: i repository vengono chiamati da contesti
/// `async` e devono poter essere passati attraverso i confini degli actor.
public protocol PostRepositoryProtocol: Sendable {

    /// Recupera l'elenco completo dei post disponibili.
    /// - Returns: Array di post (potenzialmente vuoto)
    /// - Throws: `RepositoryError` o altro errore in caso di fallimento
    func fetchPosts() async throws -> [Post]

    /// Recupera un singolo post tramite il suo identificatore.
    /// - Parameter id: Identificatore univoco del post
    /// - Returns: Il post corrispondente all'id
    /// - Throws: `RepositoryError.notFound` se il post non esiste
    func fetchPost(id: Int) async throws -> Post

    /// Recupera un utente tramite il suo identificatore.
    /// - Parameter id: Identificatore univoco dell'utente
    /// - Returns: L'utente corrispondente all'id
    /// - Throws: `RepositoryError.notFound` se l'utente non esiste
    func fetchUser(id: Int) async throws -> User
}
