//
// FetchPostsUseCase.swift
// Domain
//
// Caso d'uso per il recupero della lista di post.
//
// I casi d'uso (Use Case / Interactor) sono il cuore della business logic.
// Ogni Use Case:
// - Rappresenta UNA singola operazione di business
// - Dipende dal protocollo del repository (mai dall'implementazione)
// - È facilmente testabile in isolamento con repository mock
// - Non sa nulla di SwiftUI, UIKit o della persistenza
//

import Foundation

// MARK: - Protocollo

/// Protocollo del caso d'uso per il recupero della lista di post.
///
/// Separare il protocollo dall'implementazione permette di:
/// - Sostituire la logica di business nei test senza toccare i ViewModel
/// - Avere implementazioni diverse per ambienti diversi (dev/staging/prod)
public protocol FetchPostsUseCaseProtocol: Sendable {

    /// Esegue il recupero della lista di post.
    /// - Returns: Array di post ordinati per rilevanza
    /// - Throws: Errore propagato dal repository in caso di fallimento
    func execute() async throws -> [Post]
}

// MARK: - Implementazione

/// Implementazione del caso d'uso per il recupero dei post.
///
/// Questo use case è volutamente semplice per mostrare la struttura.
/// In scenari reali potrebbe includere:
/// - Paginazione: `execute(page: Int, pageSize: Int)`
/// - Filtri: `execute(filter: PostFilter)`
/// - Ordinamento: applicato alle entità prima di restituirle
/// - Cache: coordinando repository locale e remoto
public final class FetchPostsUseCase: FetchPostsUseCaseProtocol {

    // Il repository è iniettato come dipendenza (non creato qui)
    private let repository: PostRepositoryProtocol

    /// Inizializza il caso d'uso con il repository fornito.
    /// - Parameter repository: Implementazione del repository (mock o reale)
    public init(repository: PostRepositoryProtocol) {
        self.repository = repository
    }

    public func execute() async throws -> [Post] {
        // Recupero diretto dal repository.
        // In un'app reale qui ci potrebbe essere logica aggiuntiva:
        //   let posts = try await repository.fetchPosts()
        //   return posts.sorted { $0.id < $1.id }
        try await repository.fetchPosts()
    }
}
