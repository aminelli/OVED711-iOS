//
// User.swift
// Domain
//
// Entità di dominio che rappresenta un utente dell'applicazione.
//

import Foundation

/// Entità di dominio che rappresenta un utente/autore.
///
/// Come `Post`, anche `User` è una struct immutabile priva di
/// dipendenze esterne. La sua semplicità è intenzionale: le entità
/// del domain layer devono rappresentare solo i dati e le regole di
/// business fondamentali, senza logica di presentazione o persistenza.
public struct User: Identifiable, Hashable, Sendable {

    /// Identificatore univoco dell'utente
    public let id: Int

    /// Nome completo dell'utente
    public let name: String

    /// Indirizzo email dell'utente
    public let email: String

    public init(id: Int, name: String, email: String) {
        self.id = id
        self.name = name
        self.email = email
    }
}
