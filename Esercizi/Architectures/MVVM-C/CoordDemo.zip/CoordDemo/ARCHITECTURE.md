# CoordDemo — Architettura MVVM-C con Clean Architecture

> Documentazione tecnica del progetto dimostrativo.  
> Linguaggio: Swift 6.3 · Piattaforma: iOS 26+ · IDE: Xcode 26.3

---

## Indice

1. [Panoramica](#panoramica)
2. [Struttura dei Layer](#struttura-dei-layer)
3. [Pattern MVVM-C](#pattern-mvvm-c)
4. [Moduli Swift Package Manager](#moduli-swift-package-manager)
5. [Sistema di Feature Flag](#sistema-di-feature-flag)
6. [Dependency Rule](#dependency-rule)
7. [Flusso di un'operazione tipica](#flusso-di-unoperazione-tipica)
8. [Setup del progetto Xcode](#setup-del-progetto-xcode)
9. [Estensioni future](#estensioni-future)

---

## Panoramica

Il progetto dimostra un'implementazione avanzata del pattern **MVVM-C (Model-View-ViewModel-Coordinator)** combinato con i principi di **Clean Architecture** di Robert C. Martin ("Uncle Bob").

L'app mostra una lista di post e naviga al dettaglio, usando:
- **3 pacchetti SPM locali** per la modularizzazione
- **Feature Flag** per il controllo dinamico delle funzionalità
- **Dependency Injection** tramite Composition Root
- **Swift 6 Concurrency** (`async/await`, `@MainActor`, `Sendable`)
- **`@Observable`** (Swift Observation framework) invece di `ObservableObject`

---

## Struttura dei Layer

```
┌─────────────────────────────────────────────────────────────┐
│                    PRESENTATION LAYER                        │
│  (CoordDemo app target)                                      │
│                                                              │
│  Views ──► ViewModels ──► [Use Case Protocol]               │
│    │                                                         │
│  Coordinator ──► [Use Case Protocol]                        │
│    │                                                         │
│  AppDependencyContainer (Composition Root)                  │
└──────────────────────────┬──────────────────────────────────┘
                           │ dipende da
┌──────────────────────────▼──────────────────────────────────┐
│                    DOMAIN LAYER                              │
│  (Pacchetto SPM: Domain)                                     │
│                                                              │
│  Entities: Post, User                                        │
│  Use Cases: FetchPostsUseCase, FetchPostDetailUseCase        │
│  Repository Protocols: PostRepositoryProtocol                │
│                                                              │
│  ⚠ Nessuna dipendenza esterna                               │
└──────────────────────────┬──────────────────────────────────┘
                           │ implementa i protocolli di
┌──────────────────────────▼──────────────────────────────────┐
│                    DATA LAYER                                │
│  (Pacchetto SPM: Data)                                       │
│                                                              │
│  Repositories: MockPostRepository                            │
│  Errors: RepositoryError                                     │
│                                                              │
│  Dipende da: Domain (solo per i protocolli e le entità)     │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                    CORE LAYER                                │
│  (Pacchetto SPM: CoreKit)                                    │
│                                                              │
│  FeatureFlag<T>, AppFeatureFlags                             │
│  FeatureFlagService / FeatureFlagServiceProtocol             │
│  DependencyContainer                                         │
│                                                              │
│  ⚠ Nessuna dipendenza esterna                               │
└─────────────────────────────────────────────────────────────┘
```

---

## Pattern MVVM-C

### View
- Puramente presentazionale: nessuna logica di business
- Riceve il ViewModel già configurato (non lo crea)
- Comunica con il mondo esterno solo tramite il ViewModel
- Usa `@State var viewModel: MyViewModel` (con `@Observable`)

### ViewModel
- `@MainActor @Observable final class`
- Recupera dati tramite Use Case (mai direttamente dal Repository)
- Gestisce stati: `isLoading`, `errorMessage`, dati
- Legge i feature flag per adattare il comportamento
- Delega la navigazione al Coordinator (`weak var coordinator`)

### Coordinator
- `@MainActor @Observable final class AppCoordinator`
- Possiede il `NavigationPath` per `NavigationStack`
- È il factory per tutte le View (con dipendenze iniettate)
- Unico responsabile della logica di navigazione
- Controlla i feature flag prima di navigare

### Use Case
- `protocol FetchXxxUseCaseProtocol: Sendable`
- `final class FetchXxxUseCase: FetchXxxUseCaseProtocol`
- Una sola responsabilità per caso d'uso
- Dipende dal Repository Protocol, mai dall'implementazione

### Repository
- Protocollo nel Domain layer (`PostRepositoryProtocol`)
- Implementazione nel Data layer (`MockPostRepository`)
- Thread-safe e conforme a `Sendable`

---

## Moduli Swift Package Manager

| Pacchetto | Percorso | Dipendenze | Descrizione |
|-----------|----------|------------|-------------|
| `CoreKit` | `Packages/CoreKit/` | nessuna | Feature flag, DI container |
| `Domain`  | `Packages/Domain/`  | nessuna | Entità, Use Cases, protocolli repository |
| `Data`    | `Packages/Data/`    | `Domain` | Implementazioni repository, errori |

### Struttura file

```
Packages/
├── CoreKit/
│   ├── Package.swift
│   └── Sources/CoreKit/
│       ├── FeatureFlag.swift          — FeatureFlag<T> + AppFeatureFlags
│       ├── FeatureFlagService.swift   — protocollo + implementazione
│       └── DependencyContainer.swift  — IoC container generico
│
├── Domain/
│   ├── Package.swift
│   └── Sources/Domain/
│       ├── Entities/
│       │   ├── Post.swift
│       │   └── User.swift
│       ├── Repositories/
│       │   └── PostRepositoryProtocol.swift
│       └── UseCases/
│           ├── FetchPostsUseCase.swift
│           └── FetchPostDetailUseCase.swift
│
└── Data/
    ├── Package.swift
    └── Sources/Data/
        ├── Errors/
        │   └── RepositoryError.swift
        └── Repositories/
            └── MockPostRepository.swift

CoordDemo/  (app target)
├── App/
│   ├── CoordDemoApp.swift     — entry point, crea DI container
│   └── ContentView.swift      — placeholder (sostituito da RootView)
├── DI/
│   └── AppDependencyContainer.swift  — Composition Root
└── Presentation/
    ├── Coordinators/
    │   ├── AppRoute.swift       — enum destinazioni di navigazione
    │   └── AppCoordinator.swift — coordinatore principale
    ├── ViewModels/
    │   ├── PostListViewModel.swift
    │   └── PostDetailViewModel.swift
    └── Views/
        ├── RootView.swift           — NavigationStack + Coordinator
        ├── PostListView.swift       — lista post
        ├── PostDetailView.swift     — dettaglio post
        ├── PostRowView.swift        — componente riga (riusabile)
        └── FeatureFlagDemoView.swift — pannello debug flag
```

---

## Sistema di Feature Flag

### Definizione Flag

Tutti i flag sono definiti nel namespace `AppFeatureFlags` in `CoreKit`:

```swift
public enum AppFeatureFlags {
    public static let showPostAuthor = FeatureFlag<Bool>(
        key: "show_post_author",
        defaultValue: true,
        description: "Mostra il nome dell'autore nella lista post"
    )
    // ...
}
```

### Configurazione (Composition Root)

```swift
// AppDependencyContainer.swift
self.featureFlagService = FeatureFlagService(overrides: [
    AppFeatureFlags.showPostAuthor.key:     true,
    AppFeatureFlags.enableDetailView.key:   true,
    AppFeatureFlags.useNewDetailLayout.key: false
])
```

### Utilizzo nei ViewModel

```swift
// PostListViewModel.swift
self.showAuthor = featureFlagService.isEnabled(AppFeatureFlags.showPostAuthor)
```

### Utilizzo nel Coordinator

```swift
// AppCoordinator.swift
guard container.featureFlagService.isEnabled(AppFeatureFlags.enableDetailView) else {
    return  // navigazione disabilitata via flag
}
path.append(AppRoute.postDetail(post))
```

### Pannello Demo In-App

Tocca l'icona 🚩 in alto a destra nella lista per aprire `FeatureFlagDemoView`
e modificare i flag a runtime. I cambiamenti si applicano immediatamente.

#### Flag disponibili

| Flag | Default | Effetto |
|------|---------|---------|
| `show_post_author` | `true` | Mostra/nasconde l'autore nelle righe |
| `enable_detail_view` | `true` | Abilita/disabilita la navigazione al dettaglio |
| `use_new_detail_layout` | `false` | Attiva il layout sperimentale nel dettaglio |

---

## Dependency Rule

La regola fondamentale della Clean Architecture: **le dipendenze puntano sempre verso l'interno**.

```
App ──► CoreKit
App ──► Domain
App ──► Data
Data ──► Domain
CoreKit ──► (nessuna)
Domain ──► (nessuna)
```

**Non è mai consentito:**
- `Domain` → `Data` (il domain non deve conoscere i dettagli di persistenza)
- `Domain` → `CoreKit` (il domain non deve dipendere da infrastrutture)
- `Data` → `CoreKit` (il data layer non deve usare infrastrutture dell'app)
- `Data` → `Presentation` (i repository non devono conoscere le View)

Il **Dependency Inversion Principle** è il meccanismo che rende possibile tutto questo:
- `PostRepositoryProtocol` vive nel **Domain** (non nel Data)
- `MockPostRepository` vive nel **Data** e implementa il protocollo del Domain
- Il Domain non sa CHI implementa il protocollo: potrebbe essere un Mock, un'API REST, o CoreData

---

## Flusso di un'operazione tipica

**Scenario: l'utente tocca un post nella lista**

```
1. PostListView.onTapGesture
   └─► viewModel.didSelectPost(post)                     [View → ViewModel]

2. PostListViewModel.didSelectPost
   └─► coordinator?.navigateToDetail(post: post)          [ViewModel → Coordinator]

3. AppCoordinator.navigateToDetail
   ├─ controlla featureFlagService.isEnabled(.enableDetailView)
   └─► path.append(AppRoute.postDetail(post))             [Coordinator → NavigationPath]

4. SwiftUI detecta la modifica al path
   └─► navigationDestination(for: AppRoute.self) { route in
           coordinator.build(route: route)                 [SwiftUI → Coordinator factory]
       }

5. AppCoordinator.build(route: .postDetail(post))
   ├─ crea PostDetailViewModel(post:, useCase:, service:, coordinator:)
   └─► restituisce PostDetailView(viewModel:)             [Coordinator → View]

6. PostDetailView.task
   └─► viewModel.loadDetail()                             [View → ViewModel]

7. PostDetailViewModel.loadDetail
   └─► fetchPostDetailUseCase.execute(postId: post.id)    [ViewModel → UseCase]

8. FetchPostDetailUseCase.execute
   ├─► repository.fetchPost(id:)                          [UseCase → Repository]
   └─► repository.fetchUser(id:)                          [UseCase → Repository]

9. MockPostRepository restituisce i dati
   └─► postDetail aggiornato                              [Repository → UseCase → ViewModel]

10. ViewModel aggiorna la View tramite @Observable
    └─► PostDetailView mostra i dati dell'autore          [ViewModel → View]
```

---

## Setup del progetto Xcode

### Prerequisiti
- Xcode 26.3+
- iOS 26 Simulator

### Aggiungere i pacchetti locali SPM

1. Apri `CoordDemo.xcodeproj` in Xcode
2. **File → Add Package Dependencies…**
3. Nella finestra che appare, clicca **"Add Local…"** (in basso a sinistra)
4. Naviga a `Packages/CoreKit/` e clicca **"Add Package"**
5. Ripeti per `Packages/Domain/`
6. Ripeti per `Packages/Data/`

### Aggiungere i file al target

I file in `CoordDemo/DI/` e `CoordDemo/Presentation/` devono essere aggiunti al target:

1. In Xcode, trascina la cartella `DI` nel Project Navigator sotto `CoordDemo`
2. Trascina la cartella `Presentation` sotto `CoordDemo`
3. Assicurati che "Add to target: CoordDemo" sia selezionato
4. Aggiungi i link ai pacchetti in **Build Phases → Link Binary With Libraries**:
   - `CoreKit`
   - `Domain`
   - `Data`

### Ordine di compilazione consigliato

```
CoreKit ──► Domain ──► Data ──► CoordDemo (app)
```

Xcode gestisce automaticamente l'ordine una volta aggiunti i pacchetti.

---

## Estensioni future

### Aggiungere un nuovo Use Case

1. Crea `NewUseCase.swift` in `Domain/Sources/Domain/UseCases/`
2. Definisci il protocollo e l'implementazione
3. Aggiungi la proprietà in `AppDependencyContainer`
4. Iniettala nel ViewModel che ne ha bisogno

### Aggiungere una nuova schermata

1. Aggiungi un case in `AppRoute`
2. Crea il ViewModel in `Presentation/ViewModels/`
3. Crea la View in `Presentation/Views/`
4. Aggiungi il caso in `AppCoordinator.build(route:)`
5. Aggiungi il metodo di navigazione in `AppCoordinator` (opzionale)

### Passare da Mock a implementazione reale

1. Crea `NetworkPostRepository: PostRepositoryProtocol` nel modulo `Data`
2. In `AppDependencyContainer`, sostituisci:
   ```swift
   // self.postRepository = MockPostRepository()
   self.postRepository = NetworkPostRepository(baseURL: URL(string: "https://api.example.com")!)
   ```
3. Nessun altro file deve essere modificato.

### Aggiungere un nuovo Feature Flag

1. In `CoreKit/Sources/CoreKit/FeatureFlag.swift`, aggiungi a `AppFeatureFlags`:
   ```swift
   public static let myNewFlag = FeatureFlag<Bool>(
       key: "my_new_flag",
       defaultValue: false,
       description: "Descrizione del nuovo flag"
   )
   ```
2. Configura il valore in `AppDependencyContainer.init()`
3. Usa il flag nei ViewModel o nel Coordinator dove necessario
4. `FeatureFlagDemoView` mostrerà automaticamente il nuovo flag se aggiunto a `AppFeatureFlags.allBoolFlags`
