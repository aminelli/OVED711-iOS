//
// RootView.swift
// CoordDemo
//
// Vista radice dell'applicazione che avvolge NavigationStack e il Coordinator.
//
// Responsabilità di RootView:
//   - Creare e possedere l'AppCoordinator (tramite @State)
//   - Creare il ViewModel radice (PostListViewModel) passandolo alla View
//   - Configurare NavigationStack con il path del Coordinator
//   - Registrare i gestori di navigazione (navigationDestination)
//
// RootView è l'unico punto in cui NavigationStack viene creato:
// tutte le navigazioni passano attraverso l'AppCoordinator che
// modifica il path dello stack.
//

import SwiftUI
import Domain

/// Vista radice dell'applicazione.
///
/// Crea e possiede l'`AppCoordinator` e il ViewModel radice.
/// Entrambi vengono creati una sola volta e persistono per tutta
/// la durata dell'applicazione (grazie a `@State`).
///
/// Pattern: la creazione di oggetti nell'`init` di una View con `@State`
/// garantisce che vengano inizializzati una sola volta, non ad ogni
/// ri-renderizzazione del body.
struct RootView: View {

    // MARK: - State

    /// Coordinatore principale: possiede il NavigationPath
    @State private var coordinator: AppCoordinator

    /// ViewModel per la lista post: creato qui per evitare la dipendenza circolare
    /// (Coordinator → ViewModel → Coordinator weak ref)
    @State private var postListViewModel: PostListViewModel

    // MARK: - Inizializzazione

    init(container: AppDependencyContainer) {
        // Crea prima il coordinatore
        let coord = AppCoordinator(container: container)

        // Poi crea il ViewModel passando il coordinatore come dipendenza.
        // Il ViewModel tiene un riferimento weak al coordinator per evitare retain cycle.
        let vm = PostListViewModel(
            fetchPostsUseCase: container.fetchPostsUseCase,
            featureFlagService: container.featureFlagService,
            coordinator: coord
        )

        // Inizializza @State con i valori creati sopra.
        // Questi init vengono eseguiti UNA SOLA VOLTA (non ad ogni rerender).
        _coordinator = State(initialValue: coord)
        _postListViewModel = State(initialValue: vm)
    }

    // MARK: - Body

    var body: some View {
        // NavigationStack gestisce lo stack di navigazione tramite il path del Coordinator.
        // Ogni volta che il Coordinator modifica `path`, SwiftUI aggiorna la UI.
        NavigationStack(path: $coordinator.path) {

            // Vista radice dello stack: la lista dei post
            PostListView(
                viewModel: postListViewModel,
                featureFlagService: coordinator.container.featureFlagService
            )
            // Registrazione delle destinazioni di navigazione.
            // Quando il Coordinator aggiunge AppRoute.postDetail(post) al path,
            // SwiftUI usa questo closure per costruire la vista corrispondente.
            .navigationDestination(for: AppRoute.self) { route in
                // Il Coordinator è il factory per tutte le route
                coordinator.build(route: route)
            }
        }
    }
}
