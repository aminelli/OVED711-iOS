//
// FeatureFlagDemoView.swift
// CoordDemo
//
// Pannello in-app per la visualizzazione e il toggle dei feature flag a runtime.
//
// Scopo: dimostrare visivamente come i feature flag influenzano il comportamento
// dell'app senza richiedere un nuovo rilascio o una ricompilazione.
//
// In un'app di produzione questo pannello sarebbe visibile solo agli utenti
// interni (build di staging) o sarebbe accessibile con un gesto nascosto.
//

import SwiftUI
import CoreKit

/// Pannello debug per la gestione dei feature flag a runtime.
///
/// Permette di:
///   - Vedere il valore corrente di ogni feature flag
///   - Attivare/disattivare i flag booleani tramite Toggle
///   - Comprendere visivamente l'impatto di ogni flag sull'app
///
/// Le modifiche vengono applicate immediatamente al `FeatureFlagService`
/// condiviso. Al dismiss del pannello, i ViewModel vengono notificati
/// tramite `refreshFeatureFlags()` per aggiornare la UI.
struct FeatureFlagDemoView: View {

    // MARK: - Dipendenze

    /// Il servizio feature flag condiviso (stessa istanza usata dall'app)
    let service: FeatureFlagService

    // MARK: - State Locale

    /// Valori correnti dei flag, sincronizzati al servizio tramite onChange
    @State private var showAuthor: Bool = false
    @State private var enableDetail: Bool = false
    @State private var useNewLayout: Bool = false

    @Environment(\.dismiss) private var dismiss

    // MARK: - Body

    var body: some View {
        NavigationStack {
            Form {
                // ── Sezione: Feature Flags ────────────────────────────────
                Section {
                    flagToggle(
                        title: AppFeatureFlags.showPostAuthor.description,
                        systemImage: "person.circle",
                        isOn: $showAuthor
                    )
                    .onChange(of: showAuthor) { _, newValue in
                        // Ogni modifica al Toggle aggiorna immediatamente il servizio
                        service.setValue(newValue, for: AppFeatureFlags.showPostAuthor)
                    }

                    flagToggle(
                        title: AppFeatureFlags.enableDetailView.description,
                        systemImage: "arrow.right.circle",
                        isOn: $enableDetail
                    )
                    .onChange(of: enableDetail) { _, newValue in
                        service.setValue(newValue, for: AppFeatureFlags.enableDetailView)
                    }

                    flagToggle(
                        title: AppFeatureFlags.useNewDetailLayout.description,
                        systemImage: "rectangle.3.group",
                        isOn: $useNewLayout
                    )
                    .onChange(of: useNewLayout) { _, newValue in
                        service.setValue(newValue, for: AppFeatureFlags.useNewDetailLayout)
                    }
                } header: {
                    Text("Feature Flags Attivi")
                } footer: {
                    Text("Le modifiche vengono applicate all'app immediatamente dopo la chiusura di questo pannello.")
                        .font(.caption)
                }

                // ── Sezione: Informazioni ─────────────────────────────────
                Section("Come funziona") {
                    infoRow(
                        icon: "building.columns",
                        title: "Architettura",
                        detail: "I flag sono gestiti da FeatureFlagService in CoreKit, iniettato tramite AppDependencyContainer."
                    )
                    infoRow(
                        icon: "arrow.triangle.branch",
                        title: "Dependency Rule",
                        detail: "Domain e Data non conoscono i flag. Solo il layer Presentation li legge tramite il protocollo FeatureFlagServiceProtocol."
                    )
                    infoRow(
                        icon: "gearshape.2",
                        title: "Estensibilità",
                        detail: "Per aggiungere un nuovo flag: 1) Aggiungi in AppFeatureFlags, 2) Usa nel ViewModel, 3) Configura nel DI container."
                    )
                }
            }
            .navigationTitle("Feature Flags Demo")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Chiudi") { dismiss() }
                }
            }
            // Legge i valori correnti dal servizio all'apertura del pannello
            .onAppear {
                showAuthor   = service.isEnabled(AppFeatureFlags.showPostAuthor)
                enableDetail = service.isEnabled(AppFeatureFlags.enableDetailView)
                useNewLayout = service.isEnabled(AppFeatureFlags.useNewDetailLayout)
            }
        }
    }

    // MARK: - Componenti Privati

    /// Riga Toggle con icona per un singolo feature flag
    private func flagToggle(
        title: String,
        systemImage: String,
        isOn: Binding<Bool>
    ) -> some View {
        Toggle(isOn: isOn) {
            Label(title, systemImage: systemImage)
        }
        .tint(.accentColor)
    }

    /// Riga informativa per la sezione "Come funziona"
    private func infoRow(icon: String, title: String, detail: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Label(title, systemImage: icon)
                .font(.subheadline)
                .fontWeight(.medium)
            Text(detail)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 4)
    }
}
