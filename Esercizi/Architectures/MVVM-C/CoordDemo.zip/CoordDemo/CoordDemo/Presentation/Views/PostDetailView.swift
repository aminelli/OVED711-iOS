//
// PostDetailView.swift
// CoordDemo
//
// Vista di dettaglio di un post con informazioni sull'autore.
//
// Dimostra:
//   - Due layout alternativi pilotati da feature flag
//   - Stato di caricamento "partial" (titolo subito, autore dopo)
//   - Gestione degli errori con possibilità di retry
//

import SwiftUI
import Domain

/// Vista di dettaglio di un post.
///
/// Il titolo e il corpo del post sono disponibili subito (passati dalla lista),
/// mentre le informazioni sull'autore vengono caricate in modo asincrono.
/// Questo approccio "optimistic" migliora la perceived performance:
/// l'utente vede contenuto immediato senza schermata di caricamento vuota.
///
/// Il layout viene scelto in base al feature flag `useNewDetailLayout`:
///   - `false` (default): layout classico con ScrollView verticale
///   - `true`: layout sperimentale con header espanso
struct PostDetailView: View {

    // MARK: - State

    /// ViewModel iniettato dal Coordinator (via AppCoordinator.build)
    @State var viewModel: PostDetailViewModel

    // MARK: - Body

    var body: some View {
        Group {
            // Scelta del layout in base al feature flag
            if viewModel.useNewLayout {
                newLayoutContent
            } else {
                classicLayoutContent
            }
        }
        .navigationTitle(viewModel.post.title)
        .navigationBarTitleDisplayMode(.inline)
        // Carica il dettaglio all'apparizione della View
        .task {
            await viewModel.loadDetail()
        }
    }

    // MARK: - Layout Classico (feature flag OFF)

    private var classicLayoutContent: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {

                // ── Titolo del Post ──────────────────────────────────────
                Text(viewModel.post.title)
                    .font(.title2)
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity, alignment: .leading)

                Divider()

                // ── Corpo del Post ───────────────────────────────────────
                Text(viewModel.post.body)
                    .font(.body)
                    .lineSpacing(6)
                    .frame(maxWidth: .infinity, alignment: .leading)

                Divider()

                // ── Informazioni sull'Autore ─────────────────────────────
                authorSection

            }
            .padding(20)
        }
    }

    // MARK: - Nuovo Layout (feature flag ON - sperimentale)

    private var newLayoutContent: some View {
        ScrollView {
            VStack(spacing: 0) {

                // Header espanso con gradiente
                ZStack(alignment: .bottomLeading) {
                    LinearGradient(
                        colors: [.blue.opacity(0.7), .purple.opacity(0.5)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                    .frame(height: 180)

                    VStack(alignment: .leading, spacing: 4) {
                        Label("Post #\(viewModel.post.id)", systemImage: "doc.text.fill")
                            .font(.caption)
                            .foregroundStyle(.white.opacity(0.8))
                        Text(viewModel.post.title)
                            .font(.title3)
                            .fontWeight(.bold)
                            .foregroundStyle(.white)
                            .lineLimit(3)
                    }
                    .padding(20)
                }

                // Contenuto principale
                VStack(alignment: .leading, spacing: 20) {
                    Text(viewModel.post.body)
                        .font(.body)
                        .lineSpacing(6)

                    // Sezione autore inline nel nuovo layout
                    authorSection
                        .padding()
                        .background(Color(.secondarySystemGroupedBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }
                .padding(20)

                // Badge "Nuovo Layout" per indicare che è sperimentale
                HStack {
                    Spacer()
                    Label("Nuovo Layout (Feature Flag attivo)", systemImage: "flag.fill")
                        .font(.caption2)
                        .foregroundStyle(.orange)
                    Spacer()
                }
                .padding(.bottom, 20)
            }
        }
    }

    // MARK: - Sezione Autore (condivisa tra layout)

    @ViewBuilder
    private var authorSection: some View {
        if viewModel.isLoading {
            // Stato di caricamento per l'autore
            HStack(spacing: 12) {
                ProgressView()
                    .scaleEffect(0.9)
                Text("Caricamento autore…")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        } else if let errorMessage = viewModel.errorMessage {
            // Stato di errore con retry
            VStack(alignment: .leading, spacing: 8) {
                Label("Impossibile caricare il dettaglio", systemImage: "exclamationmark.circle.fill")
                    .font(.subheadline)
                    .foregroundStyle(.red)
                Text(errorMessage)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Button("Riprova") {
                    Task { await viewModel.loadDetail() }
                }
                .font(.caption)
            }
        } else if let detail = viewModel.postDetail {
            // Stato normale: mostra informazioni sull'autore
            VStack(alignment: .leading, spacing: 8) {
                Text("Autore")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .textCase(.uppercase)
                HStack(spacing: 12) {
                    // Avatar generato con le iniziali
                    Circle()
                        .fill(Color.accentColor.gradient)
                        .frame(width: 40, height: 40)
                        .overlay {
                            Text(detail.author.name.prefix(1))
                                .font(.headline)
                                .foregroundStyle(.white)
                        }
                    VStack(alignment: .leading, spacing: 2) {
                        Text(detail.author.name)
                            .font(.subheadline)
                            .fontWeight(.medium)
                        Text(detail.author.email)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                }
            }
        }
    }
}
