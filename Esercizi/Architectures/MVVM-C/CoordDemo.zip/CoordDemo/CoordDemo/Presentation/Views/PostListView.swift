//
// PostListView.swift
// CoordDemo
//
// Vista principale che mostra la lista dei post.
//
// La View nel pattern MVVM:
//   ✓ È responsabile SOLO della presentazione dei dati
//   ✓ Riceve un ViewModel pre-configurato (non lo crea)
//   ✓ Comunica con il mondo esterno SOLO tramite il ViewModel
//   ✗ NON contiene logica di business
//   ✗ NON conosce i Use Case, Repository o Coordinator direttamente
//   ✗ NON crea mai i propri ViewModel (Single Responsibility)
//

import SwiftUI
import CoreKit

/// Vista lista dei post.
///
/// Il ViewModel è passato dall'esterno (da RootView/Coordinator) e
/// memorizzato con `@State`. Con `@Observable`, SwiftUI traccia
/// automaticamente le proprietà del ViewModel lette nel `body`,
/// aggiornando solo le parti della View che cambiano davvero.
///
/// La `featureFlagService` è passata separatamente per il pannello
/// debug (FeatureFlagDemoView), che ha bisogno di modificarla direttamente.
struct PostListView: View {

    // MARK: - State

    /// ViewModel iniettato dal Coordinator via RootView.
    /// `@State` garantisce che l'oggetto persista per tutta la vita della View.
    @State var viewModel: PostListViewModel

    /// Servizio feature flag: usato solo per il pannello debug in-app
    let featureFlagService: FeatureFlagService

    /// Controlla la visibilità del pannello debug Feature Flags
    @State private var showingFeatureFlags = false

    // MARK: - Body

    var body: some View {
        Group {
            if viewModel.isLoading && viewModel.posts.isEmpty {
                // Stato di caricamento iniziale (nessun dato ancora disponibile)
                loadingView
            } else if let errorMessage = viewModel.errorMessage, viewModel.posts.isEmpty {
                // Stato di errore (solo quando non ci sono dati da mostrare)
                errorView(message: errorMessage)
            } else {
                // Stato normale: lista dei post
                postListContent
            }
        }
        .navigationTitle("Post")
        .navigationBarTitleDisplayMode(.large)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                // Pulsante per aprire il pannello demo dei feature flag
                Button {
                    showingFeatureFlags = true
                } label: {
                    Image(systemName: "flag.2.crossed.fill")
                        .symbolRenderingMode(.hierarchical)
                }
                .accessibilityLabel("Feature Flags")
            }
        }
        // Sheet per il pannello demo dei feature flag
        .sheet(isPresented: $showingFeatureFlags) {
            FeatureFlagDemoView(service: featureFlagService)
                .onDisappear {
                    // Dopo aver modificato i flag, aggiorna il ViewModel
                    // in modo che la View rifletta i nuovi valori
                    viewModel.refreshFeatureFlags()
                }
        }
        // Carica i post alla prima apparizione della View
        .task {
            await viewModel.loadPosts()
        }
        // Supporto pull-to-refresh nativo di SwiftUI
        .refreshable {
            await viewModel.loadPosts()
        }
    }

    // MARK: - Sotto-componenti

    /// Vista mostrata durante il caricamento iniziale
    private var loadingView: some View {
        VStack(spacing: 16) {
            ProgressView()
                .scaleEffect(1.5)
            Text("Caricamento post in corso…")
                .foregroundStyle(.secondary)
                .font(.subheadline)
        }
    }

    /// Vista di errore con pulsante di retry
    private func errorView(message: String) -> some View {
        VStack(spacing: 20) {
            Image(systemName: "exclamationmark.triangle.fill")
                .font(.system(size: 48))
                .foregroundStyle(.orange)
            Text("Impossibile caricare i post")
                .font(.headline)
            Text(message)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 32)
            Button("Riprova") {
                Task { await viewModel.loadPosts() }
            }
            .buttonStyle(.borderedProminent)
        }
    }

    /// Lista dei post con supporto al tap
    private var postListContent: some View {
        List(viewModel.posts) { post in
            // Componente riga riutilizzabile e indipendente
            PostRowView(post: post, showAuthor: viewModel.showAuthor)
                // Rende tutta la riga tappabile, non solo il testo
                .contentShape(Rectangle())
                .onTapGesture {
                    // La View delega completamente la selezione al ViewModel
                    viewModel.didSelectPost(post)
                }
                // Feedback visivo che indica se il dettaglio è abilitato
                .opacity(viewModel.isDetailEnabled ? 1.0 : 0.55)
                // Freccia di navigazione solo se il dettaglio è abilitato
                .overlay(alignment: .trailing) {
                    if viewModel.isDetailEnabled {
                        Image(systemName: "chevron.right")
                            .font(.caption)
                            .foregroundStyle(.tertiary)
                    }
                }
        }
        .listStyle(.insetGrouped)
        // Banner che informa l'utente quando il dettaglio è disabilitato via flag
        .safeAreaInset(edge: .bottom) {
            if !viewModel.isDetailEnabled {
                featureFlagBanner(message: "Dettaglio post disabilitato via Feature Flag")
            }
        }
    }

    /// Banner informativo mostrato quando una feature è disabilitata
    private func featureFlagBanner(message: String) -> some View {
        HStack(spacing: 8) {
            Image(systemName: "flag.fill")
                .foregroundStyle(.orange)
            Text(message)
                .font(.caption)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .frame(maxWidth: .infinity)
        .background(.ultraThinMaterial)
    }
}
