//
// PostRowView.swift
// CoordDemo
//
// Componente View riutilizzabile per una singola riga della lista post.
//
// Separare questo componente in una View autonoma:
//   - Migliora la riusabilità (usabile anche in altre liste o widget)
//   - Facilita il testing tramite Preview isolate
//   - Mantiene PostListView snella e leggibile
//   - Incapsula le regole di layout della riga in un solo posto
//

import SwiftUI
import Domain

/// Vista per una singola riga nella lista dei post.
///
/// Riceve solo i dati strettamente necessari per renderizzarsi.
/// Non conosce il ViewModel né il Coordinator: è un componente
/// puramente presentazionale ("dumb component").
struct PostRowView: View {

    /// Il post da visualizzare
    let post: Post

    /// Controlla la visibilità del nome dell'autore.
    /// Pilotato dal feature flag `AppFeatureFlags.showPostAuthor` tramite il ViewModel.
    let showAuthor: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {

            // Titolo del post in evidenza
            Text(post.title)
                .font(.headline)
                .foregroundStyle(.primary)
                .lineLimit(2)

            // Anteprima del corpo del post (max 3 righe)
            Text(post.body)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .lineLimit(3)

            // ── Feature Flag: mostra l'autore solo se il flag è abilitato ──
            // Questo blocco è completamente condizionale: rimuovendo
            // il flag dal servizio, questo pezzo di UI sparisce.
            if showAuthor {
                Label("Utente #\(post.userId)", systemImage: "person.circle.fill")
                    .font(.caption)
                    .foregroundStyle(.tint)
                    .padding(.top, 2)
            }
        }
        .padding(.vertical, 4)
    }
}

// MARK: - Preview

#Preview("Con autore") {
    List {
        PostRowView(
            post: Post(
                id: 1,
                title: "Clean Architecture in iOS",
                body: "Esempio di post con tutti i dati compilati per la preview del componente.",
                userId: 1
            ),
            showAuthor: true
        )
    }
}

#Preview("Senza autore") {
    List {
        PostRowView(
            post: Post(
                id: 2,
                title: "Feature Flag disabilitato",
                body: "Con il flag showPostAuthor disabilitato, la riga non mostra l'autore.",
                userId: 2
            ),
            showAuthor: false
        )
    }
}
