//
// AppCoordinator.swift
// CoordDemo
//
// Coordinatore principale che gestisce il flusso di navigazione.
//
// PATTERN: Coordinator (MVVM-C)
// Il Coordinator risolve il problema della navigazione accoppiata alle View.
// Senza Coordinator, le View devono conoscersi a vicenda per poter navigare.
// Con il Coordinator, ogni View è completamente ignara di ciò che viene dopo.
//
// Responsabilità del Coordinator:
//   ✓ Gestire lo stack di navigazione (NavigationPath)
//   ✓ Decidere QUANDO e COME navigare tra le schermate
//   ✓ Costruire le View con le dipendenze corrette (factory method)
//   ✓ Rispettare i feature flag per abilitare/disabilitare la navigazione
//   ✗ NON gestisce la UI (nessun body, nessun layout)
//   ✗ NON esegue logica di business (quella è nei UseCase)
//   ✗ NON recupera dati (quello è nel Repository)
//

import SwiftUI
import Domain
import CoreKit

/// Coordinatore principale dell'applicazione.
///
/// Con `@Observable` (Swift Observation framework, iOS 17+):
///   - Le View si aggiornano automaticamente quando `path` cambia
///   - Meno boilerplate rispetto a `ObservableObject` + `@Published`
///   - Swift traccia solo le proprietà effettivamente lette (performance migliore)
///
/// `@MainActor`: tutte le modifiche al path devono avvenire sul main thread
/// perché causano aggiornamenti dell'interfaccia utente.
@MainActor
@Observable
final class AppCoordinator {

    // MARK: - Stato di Navigazione

    /// Percorso di navigazione dello stack.
    /// Quando viene modificato, `NavigationStack` aggiorna automaticamente
    /// la UI per riflettere il nuovo stato.
    var path = NavigationPath()

    // MARK: - Dipendenze

    /// Contenitore delle dipendenze, usato per costruire i ViewModel delle route
    let container: AppDependencyContainer

    // MARK: - Inizializzazione

    init(container: AppDependencyContainer) {
        self.container = container
    }

    // MARK: - Navigazione

    /// Naviga alla vista di dettaglio di un post.
    ///
    /// Il Coordinator controlla il feature flag prima di navigare:
    /// se `enableDetailView` è disabilitato, la navigazione non avviene.
    /// Questo centralizza la logica di "gating" in un solo punto.
    ///
    /// - Parameter post: Il post di cui mostrare il dettaglio
    func navigateToDetail(post: Post) {
        // Controllo feature flag: il Coordinator decide se procedere
        guard container.featureFlagService.isEnabled(AppFeatureFlags.enableDetailView) else {
            // In un'app reale si potrebbe mostrare un alert o un banner
            return
        }
        path.append(AppRoute.postDetail(post))
    }

    /// Torna alla schermata precedente nello stack di navigazione
    func pop() {
        guard !path.isEmpty else { return }
        path.removeLast()
    }

    /// Torna alla schermata radice, svuotando l'intero stack
    func popToRoot() {
        path.removeLast(path.count)
    }

    // MARK: - Factory Method

    /// Costruisce la View appropriata per la route richiesta.
    ///
    /// Questo è il "factory method" del Coordinator: centralizza la creazione
    /// di View con le loro dipendenze iniettate. Le View non si creano mai
    /// da sole: è il Coordinator che le istanzia con il contesto corretto.
    ///
    /// - Parameter route: La destinazione di navigazione
    /// - Returns: La View corrispondente alla route, con ViewModel pre-configurato
    @ViewBuilder
    func build(route: AppRoute) -> some View {
        switch route {
        case .postDetail(let post):
            // Il Coordinator crea il ViewModel con TUTTE le dipendenze iniettate.
            // La View riceve un ViewModel già pronto, non sa da dove viene.
            let viewModel = PostDetailViewModel(
                post: post,
                fetchPostDetailUseCase: container.fetchPostDetailUseCase,
                featureFlagService: container.featureFlagService,
                coordinator: self
            )
            PostDetailView(viewModel: viewModel)
        }
    }
}
