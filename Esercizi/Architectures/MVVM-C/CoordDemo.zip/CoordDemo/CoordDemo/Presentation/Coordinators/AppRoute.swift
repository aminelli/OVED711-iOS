//
// AppRoute.swift
// CoordDemo
//
// Definisce le possibili destinazioni di navigazione nell'applicazione.
//
// PATTERN: Typed Navigation Routes
// Usando un enum tipizzato con NavigationStack otteniamo:
//   - Navigazione type-safe (impossibile navigare verso route inesistenti)
//   - Centralizzazione di tutta la logica di navigazione nel Coordinator
//   - Deep linking e state restoration facilitati
//   - Facilità di testing del flusso di navigazione
//

import Foundation
import Domain

/// Enumerazione di tutte le destinazioni di navigazione dell'applicazione.
///
/// Ogni `case` rappresenta una schermata raggiungibile tramite navigazione.
/// I dati necessari per costruire la schermata vengono passati come
/// associated values del case.
///
/// Conformando a `Hashable`, i valori possono essere usati direttamente
/// come elementi della `NavigationPath` di SwiftUI (introdotta in iOS 16).
///
/// Estendere l'app con una nuova schermata richiede:
///   1. Aggiungere un case qui
///   2. Aggiungere il caso in `AppCoordinator.build(route:)`
///   3. Creare la View corrispondente
enum AppRoute: Hashable {

    /// Vista di dettaglio di un post specifico.
    /// Il `Post` viene passato dalla lista per evitare un fetch ridondante.
    case postDetail(Post)
}
