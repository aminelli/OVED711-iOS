//
// PostListViewModel.swift
// CoordDemo
//
// ViewModel per la vista lista dei post.
//
// PATTERN: ViewModel in MVVM-C
// Il ViewModel è il mediatore tra la View e il Domain layer.
//
// Responsabilità del ViewModel:
//   ✓ Recuperare dati tramite Use Case (mai direttamente dal Repository)
//   ✓ Gestire stati di caricamento, errore e successo
//   ✓ Esporre dati pronti per la View (non entità di dominio grezze, se serve)
//   ✓ Rispondere alle azioni utente delegando al Coordinator per la navigazione
//   ✓ Leggere i feature flag per adattare il comportamento
//   ✗ NON conosce UIKit o SwiftUI (tranne per casi specifici come @Observable)
//   ✗ NON conosce la View (dipendenza unidirezionale: View → ViewModel)
//   ✗ NON naviga direttamente (delega al Coordinator)
//

import Foundation
import Domain
import CoreKit

/// ViewModel per la lista dei post.
///
/// Usa il macro `@Observable` di Swift 5.9+:
///   - Traccia automaticamente le proprietà lette dalla View
///   - Aggiornamenti UI più granulari (solo le proprietà cambiate)
///   - Nessun `@Published` necessario
///   - Compatibile con SwiftUI sia con `@State` che con `@Environment`
///
/// `@MainActor` garantisce che tutti gli aggiornamenti delle proprietà
/// osservate avvengano sul main thread, dove opera SwiftUI.
@MainActor
@Observable
final class PostListViewModel {

    // MARK: - Stato Observable (letto dalla View)

    /// Lista di post da visualizzare nella List
    var posts: [Post] = []

    /// `true` durante il caricamento asincrono dei dati
    var isLoading = false

    /// Messaggio di errore da mostrare quando `isLoading` è `false` e `posts` è vuoto
    var errorMessage: String?

    /// Controlla la visibilità del nome dell'autore nelle righe.
    /// Pilotato dal feature flag `AppFeatureFlags.showPostAuthor`.
    var showAuthor: Bool

    /// Controlla se il tap sulle righe è abilitato (feature flag `enableDetailView`)
    var isDetailEnabled: Bool

    // MARK: - Dipendenze (private, non osservabili dalla View)

    /// Use Case per il recupero dei post. Iniettato, non creato qui.
    /// La View non sa né che esiste né come funziona.
    private let fetchPostsUseCase: FetchPostsUseCaseProtocol

    /// Servizio feature flag. Consultato all'init e su richiesta esplicita.
    private let featureFlagService: FeatureFlagServiceProtocol

    /// Riferimento debole al Coordinator per evitare retain cycle circolare.
    /// ViewModel → Coordinator (weak) evita che si tengano a vicenda in vita.
    private weak var coordinator: AppCoordinator?

    // MARK: - Inizializzazione

    init(
        fetchPostsUseCase: FetchPostsUseCaseProtocol,
        featureFlagService: FeatureFlagServiceProtocol,
        coordinator: AppCoordinator
    ) {
        self.fetchPostsUseCase = fetchPostsUseCase
        self.featureFlagService = featureFlagService
        self.coordinator = coordinator

        // Legge i flag al momento dell'inizializzazione.
        // Se i flag possono cambiare a runtime, usa `refreshFeatureFlags()`.
        self.showAuthor = featureFlagService.isEnabled(AppFeatureFlags.showPostAuthor)
        self.isDetailEnabled = featureFlagService.isEnabled(AppFeatureFlags.enableDetailView)
    }

    // MARK: - Azioni

    /// Carica la lista dei post invocando il caso d'uso.
    /// Gestisce automaticamente gli stati di caricamento ed errore.
    func loadPosts() async {
        isLoading = true
        errorMessage = nil

        do {
            posts = try await fetchPostsUseCase.execute()
        } catch {
            // Trasforma l'errore tecnico in un messaggio leggibile per l'utente
            errorMessage = error.localizedDescription
        }

        isLoading = false
    }

    /// Gestisce la selezione di un post da parte dell'utente.
    /// DELEGA la navigazione al Coordinator: il ViewModel non naviga mai da solo.
    /// - Parameter post: Il post toccato dall'utente
    func didSelectPost(_ post: Post) {
        // Il ViewModel si limita a comunicare l'intenzione al Coordinator
        coordinator?.navigateToDetail(post: post)
    }

    /// Rilegge i valori dei feature flag dal servizio.
    /// Da chiamare dopo modifiche runtime ai flag (es. chiusura del pannello debug).
    func refreshFeatureFlags() {
        showAuthor = featureFlagService.isEnabled(AppFeatureFlags.showPostAuthor)
        isDetailEnabled = featureFlagService.isEnabled(AppFeatureFlags.enableDetailView)
    }
}
