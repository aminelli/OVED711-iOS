//
// PostDetailViewModel.swift
// CoordDemo
//
// ViewModel per la vista di dettaglio del post.
//
// A differenza del PostListViewModel, il PostDetailViewModel riceve
// il post di partenza direttamente (già disponibile dalla lista) e
// recupera i dati arricchiti (come l'autore) tramite Use Case.
// Questo evita un fetch ridondante del post che abbiamo già.
//

import Foundation
import Domain
import CoreKit

/// ViewModel per il dettaglio di un post.
///
/// Il dettaglio include informazioni aggiuntive sull'autore che vengono
/// recuperate in modo asincrono tramite `FetchPostDetailUseCase`.
///
/// Il feature flag `useNewDetailLayout` determina quale layout
/// viene mostrato dalla View (layout classico vs. nuovo sperimentale).
@MainActor
@Observable
final class PostDetailViewModel {

    // MARK: - Stato Observable

    /// Il post di cui mostrare il dettaglio.
    /// Disponibile immediatamente (passato dalla lista), senza attendere il fetch.
    let post: Post

    /// Dettaglio arricchito con l'autore. `nil` fino al completamento del caricamento.
    var postDetail: PostDetail?

    /// `true` durante il caricamento del dettaglio
    var isLoading = false

    /// Messaggio di errore, valorizzato solo in caso di fallimento del fetch
    var errorMessage: String?

    /// Feature flag: determina quale layout usare per il dettaglio
    var useNewLayout: Bool

    // MARK: - Dipendenze

    private let fetchPostDetailUseCase: FetchPostDetailUseCaseProtocol
    private let featureFlagService: FeatureFlagServiceProtocol

    /// Riferimento debole al Coordinator per la navigazione "back"
    private weak var coordinator: AppCoordinator?

    // MARK: - Inizializzazione

    init(
        post: Post,
        fetchPostDetailUseCase: FetchPostDetailUseCaseProtocol,
        featureFlagService: FeatureFlagServiceProtocol,
        coordinator: AppCoordinator
    ) {
        self.post = post
        self.fetchPostDetailUseCase = fetchPostDetailUseCase
        self.featureFlagService = featureFlagService
        self.coordinator = coordinator
        self.useNewLayout = featureFlagService.isEnabled(AppFeatureFlags.useNewDetailLayout)
    }

    // MARK: - Azioni

    /// Carica il dettaglio completo del post (post + autore).
    /// Il titolo e il corpo del post sono già disponibili da `post`,
    /// ma l'autore richiede una chiamata aggiuntiva al repository.
    func loadDetail() async {
        isLoading = true
        errorMessage = nil

        do {
            postDetail = try await fetchPostDetailUseCase.execute(postId: post.id)
        } catch {
            errorMessage = error.localizedDescription
        }

        isLoading = false
    }

    /// Richiede al Coordinator di tornare alla schermata precedente.
    /// La View chiama questo metodo; non gestisce mai la navigazione da sola.
    func goBack() {
        coordinator?.pop()
    }
}
