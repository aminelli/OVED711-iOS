//
//  ContentView.swift
//  CoordDemo
//
//  Created by Antonio Minelli.
//
//  Questo file è stato sostituito da RootView.swift nella nuova architettura
//  MVVM-C con Clean Architecture.
//
//  La vista radice è ora RootView, che gestisce NavigationStack e AppCoordinator.
//  Vedi: CoordDemo/Presentation/Views/RootView.swift
//
