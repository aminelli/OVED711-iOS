//
//  CoordDemoApp.swift
//  CoordDemo
//
//  Created by Antonio Minelli.
//
//  Entry point dell'applicazione.
//
//  Qui avviene la creazione del Composition Root (AppDependencyContainer)
//  che viene passato alla RootView. Il container persiste per tutta la
//  durata dell'applicazione tramite @State.
//
//  Struttura del progetto:
//    CoordDemoApp  ← entry point, crea il DI container
//       └─ RootView ← NavigationStack + AppCoordinator
//            └─ PostListView ← lista post
//                 └─ PostDetailView ← dettaglio post
//

import SwiftUI

@main
struct CoordDemoApp: App {

    /// Composition Root: creato una sola volta e iniettato nell'intera app.
    /// @State garantisce che persista per tutta la durata dell'applicazione.
    @State private var container = AppDependencyContainer()

    var body: some Scene {
        WindowGroup {
            // RootView riceve il container e costruisce il grafo delle View
            RootView(container: container)
        }
    }
}
