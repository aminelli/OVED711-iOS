//
// AppDependencyContainer.swift
// CoordDemo
//
// Composition Root dell'applicazione.
//
// PATTERN: Composition Root (Mark Seemann)
// Il Composition Root è l'unico posto nell'applicazione dove si sa
// COME costruire il grafo completo delle dipendenze. Tutto il resto
// del codice dipende solo da astrazioni (protocolli).
//
// REGOLA DELLA DIPENDENZA rispettata:
//   Domain   → (nessuna dipendenza)
//   Data     → Domain
//   CoreKit  → (nessuna dipendenza)
//   App      → CoreKit + Domain + Data  ← solo qui!
//
// Vantaggi:
//   - Un solo punto di modifica per cambiare implementazione (es. Mock → Real)
//   - Facilita il testing: si crea un contenitore con mock
//   - Rende esplicite le dipendenze dell'intera applicazione
//

import Foundation
import CoreKit
import Domain
import Data

/// Composition Root dell'applicazione.
///
/// Assembla tutti i layer dell'architettura rispettando la dependency rule.
/// Questo è il SOLO componente che conosce tutte le implementazioni concrete.
///
/// Isolato su `@MainActor` perché viene creato e usato esclusivamente
/// nel contesto dell'interfaccia utente (SwiftUI App lifecycle).
@MainActor
final class AppDependencyContainer {

    // MARK: - Layer Core

    /// Servizio per la gestione dei feature flag.
    /// Tipo concreto (non il protocollo) per permettere il toggle nel pannello debug.
    /// Gli altri componenti ricevono il tipo `FeatureFlagServiceProtocol`.
    let featureFlagService: FeatureFlagService

    // MARK: - Layer Data (Repository)

    /// Repository per i post. Tipo privato: nessuno al di fuori di questo
    /// contenitore deve sapere che stiamo usando un Mock.
    private let postRepository: PostRepositoryProtocol

    // MARK: - Layer Domain (Use Cases)

    /// Caso d'uso per il recupero della lista di post
    let fetchPostsUseCase: FetchPostsUseCaseProtocol

    /// Caso d'uso per il recupero del dettaglio di un post
    let fetchPostDetailUseCase: FetchPostDetailUseCaseProtocol

    // MARK: - Inizializzazione

    init() {
        // ── 1. Configurazione Feature Flags ─────────────────────────────────
        // In produzione i valori iniziali verrebbero caricati da:
        //   - Firebase Remote Config
        //   - LaunchDarkly
        //   - Un file JSON in bundle (per A/B testing)
        self.featureFlagService = FeatureFlagService(overrides: [
            AppFeatureFlags.showPostAuthor.key:    true,
            AppFeatureFlags.enableDetailView.key:  true,
            AppFeatureFlags.useNewDetailLayout.key: false
        ])

        // ── 2. Costruzione Repository (Data Layer) ──────────────────────────
        // Per passare all'implementazione reale basta sostituire questa riga:
        //   self.postRepository = NetworkPostRepository(baseURL: ...)
        self.postRepository = MockPostRepository()

        // ── 3. Composizione Use Cases (Domain Layer) ────────────────────────
        // I use case ricevono il protocollo, non sanno se è Mock o Real.
        self.fetchPostsUseCase   = FetchPostsUseCase(repository: postRepository)
        self.fetchPostDetailUseCase = FetchPostDetailUseCase(repository: postRepository)
    }
}
