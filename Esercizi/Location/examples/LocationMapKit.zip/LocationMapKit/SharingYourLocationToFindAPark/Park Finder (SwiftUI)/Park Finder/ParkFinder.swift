/*
See the LICENSE.txt file for this sample’s licensing information.

Abstract:
The main entry point for the app.
*/

import SwiftUI

@main
struct ParkFinder: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
