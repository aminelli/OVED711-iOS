/*
See the LICENSE.txt file for this sample’s licensing information.

Abstract:
The scene delegate for the app.
*/

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

