//
//  AppDelegate.swift
//  MediaAndSensorDemo
//
//  Gestisce il ciclo di vita dell'applicazione UIKit e la registrazione
//  al servizio di notifiche push Apple (APNs).
//

import UIKit
import UserNotifications

/// AppDelegate: delegato principale dell'applicazione UIKit.
/// Viene integrato con SwiftUI tramite @UIApplicationDelegateAdaptor in MediaAndSensorDemoApp.
final class AppDelegate: NSObject, UIApplicationDelegate {

    // MARK: - Avvio applicazione

    /// Chiamato al termine del lancio dell'applicazione.
    /// Configura il delegate del centro notifiche per gestire le notifiche in foreground.
    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil
    ) -> Bool {
        // Imposta NotificationManager come delegate per ricevere callback sulle notifiche
        //UNUserNotificationCenter.current().delegate = NotificationManager.shared
        
        let center = UNUserNotificationCenter.current()
            center.delegate = NotificationManager.shared

            center.requestAuthorization(options: [.alert, .badge, .sound]) { granted, error in
                if granted {
                    DispatchQueue.main.async {
                        UIApplication.shared.registerForRemoteNotifications()
                    }
                }
            }

        return true
    }

    // MARK: - Registrazione APNs

    /// Chiamato da iOS quando la registrazione APNs ha successo.
    /// Il token del dispositivo è necessario per inviare notifiche push remote.
    func application(
        _ application: UIApplication,
        didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data
    ) {
        // Converte il Data in stringa esadecimale leggibile
        let tokenString = deviceToken.map { String(format: "%02.2hhx", $0) }.joined()
        print("[APNs] Token dispositivo registrato: \(tokenString)")

        // Aggiorna il NotificationManager con il token (sempre su MainActor)
        Task { @MainActor in
            NotificationManager.shared.apnsDeviceToken = tokenString
        }
    }

    /// Chiamato da iOS quando la registrazione APNs fallisce.
    /// Può avvenire su simulatore o in assenza di connessione.
    func application(
        _ application: UIApplication,
        didFailToRegisterForRemoteNotificationsWithError error: Error
    ) {
        print("[APNs] Registrazione fallita: \(error.localizedDescription)")
    }

    // MARK: - Ricezione notifiche remote in background

    /// Chiamato quando arriva una notifica push con content-available: 1.
    /// Permette all'app di aggiornare dati in background prima di mostrare la notifica.
    func application(
        _ application: UIApplication,
        didReceiveRemoteNotification userInfo: [AnyHashable: Any],
        fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void
    ) {
        print("[APNs] Notifica remota ricevuta: \(userInfo)")
        // Elabora il payload e notifica il sistema che ci sono nuovi dati
        completionHandler(.newData)
    }
}
