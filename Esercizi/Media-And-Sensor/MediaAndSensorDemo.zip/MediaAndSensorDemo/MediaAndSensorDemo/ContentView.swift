//
//  ContentView.swift
//  MediaAndSensorDemo
//
//  Vista radice dell'applicazione. Usa TabView per navigare tra le cinque
//  sezioni principali: Camera, Posizione, Sensori, HealthKit e Notifiche.
//

import SwiftUI

/// Vista principale che organizza le funzionalità dell'app in una TabView.
/// Ogni tab corrisponde a una categoria di sensori o servizi di sistema.
struct ContentView: View {

    var body: some View {
        TabView {

            // Tab 1: Fotocamera, video e scanner codici (AVFoundation)
            CameraFeatureView()
                .tabItem {
                    Label("Camera", systemImage: "camera.fill")
                }

            // Tab 2: GPS, posizione e geofencing (CoreLocation)
            LocationFeatureView()
                .tabItem {
                    Label("Location", systemImage: "location.fill")
                }

            // Tab 3: Accelerometro, giroscopio, magnetometro (CoreMotion)
            MotionView()
                .tabItem {
                    Label("Motion", systemImage: "gyroscope")
                }

            // Tab 4: Dati sanitari e allenamenti (HealthKit)
            HealthKitView()
                .tabItem {
                    Label("Health", systemImage: "heart.fill")
                }

            // Tab 5: Notifiche locali e remote (APNs)
            NotificationsView()
                .tabItem {
                    Label("Notifications", systemImage: "bell.fill")
                }
        }
    }
}

#Preview {
    ContentView()
}
