//
//  MediaAndSensorDemoApp.swift
//  MediaAndSensorDemo
//
//  Punto di ingresso principale dell'applicazione.
//  Integra UIApplicationDelegate (AppDelegate) con il ciclo di vita SwiftUI
//  per gestire eventi UIKit come la registrazione APNs.
//

import SwiftUI

/// Struttura principale dell'app SwiftUI.
/// @UIApplicationDelegateAdaptor collega AppDelegate per la gestione di APNs
/// e altri eventi del ciclo di vita UIKit non ancora supportati nativamente da SwiftUI.
@main
struct MediaAndSensorDemoApp: App {

    // Collega l'AppDelegate UIKit all'app SwiftUI
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
