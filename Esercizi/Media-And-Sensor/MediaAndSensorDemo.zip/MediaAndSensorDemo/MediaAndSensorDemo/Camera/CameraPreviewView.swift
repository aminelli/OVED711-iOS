//
//  CameraPreviewView.swift
//  MediaAndSensorDemo
//
//  Componente UIViewRepresentable che integra AVCaptureVideoPreviewLayer
//  all'interno della gerarchia di viste SwiftUI.
//  Mostra il feed live della fotocamera in tempo reale.
//

import SwiftUI
import AVFoundation

/// Vista SwiftUI per l'anteprima live della fotocamera.
/// Utilizza UIViewRepresentable per integrare il layer AVFoundation in SwiftUI.
/// Il feed viene adattato al frame della view mantenendo le proporzioni (resizeAspectFill).
struct CameraPreviewView: UIViewRepresentable {

    /// Sessione di cattura da visualizzare nell'anteprima.
    let session: AVCaptureSession

    // MARK: - UIViewRepresentable

    /// Crea la UIView personalizzata con il preview layer configurato.
    func makeUIView(context: Context) -> PreviewUIView {
        let view = PreviewUIView()
        view.session = session
        return view
    }

    /// Aggiornamenti da SwiftUI verso UIKit (non necessari per il preview layer).
    func updateUIView(_ uiView: PreviewUIView, context: Context) {}

    // MARK: - PreviewUIView

    /// UIView personalizzata che usa AVCaptureVideoPreviewLayer come layer radice.
    /// Overridando layerClass, il preview layer viene usato come CA layer principale,
    /// eliminando la necessità di aggiungerlo come sublayer.
    final class PreviewUIView: UIView {

        /// Il layer principale è AVCaptureVideoPreviewLayer anziché CALayer.
        override class var layerClass: AnyClass {
            AVCaptureVideoPreviewLayer.self
        }

        /// Accesso tipizzato e sicuro al layer AVCaptureVideoPreviewLayer.
        var previewLayer: AVCaptureVideoPreviewLayer {
            // Il cast è sicuro perché layerClass garantisce il tipo
            layer as! AVCaptureVideoPreviewLayer // swiftlint:disable:this force_cast
        }

        /// Collega la sessione AVFoundation al preview layer.
        var session: AVCaptureSession? {
            get { previewLayer.session }
            set { previewLayer.session = newValue }
        }

        override func layoutSubviews() {
            super.layoutSubviews()
            // Riempie l'intera view ritagliando il video se necessario (nessuna banda nera)
            previewLayer.videoGravity = .resizeAspectFill
            previewLayer.frame = bounds
        }
    }
}
