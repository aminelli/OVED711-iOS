//
//  CameraFeatureView.swift
//  MediaAndSensorDemo
//
//  Vista contenitore per tutte le funzionalità AVFoundation.
//  Organizza Foto, Video e Scanner in tre tab distinte.
//

import SwiftUI

/// Vista contenitore per la sezione Camera.
/// Presenta Foto, Video e Scanner come tab all'interno di un NavigationStack.
struct CameraFeatureView: View {

    /// Indice del tab selezionato (0=Foto, 1=Video, 2=Scanner).
    @State private var selectedTab = 0

    var body: some View {
        NavigationStack {
            TabView(selection: $selectedTab) {

                // Tab 0: Scatto fotografico
                PhotoCaptureView()
                    .tabItem {
                        Label("Photo", systemImage: "camera")
                    }
                    .tag(0)

                // Tab 1: Registrazione e riproduzione video
                VideoRecordingView()
                    .tabItem {
                        Label("Video", systemImage: "video")
                    }
                    .tag(1)

                // Tab 2: Scansione QR code e codici a barre
                BarcodeScannerView()
                    .tabItem {
                        Label("Scanner", systemImage: "qrcode.viewfinder")
                    }
                    .tag(2)
            }
            .navigationTitle("Camera & AVFoundation")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}
