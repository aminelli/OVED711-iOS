//
//  VideoRecordingView.swift
//  MediaAndSensorDemo
//
//  Interfaccia per la registrazione video con AVCaptureMovieFileOutput.
//  Mostra il feed live, gestisce avvio/arresto della registrazione,
//  un timer di durata e la riproduzione del video salvato tramite AVKit.
//

import SwiftUI
import AVKit

/// Vista per la registrazione video tramite AVFoundation.
/// Supporta registrazione, visualizzazione della durata e riproduzione con AVPlayer.
struct VideoRecordingView: View {

    @State private var cameraManager = CameraManager()
    /// Timer per visualizzare la durata della registrazione corrente.
    @State private var recordingDuration: TimeInterval = 0
    @State private var recordingTimer: Timer?
    /// Controlla la presentazione del player video.
    @State private var showingVideoPlayer = false

    var body: some View {
        ZStack(alignment: .bottom) {

            // Feed live fotocamera
            if cameraManager.cameraAuthorized {
                CameraPreviewView(session: cameraManager.captureSession)
                    .ignoresSafeArea()
            } else {
                PermissionDeniedView(
                    icon: "video.fill",
                    message: "Consenti fotocamera e microfono nelle Impostazioni per registrare video."
                )
            }

            // Indicatore di registrazione attiva (in alto)
            if cameraManager.isRecording {
                VStack {
                    RecordingIndicatorView(duration: recordingDuration)
                        .padding(.top, 12)
                    Spacer()
                }
            }

            // Pannello controlli in basso
            VStack(spacing: 16) {

                // Pulsante "Riproduci" visibile dopo aver salvato un video
                if cameraManager.recordedVideoURL != nil {
                    Button {
                        showingVideoPlayer = true
                    } label: {
                        Label("Riproduci Video", systemImage: "play.circle.fill")
                            .font(.headline)
                            .foregroundStyle(.white)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 10)
                            .background(.blue.opacity(0.8))
                            .clipShape(Capsule())
                    }
                }

                // Barra con pulsanti di controllo
                HStack(spacing: 48) {

                    // Inversione fotocamera (disabilitata durante la registrazione)
                    Button { cameraManager.toggleCamera() } label: {
                        Image(systemName: "arrow.triangle.2.circlepath.camera")
                            .font(.title2)
                            .foregroundStyle(cameraManager.isRecording ? .gray : .white)
                    }
                    .disabled(cameraManager.isRecording)

                    // Pulsante record / stop
                    Button { toggleRecording() } label: {
                        ZStack {
                            Circle()
                                .strokeBorder(.white, lineWidth: 4)
                                .frame(width: 74, height: 74)
                            // Quadrato rosso = in registrazione, cerchio rosso = pronto
                            if cameraManager.isRecording {
                                RoundedRectangle(cornerRadius: 6)
                                    .fill(.red)
                                    .frame(width: 30, height: 30)
                            } else {
                                Circle()
                                    .fill(.red)
                                    .frame(width: 58, height: 58)
                            }
                        }
                    }
                    .disabled(!cameraManager.cameraAuthorized)

                    Color.clear.frame(width: 44, height: 44)
                }
                .padding(.bottom, 32)
                .padding(.horizontal, 24)
            }
            .background(
                LinearGradient(
                    colors: [.clear, .black.opacity(0.55)],
                    startPoint: .top, endPoint: .bottom
                )
            )
        }
        // Player per la riproduzione del video registrato
        .sheet(isPresented: $showingVideoPlayer) {
            if let url = cameraManager.recordedVideoURL {
                VideoPlayer(player: AVPlayer(url: url))
                    .ignoresSafeArea()
            }
        }
        .alert("Errore Video", isPresented: .constant(cameraManager.errorMessage != nil)) {
            Button("OK") { cameraManager.errorMessage = nil }
        } message: {
            Text(cameraManager.errorMessage ?? "")
        }
        .task {
            await cameraManager.requestPermissions()
            cameraManager.startSession()
        }
        .onDisappear {
            if cameraManager.isRecording { cameraManager.stopVideoRecording() }
            stopTimer()
            cameraManager.stopSession()
        }
    }

    // MARK: - Azioni

    /// Alterna tra avvio e arresto della registrazione video.
    private func toggleRecording() {
        if cameraManager.isRecording {
            cameraManager.stopVideoRecording()
            stopTimer()
        } else {
            recordingDuration = 0
            cameraManager.startVideoRecording()
            startTimer()
        }
    }

    /// Avvia il timer per il conteggio della durata di registrazione.
    private func startTimer() {
        recordingTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            recordingDuration += 1
        }
    }

    /// Ferma e invalida il timer.
    private func stopTimer() {
        recordingTimer?.invalidate()
        recordingTimer = nil
    }
}

// MARK: - Indicatore di registrazione

/// Badge rosso che mostra il tempo di registrazione trascorso.
struct RecordingIndicatorView: View {
    let duration: TimeInterval

    var body: some View {
        HStack(spacing: 6) {
            // Pallino rosso lampeggiante (simulato)
            Circle()
                .fill(.red)
                .frame(width: 10, height: 10)
            Text(formattedDuration)
                .font(.system(.body, design: .monospaced).bold())
                .foregroundStyle(.white)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 6)
        .background(.black.opacity(0.65))
        .clipShape(Capsule())
    }

    /// Formato MM:SS per la durata.
    private var formattedDuration: String {
        let m = Int(duration) / 60
        let s = Int(duration) % 60
        return String(format: "%02d:%02d", m, s)
    }
}
