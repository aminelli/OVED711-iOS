//
//  CameraManager.swift
//  MediaAndSensorDemo
//
//  Manager principale per AVFoundation. Gestisce in modo thread-safe:
//  - Sessione di cattura (AVCaptureSession)
//  - Scatto di foto ad alta risoluzione (AVCapturePhotoOutput)
//  - Registrazione video su file (AVCaptureMovieFileOutput)
//  - Scansione di QR code e codici a barre (AVCaptureMetadataOutput)
//  - Richiesta e verifica dei permessi fotocamera/microfono
//

import AVFoundation
import UIKit
import Observation

// MARK: - Tipi di supporto

/// Modalità operative della fotocamera.
enum CameraMode {
    case photo    // Scatto singolo
    case video    // Registrazione video
    case scanner  // Scansione codici
}

/// Codice QR o barcode rilevato dalla fotocamera.
struct ScannedCode: Identifiable {
    let id = UUID()
    let type: AVMetadataObject.ObjectType  // Tipo: .qr, .ean13, .code128, ecc.
    let value: String                       // Contenuto decodificato
    let timestamp: Date                     // Momento della scansione
}

// MARK: - CameraManager

/// Manager osservabile per la fotocamera AVFoundation.
/// È isolato su @MainActor per garantire thread safety con SwiftUI.
/// Le operazioni AVFoundation vengono eseguite su sessionQueue dedicata.
@Observable
@MainActor
final class CameraManager: NSObject {

    // MARK: - Proprietà osservabili (aggiornate su MainActor)

    /// Indica se la fotocamera è autorizzata dall'utente.
    var cameraAuthorized: Bool = false

    /// Indica se il microfono è autorizzato (necessario per video).
    var microphoneAuthorized: Bool = false

    /// Foto catturata come UIImage (nil se nessuno scatto effettuato).
    var capturedPhoto: UIImage?

    /// URL del video registrato (nil se nessuna registrazione completata).
    var recordedVideoURL: URL?

    /// Indica se la registrazione video è in corso.
    var isRecording: Bool = false

    /// Lista dei codici scansionati nella sessione corrente.
    var scannedCodes: [ScannedCode] = []

    /// Messaggio di errore corrente (nil se nessun errore).
    var errorMessage: String?

    /// Modalità corrente della fotocamera.
    var currentMode: CameraMode = .photo

    // MARK: - Oggetti AVFoundation (nonisolated - accesso da sessionQueue)

    /// Sessione di cattura principale. Marcata nonisolated(unsafe) per accesso
    /// sicuro dalla sessionQueue senza violare Swift 6 strict concurrency.
    nonisolated(unsafe) let captureSession = AVCaptureSession()

    /// Output per la cattura di foto.
    nonisolated(unsafe) private let photoOutput = AVCapturePhotoOutput()

    /// Output per la registrazione video su file.
    nonisolated(unsafe) private let movieOutput = AVCaptureMovieFileOutput()

    /// Output per la lettura di metadati (QR, barcode).
    nonisolated(unsafe) private let metadataOutput = AVCaptureMetadataOutput()

    /// Input video corrente (riferimento al dispositivo fotocamera attivo).
    nonisolated(unsafe) private var videoInput: AVCaptureDeviceInput?

    /// Coda seriale dedicata alle operazioni AVFoundation (mai bloccare il main thread).
    private let sessionQueue = DispatchQueue(
        label: "com.mediasensordemo.camera.session",
        qos: .userInitiated
    )

    // MARK: - Permessi

    /// Richiede i permessi necessari per fotocamera e microfono.
    /// Avvia la configurazione della sessione solo se la fotocamera è autorizzata.
    func requestPermissions() async {
        // --- Permesso fotocamera ---
        let videoStatus = AVCaptureDevice.authorizationStatus(for: .video)
        if videoStatus == .notDetermined {
            // Prima richiesta: mostra il dialog di sistema all'utente
            cameraAuthorized = await AVCaptureDevice.requestAccess(for: .video)
        } else {
            cameraAuthorized = (videoStatus == .authorized)
        }

        // --- Permesso microfono ---
        let audioStatus = AVCaptureDevice.authorizationStatus(for: .audio)
        if audioStatus == .notDetermined {
            microphoneAuthorized = await AVCaptureDevice.requestAccess(for: .audio)
        } else {
            microphoneAuthorized = (audioStatus == .authorized)
        }

        // Configura la sessione solo se la fotocamera è disponibile
        if cameraAuthorized {
            await configureSession()
        }
    }

    // MARK: - Configurazione sessione

    /// Configura la sessione AVCapture in background e attende il completamento.
    private func configureSession() async {
        await withCheckedContinuation { continuation in
            sessionQueue.async { [weak self] in
                guard let self else { continuation.resume(); return }
                self.captureSession.beginConfiguration()
                self.captureSession.sessionPreset = .high
                self.addVideoInput()
                self.addAudioInput()
                self.addOutputs()
                self.captureSession.commitConfiguration()
                continuation.resume()
            }
        }
    }

    /// Aggiunge l'input video dalla fotocamera.
    /// Usa userPreferredCamera (iOS 17+, API raccomandata), con fallback progressivo.
    /// Eseguito sulla sessionQueue (nonisolated).
    nonisolated private func addVideoInput() {
        // iOS 17+: userPreferredCamera restituisce la fotocamera preferita dall'utente
        // (di default la migliore fotocamera posteriore disponibile).
        // Fallback progressivo per garantire compatibilità su qualsiasi iPhone.
        guard let camera = AVCaptureDevice.userPreferredCamera
            ?? AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back)
            ?? AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front)
            ?? AVCaptureDevice.default(for: .video)
        else {
            Task { @MainActor in self.errorMessage = "Nessuna fotocamera disponibile" }
            return
        }
        do {
            let input = try AVCaptureDeviceInput(device: camera)
            if captureSession.canAddInput(input) {
                captureSession.addInput(input)
                videoInput = input
            }
        } catch {
            Task { @MainActor in
                self.errorMessage = "Errore input fotocamera: \(error.localizedDescription)"
            }
        }
    }

    /// Aggiunge l'input del microfono alla sessione (necessario per la registrazione video).
    nonisolated private func addAudioInput() {
        guard let mic = AVCaptureDevice.default(for: .audio) else { return }
        do {
            let audioInput = try AVCaptureDeviceInput(device: mic)
            if captureSession.canAddInput(audioInput) {
                captureSession.addInput(audioInput)
            }
        } catch {
            print("[Camera] Errore aggiunta microfono: \(error.localizedDescription)")
        }
    }

    /// Aggiunge gli output (foto, video, metadati) alla sessione.
    nonisolated private func addOutputs() {
        // Output foto ad alta risoluzione
        if captureSession.canAddOutput(photoOutput) {
            captureSession.addOutput(photoOutput)
            // isHighResolutionCaptureEnabled è stato rimosso in iOS 16+;
            // la risoluzione massima viene ora configurata tramite maxPhotoDimensions
            // che viene impostato automaticamente al valore massimo supportato.
            // Abilita cattura in formato HEIF se disponibile
            if photoOutput.availablePhotoCodecTypes.contains(.hevc) {
                // La preferenza viene passata tramite AVCapturePhotoSettings al momento dello scatto
            }
        }

        // Output video su file
        if captureSession.canAddOutput(movieOutput) {
            captureSession.addOutput(movieOutput)
        }

        // Output metadati per QR e codici a barre
        if captureSession.canAddOutput(metadataOutput) {
            captureSession.addOutput(metadataOutput)
            metadataOutput.setMetadataObjectsDelegate(self, queue: .main)

            // Tutti i tipi di codici supportati da AVFoundation
            let desired: [AVMetadataObject.ObjectType] = [
                .qr,         // QR Code (standard ISO 18004)
                .ean13,      // EAN-13: prodotti europei
                .ean8,       // EAN-8: prodotti europei (formato breve)
                .code128,    // Code 128: uso generale
                .code39,     // Code 39: settore sanitario/militare
                .code93,     // Code 93: variante compatta di Code 39
                .upce,       // UPC-E: prodotti USA
                .pdf417,     // PDF417: documenti di identità e biglietti
                .aztec,      // Aztec: biglietti di trasporto
                .dataMatrix  // Data Matrix: industria e logistica
            ]
            // Usa solo i tipi effettivamente supportati dall'output
            let available = metadataOutput.availableMetadataObjectTypes
            metadataOutput.metadataObjectTypes = desired.filter { available.contains($0) }
        }
    }

    // MARK: - Avvio / Arresto sessione

    /// Avvia la sessione di cattura in background.
    /// Deve essere chiamato dopo requestPermissions().
    func startSession() {
        sessionQueue.async { [weak self] in
            guard let self, !self.captureSession.isRunning else { return }
            self.captureSession.startRunning()
        }
    }

    /// Ferma la sessione di cattura (libera le risorse hardware).
    func stopSession() {
        sessionQueue.async { [weak self] in
            guard let self, self.captureSession.isRunning else { return }
            self.captureSession.stopRunning()
        }
    }

    // MARK: - Scatto foto

    /// Scatta una foto con impostazioni ottimizzate (flash auto, stabilizzazione).
    func capturePhoto() {
        // Crea impostazioni per la foto
        let settings: AVCapturePhotoSettings
        // Preferisce HEVC per minor dimensione a parità di qualità
        if photoOutput.availablePhotoCodecTypes.contains(.hevc) {
            settings = AVCapturePhotoSettings(format: [AVVideoCodecKey: AVVideoCodecType.hevc])
        } else {
            settings = AVCapturePhotoSettings()
        }
        // Flash automatico se disponibile
        if photoOutput.supportedFlashModes.contains(.auto) {
            settings.flashMode = .auto
        }
        photoOutput.capturePhoto(with: settings, delegate: self)
    }

    // MARK: - Registrazione video

    /// Avvia la registrazione video su un file temporaneo in formato MOV.
    func startVideoRecording() {
        guard !movieOutput.isRecording else { return }
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let url = docs.appendingPathComponent("rec_\(Int(Date().timeIntervalSince1970)).mov")
        movieOutput.startRecording(to: url, recordingDelegate: self)
        isRecording = true
    }

    /// Ferma la registrazione video in corso.
    func stopVideoRecording() {
        guard movieOutput.isRecording else { return }
        movieOutput.stopRecording()
        isRecording = false
    }

    // MARK: - Scanner

    /// Rimuove tutti i codici scansionati dalla lista corrente.
    func clearScannedCodes() {
        scannedCodes.removeAll()
    }

    // MARK: - Zoom fotocamera

    /// Imposta il fattore di zoom della fotocamera (1.0 = normale).
    /// Il valore viene limitato ai valori minimi/massimi supportati dal dispositivo.
    func setZoom(factor: CGFloat) {
        guard let device = videoInput?.device else { return }
        do {
            try device.lockForConfiguration()
            let clamped = max(device.minAvailableVideoZoomFactor,
                              min(factor, device.maxAvailableVideoZoomFactor))
            device.videoZoomFactor = clamped
            device.unlockForConfiguration()
        } catch {
            print("[Camera] Errore zoom: \(error.localizedDescription)")
        }
    }

    // MARK: - Cambio fotocamera

    /// Alterna tra fotocamera anteriore e posteriore.
    func toggleCamera() {
        guard let currentInput = videoInput else { return }
        let newPosition: AVCaptureDevice.Position =
            currentInput.device.position == .back ? .front : .back

        sessionQueue.async { [weak self] in
            guard let self else { return }
            guard let newDevice = AVCaptureDevice.default(
                .builtInWideAngleCamera, for: .video, position: newPosition
            ) else { return }

            do {
                let newInput = try AVCaptureDeviceInput(device: newDevice)
                self.captureSession.beginConfiguration()
                self.captureSession.removeInput(currentInput)
                if self.captureSession.canAddInput(newInput) {
                    self.captureSession.addInput(newInput)
                    self.videoInput = newInput
                }
                self.captureSession.commitConfiguration()
            } catch {
                print("[Camera] Errore cambio fotocamera: \(error.localizedDescription)")
            }
        }
    }
}

// MARK: - AVCapturePhotoCaptureDelegate

extension CameraManager: AVCapturePhotoCaptureDelegate {

    /// Chiamato al termine dell'elaborazione della foto catturata.
    nonisolated func photoOutput(
        _ output: AVCapturePhotoOutput,
        didFinishProcessingPhoto photo: AVCapturePhoto,
        error: Error?
    ) {
        if let error {
            Task { @MainActor in self.errorMessage = "Errore foto: \(error.localizedDescription)" }
            return
        }
        guard let data = photo.fileDataRepresentation(),
              let image = UIImage(data: data) else { return }

        Task { @MainActor in
            self.capturedPhoto = image
        }
    }
}

// MARK: - AVCaptureFileOutputRecordingDelegate

extension CameraManager: AVCaptureFileOutputRecordingDelegate {

    /// Chiamato quando la registrazione video è terminata e il file è stato salvato.
    nonisolated func fileOutput(
        _ output: AVCaptureFileOutput,
        didFinishRecordingTo outputFileURL: URL,
        from connections: [AVCaptureConnection],
        error: Error?
    ) {
        if let error {
            Task { @MainActor in
                self.errorMessage = "Errore video: \(error.localizedDescription)"
            }
            return
        }
        Task { @MainActor in
            self.recordedVideoURL = outputFileURL
            print("[Camera] Video salvato: \(outputFileURL.lastPathComponent)")
        }
    }
}

// MARK: - AVCaptureMetadataOutputObjectsDelegate

extension CameraManager: AVCaptureMetadataOutputObjectsDelegate {

    /// Chiamato (su DispatchQueue.main) quando la fotocamera rileva codici nel frame.
    nonisolated func metadataOutput(
        _ output: AVCaptureMetadataOutput,
        didOutput metadataObjects: [AVMetadataObject],
        from connection: AVCaptureConnection
    ) {
        // Estrae i codici leggibili dagli oggetti metadato
        let newCodes: [ScannedCode] = metadataObjects.compactMap { obj in
            guard let readable = obj as? AVMetadataMachineReadableCodeObject,
                  let value = readable.stringValue else { return nil }
            return ScannedCode(type: readable.type, value: value, timestamp: Date())
        }
        guard !newCodes.isEmpty else { return }

        Task { @MainActor in
            for code in newCodes {
                // Evita duplicati nella stessa sessione
                guard !scannedCodes.contains(where: {
                    $0.value == code.value && $0.type == code.type
                }) else { continue }
                scannedCodes.append(code)
                // Feedback aptico al rilevamento di un nuovo codice
                let generator = UINotificationFeedbackGenerator()
                generator.notificationOccurred(.success)
            }
        }
    }
}
