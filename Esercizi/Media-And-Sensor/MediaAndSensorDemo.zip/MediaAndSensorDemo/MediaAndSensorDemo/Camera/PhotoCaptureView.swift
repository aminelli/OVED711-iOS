//
//  PhotoCaptureView.swift
//  MediaAndSensorDemo
//
//  Interfaccia per la cattura di fotografie ad alta risoluzione.
//  Mostra il feed live, permette di scattare foto, invertire la fotocamera
//  e visualizzare/salvare l'ultima immagine catturata.
//

import SwiftUI
import AVFoundation

/// Vista per lo scatto fotografico tramite AVCapturePhotoOutput.
/// Gestisce il permesso fotocamera, il feed live e la visualizzazione della foto catturata.
struct PhotoCaptureView: View {

    /// Manager della fotocamera (un'istanza per view per evitare conflitti con VideoRecordingView).
    @State private var cameraManager = CameraManager()

    /// Controlla la presentazione della sheet con la foto catturata.
    @State private var showingCapturedPhoto = false

    var body: some View {
        ZStack(alignment: .bottom) {

            // --- Sfondo: feed live fotocamera o messaggio permesso negato ---
            if cameraManager.cameraAuthorized {
                CameraPreviewView(session: cameraManager.captureSession)
                    .ignoresSafeArea()
            } else {
                PermissionDeniedView(
                    icon: "camera.fill",
                    message: "Consenti l'accesso alla fotocamera nelle Impostazioni per scattare foto."
                )
            }

            // --- Controlli sovrapposti in basso ---
            VStack(spacing: 20) {

                // Miniatura dell'ultima foto catturata
                if let photo = cameraManager.capturedPhoto {
                    Button {
                        showingCapturedPhoto = true
                    } label: {
                        Image(uiImage: photo)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 60, height: 60)
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(.white, lineWidth: 2)
                            )
                    }
                }

                // Barra con pulsanti fotocamera
                HStack(spacing: 48) {

                    // Pulsante inversione fotocamera (anteriore/posteriore)
                    Button {
                        cameraManager.toggleCamera()
                    } label: {
                        Image(systemName: "arrow.triangle.2.circlepath.camera")
                            .font(.title2)
                            .foregroundStyle(.white)
                    }

                    // Pulsante scatto principale (cerchio bianco)
                    Button {
                        cameraManager.capturePhoto()
                    } label: {
                        ZStack {
                            Circle()
                                .strokeBorder(.white, lineWidth: 4)
                                .frame(width: 74, height: 74)
                            Circle()
                                .fill(.white)
                                .frame(width: 62, height: 62)
                        }
                    }
                    .disabled(!cameraManager.cameraAuthorized)

                    // Placeholder per simmetria
                    Color.clear.frame(width: 44, height: 44)
                }
                .padding(.bottom, 32)
                .padding(.horizontal, 24)
            }
            .background(
                // Gradiente scuro per leggibilità dei controlli sul feed
                LinearGradient(
                    colors: [.clear, .black.opacity(0.55)],
                    startPoint: .top, endPoint: .bottom
                )
            )
        }
        // Sheet con anteprima fullscreen della foto catturata
        .sheet(isPresented: $showingCapturedPhoto) {
            if let photo = cameraManager.capturedPhoto {
                CapturedPhotoView(image: photo)
            }
        }
        // Alert in caso di errori AVFoundation
        .alert("Errore Fotocamera", isPresented: .constant(cameraManager.errorMessage != nil)) {
            Button("OK") { cameraManager.errorMessage = nil }
        } message: {
            Text(cameraManager.errorMessage ?? "")
        }
        // Richiede permessi e avvia la sessione all'apertura della vista
        .task {
            await cameraManager.requestPermissions()
            cameraManager.startSession()
        }
        // Ferma la sessione per liberare la fotocamera quando la vista scompare
        .onDisappear {
            cameraManager.stopSession()
        }
    }
}

// MARK: - Viste di supporto

/// Vista fullscreen per visualizzare e salvare la foto catturata.
struct CapturedPhotoView: View {
    let image: UIImage
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Image(uiImage: image)
                .resizable()
                .scaledToFit()
                .background(.black)
                .ignoresSafeArea()
                .toolbar {
                    // Pulsante di chiusura
                    ToolbarItem(placement: .topBarTrailing) {
                        Button("Chiudi") { dismiss() }
                            .tint(.white)
                    }
                    // Salvataggio nella libreria foto
                    ToolbarItem(placement: .topBarLeading) {
                        Button {
                            UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
                        } label: {
                            Image(systemName: "square.and.arrow.down")
                                .tint(.white)
                        }
                    }
                }
                .toolbarBackground(.black.opacity(0.5), for: .navigationBar)
        }
    }
}

/// Vista placeholder mostrata quando i permessi hardware non sono stati concessi.
struct PermissionDeniedView: View {
    let icon: String
    let message: String

    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: icon)
                .font(.system(size: 56))
                .foregroundStyle(.gray)

            Text("Accesso non autorizzato")
                .font(.title2.bold())

            Text(message)
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
                .padding(.horizontal, 32)

            // Apre le impostazioni dell'app per modificare i permessi
            Button("Apri Impostazioni") {
                if let url = URL(string: UIApplication.openSettingsURLString) {
                    UIApplication.shared.open(url)
                }
            }
            .buttonStyle(.borderedProminent)
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(.systemGroupedBackground))
    }
}
