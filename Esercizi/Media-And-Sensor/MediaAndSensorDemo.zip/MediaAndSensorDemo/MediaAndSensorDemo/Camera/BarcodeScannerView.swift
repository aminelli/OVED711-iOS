//
//  BarcodeScannerView.swift
//  MediaAndSensorDemo
//
//  Scanner per QR code e codici a barre multipli tramite AVCaptureMetadataOutput.
//  Mostra il feed live con mirino animato, lista dei codici rilevati e
//  una vista dettaglio con azioni (apri URL, copia negli appunti).
//

import SwiftUI
import AVFoundation

/// Vista per la scansione di QR code e codici a barre.
/// I codici rilevati vengono mostrati in una lista scorrevole in basso.
struct BarcodeScannerView: View {

    @State private var cameraManager = CameraManager()
    /// Codice selezionato per visualizzare i dettagli.
    @State private var selectedCode: ScannedCode?

    var body: some View {
        ZStack(alignment: .bottom) {

            // Feed live fotocamera
            if cameraManager.cameraAuthorized {
                CameraPreviewView(session: cameraManager.captureSession)
                    .ignoresSafeArea()
                // Mirino grafico sovrapposto al feed
                ScannerOverlayView()
            } else {
                PermissionDeniedView(
                    icon: "qrcode.viewfinder",
                    message: "Consenti l'accesso alla fotocamera per scansionare codici."
                )
            }

            // Pannello inferiore con i codici rilevati
            if !cameraManager.scannedCodes.isEmpty {
                VStack(alignment: .leading, spacing: 0) {

                    // Intestazione con pulsante "Pulisci"
                    HStack {
                        Text("Codici Rilevati")
                            .font(.headline)
                            .foregroundStyle(.white)
                        Spacer()
                        Button {
                            cameraManager.clearScannedCodes()
                        } label: {
                            Text("Pulisci")
                                .font(.subheadline)
                                .foregroundStyle(.blue)
                        }
                    }
                    .padding(.horizontal)
                    .padding(.top, 12)

                    // Ultimi 5 codici scansionati
                    ForEach(cameraManager.scannedCodes.suffix(5)) { code in
                        ScannedCodeRowView(code: code)
                            .onTapGesture { selectedCode = code }
                    }
                    .padding(.bottom, 8)
                }
                .background(.black.opacity(0.82))
                .clipShape(RoundedRectangle(cornerRadius: 18))
                .padding()
            }
        }
        // Sheet dettaglio codice selezionato
        .sheet(item: $selectedCode) { code in
            ScannedCodeDetailView(code: code)
        }
        .task {
            await cameraManager.requestPermissions()
            cameraManager.currentMode = .scanner
            cameraManager.startSession()
        }
        .onDisappear {
            cameraManager.stopSession()
        }
    }
}

// MARK: - Mirino scanner

/// Overlay grafico che oscura le aree fuori dal rettangolo di scansione
/// e disegna gli angoli del mirino in verde.
struct ScannerOverlayView: View {

    var body: some View {
        GeometryReader { geo in
            let side = min(geo.size.width, geo.size.height) * 0.68
            let ox = (geo.size.width - side) / 2
            let oy = (geo.size.height - side) / 2

            // Maschera semitrasparente con finestra ritagliata
            Rectangle()
                .fill(.black.opacity(0.45))
                .overlay(
                    Rectangle()
                        .frame(width: side, height: side)
                        .blendMode(.destinationOut)
                        .position(x: geo.size.width / 2, y: geo.size.height / 2)
                )
                .compositingGroup()

            // Angoli del mirino
            ScannerCornersShape(ox: ox, oy: oy, side: side)
                .stroke(.green, lineWidth: 3)
        }
        .ignoresSafeArea()
    }
}

/// Shape che disegna i quattro angoli del mirino.
struct ScannerCornersShape: Shape {
    let ox: CGFloat  // Origine X del rettangolo
    let oy: CGFloat  // Origine Y del rettangolo
    let side: CGFloat  // Lato del rettangolo

    private let len: CGFloat = 26  // Lunghezza di ogni segmento d'angolo

    func path(in rect: CGRect) -> Path {
        var p = Path()
        // Angolo in alto a sinistra
        p.move(to: CGPoint(x: ox, y: oy + len))
        p.addLine(to: CGPoint(x: ox, y: oy))
        p.addLine(to: CGPoint(x: ox + len, y: oy))
        // Angolo in alto a destra
        p.move(to: CGPoint(x: ox + side - len, y: oy))
        p.addLine(to: CGPoint(x: ox + side, y: oy))
        p.addLine(to: CGPoint(x: ox + side, y: oy + len))
        // Angolo in basso a destra
        p.move(to: CGPoint(x: ox + side, y: oy + side - len))
        p.addLine(to: CGPoint(x: ox + side, y: oy + side))
        p.addLine(to: CGPoint(x: ox + side - len, y: oy + side))
        // Angolo in basso a sinistra
        p.move(to: CGPoint(x: ox + len, y: oy + side))
        p.addLine(to: CGPoint(x: ox, y: oy + side))
        p.addLine(to: CGPoint(x: ox, y: oy + side - len))
        return p
    }
}

// MARK: - Righe lista codici

/// Riga compatta per un singolo codice scansionato.
struct ScannedCodeRowView: View {
    let code: ScannedCode

    var body: some View {
        HStack(spacing: 12) {
            // Icona differenziata per QR code vs barcode
            Image(systemName: code.type == .qr ? "qrcode" : "barcode")
                .foregroundStyle(.blue)
                .frame(width: 22)

            VStack(alignment: .leading, spacing: 2) {
                Text(code.value)
                    .font(.caption.bold())
                    .foregroundStyle(.white)
                    .lineLimit(1)
                Text(code.type.rawValue)
                    .font(.caption2)
                    .foregroundStyle(.gray)
            }

            Spacer()

            Image(systemName: "chevron.right")
                .font(.caption2)
                .foregroundStyle(.gray)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
    }
}

// MARK: - Dettaglio codice

/// Schermata dettaglio per un singolo codice scansionato.
/// Permette di copiare il valore e aprire gli URL nel browser.
struct ScannedCodeDetailView: View {
    let code: ScannedCode
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section("Tipo Codice") {
                    Label(code.type.rawValue, systemImage: code.type == .qr ? "qrcode" : "barcode")
                }

                Section("Contenuto") {
                    Text(code.value)
                        .textSelection(.enabled) // Permette la selezione del testo

                    // Se è un URL valido, mostra il pulsante "Apri"
                    if let url = URL(string: code.value),
                       UIApplication.shared.canOpenURL(url) {
                        Button {
                            UIApplication.shared.open(url)
                        } label: {
                            Label("Apri nel Browser", systemImage: "safari")
                        }
                    }
                }

                Section("Data Scansione") {
                    Text(code.timestamp.formatted(date: .complete, time: .complete))
                }
            }
            .navigationTitle("Dettaglio Codice")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Chiudi") { dismiss() }
                }
                ToolbarItem(placement: .topBarLeading) {
                    // Copia il valore del codice negli appunti
                    Button {
                        UIPasteboard.general.string = code.value
                    } label: {
                        Image(systemName: "doc.on.doc")
                    }
                }
            }
        }
    }
}
