//
//  MotionManager.swift
//  MediaAndSensorDemo
//
//  Gestisce l'accesso ai sensori di movimento tramite CoreMotion:
//  - Accelerometro: forza gravitazionale sui tre assi (g)
//  - Giroscopio: velocità angolare (rad/s)
//  - Magnetometro: campo magnetico ambientale (µT)
//  - Device Motion: orientamento 3D calibrato (roll/pitch/yaw)
//  - Altimetro barometrico: variazione di altitudine e pressione
//  - Activity Recognition: riconoscimento attività fisica (ML)
//  - Pedometro: conteggio passi in tempo reale
//

import CoreMotion
import Observation

// MARK: - Tipi di supporto

/// Dati dell'accelerometro (accelerazione relativa alla gravità).
struct AccelerometerData {
    let x: Double  // Asse X laterale (g)
    let y: Double  // Asse Y verticale (g)
    let z: Double  // Asse Z profondità (g)

    /// Magnitudo del vettore accelerazione totale.
    var magnitude: Double { sqrt(x*x + y*y + z*z) }
}

/// Dati del giroscopio (velocità angolare di rotazione).
struct GyroscopeData {
    let x: Double  // Rotazione attorno all'asse X (rad/s) - pitch
    let y: Double  // Rotazione attorno all'asse Y (rad/s) - yaw
    let z: Double  // Rotazione attorno all'asse Z (rad/s) - roll
}

/// Dati del magnetometro (campo magnetico locale).
struct MagnetometerData {
    let x: Double  // Campo asse X (µT)
    let y: Double  // Campo asse Y (µT)
    let z: Double  // Campo asse Z (µT)

    /// Intensità totale del campo magnetico.
    var magnitude: Double { sqrt(x*x + y*y + z*z) }
}

/// Attività fisica rilevata dal motore di Activity Recognition.
enum DetectedActivity: String, CaseIterable {
    case stationary = "Ferma"
    case walking    = "Camminata"
    case running    = "Corsa"
    case automotive = "In Auto"
    case cycling    = "Ciclismo"
    case unknown    = "Sconosciuta"
}

// MARK: - MotionManager

/// Manager per tutti i sensori di movimento tramite CoreMotion.
/// Aggiornamenti ricevuti su operationQueue e pubblicati su @MainActor.
@Observable
@MainActor
final class MotionManager {

    // MARK: - Proprietà osservabili

    var accelerometerData: AccelerometerData?
    var gyroscopeData: GyroscopeData?
    var magnetometerData: MagnetometerData?

    /// Orientamento 3D calibrato del dispositivo (roll, pitch, yaw in radianti).
    var deviceAttitude: CMAttitude?

    /// Variazione di altitudine relativa all'avvio (metri, barometrico).
    var relativeAltitude: Double?

    /// Pressione atmosferica relativa (kPa).
    var relativePressure: Double?

    /// Attività fisica corrente rilevata tramite ML.
    var currentActivity: DetectedActivity = .unknown

    /// Numero di passi dall'avvio del monitoraggio.
    var stepCount: Int = 0

    /// Distanza percorsa dall'avvio del monitoraggio (metri).
    var distanceCovered: Double = 0

    /// Indica se il monitoraggio dei sensori è attivo.
    var isMonitoring: Bool = false

    /// Indica se il pedometro è disponibile su questo dispositivo.
    var isPedometerAvailable: Bool = false

    /// Indica se l'altimetro è disponibile su questo dispositivo.
    var isAltimeterAvailable: Bool = false

    /// Messaggio di errore corrente.
    var errorMessage: String?

    // MARK: - Componenti CoreMotion

    private let motionManager   = CMMotionManager()
    private let activityManager = CMMotionActivityManager()
    private let pedometer       = CMPedometer()
    private let altimeter       = CMAltimeter()

    /// Coda dedicata agli aggiornamenti dei sensori (alta priorità, non main thread).
    private let sensorQueue: OperationQueue = {
        let q = OperationQueue()
        q.name = "com.mediasensordemo.motion"
        q.qualityOfService = .userInitiated
        q.maxConcurrentOperationCount = 1
        return q
    }()

    // MARK: - Inizializzazione

    init() {
        isPedometerAvailable = CMPedometer.isStepCountingAvailable()
        isAltimeterAvailable = CMAltimeter.isRelativeAltitudeAvailable()
    }

    // MARK: - Avvio / Arresto

    /// Avvia il monitoraggio di tutti i sensori disponibili sul dispositivo.
    func startMonitoring() {
        guard !isMonitoring else { return }
        isMonitoring = true
        startAccelerometer()
        startGyroscope()
        startMagnetometer()
        startDeviceMotion()
        startAltimeter()
        startActivityRecognition()
        startPedometer()
    }

    /// Ferma tutti i sensori e libera le risorse hardware.
    func stopMonitoring() {
        guard isMonitoring else { return }
        isMonitoring = false
        motionManager.stopAccelerometerUpdates()
        motionManager.stopGyroUpdates()
        motionManager.stopMagnetometerUpdates()
        motionManager.stopDeviceMotionUpdates()
        altimeter.stopRelativeAltitudeUpdates()
        activityManager.stopActivityUpdates()
        pedometer.stopUpdates()
    }

    // MARK: - Avvio sensori individuali

    /// Avvia l'accelerometro a 60 Hz.
    /// Misura la forza di accelerazione inclusa la gravità (unità: g = 9.81 m/s²).
    private func startAccelerometer() {
        guard motionManager.isAccelerometerAvailable else { return }
        motionManager.accelerometerUpdateInterval = 1.0 / 60.0
        motionManager.startAccelerometerUpdates(to: sensorQueue) { [weak self] data, _ in
            guard let self, let data else { return }
            let acc = AccelerometerData(
                x: data.acceleration.x,
                y: data.acceleration.y,
                z: data.acceleration.z
            )
            Task { @MainActor in self.accelerometerData = acc }
        }
    }

    /// Avvia il giroscopio a 60 Hz.
    /// Misura la velocità angolare di rotazione del dispositivo (rad/s).
    private func startGyroscope() {
        guard motionManager.isGyroAvailable else { return }
        motionManager.gyroUpdateInterval = 1.0 / 60.0
        motionManager.startGyroUpdates(to: sensorQueue) { [weak self] data, _ in
            guard let self, let data else { return }
            let gyro = GyroscopeData(
                x: data.rotationRate.x,
                y: data.rotationRate.y,
                z: data.rotationRate.z
            )
            Task { @MainActor in self.gyroscopeData = gyro }
        }
    }

    /// Avvia il magnetometro a 20 Hz.
    /// Misura il campo magnetico ambientale (µT). Utile per bussola e rilevamento metalli.
    private func startMagnetometer() {
        guard motionManager.isMagnetometerAvailable else { return }
        motionManager.magnetometerUpdateInterval = 1.0 / 20.0
        motionManager.startMagnetometerUpdates(to: sensorQueue) { [weak self] data, _ in
            guard let self, let data else { return }
            let mag = MagnetometerData(
                x: data.magneticField.x,
                y: data.magneticField.y,
                z: data.magneticField.z
            )
            Task { @MainActor in self.magnetometerData = mag }
        }
    }

    /// Avvia il Device Motion a 30 Hz.
    /// Combina accelerometro, giroscopio e magnetometro per un orientamento calibrato.
    /// Usa il reference frame xMagneticNorthZVertical (Nord magnetico = riferimento X).
    private func startDeviceMotion() {
        guard motionManager.isDeviceMotionAvailable else { return }
        motionManager.deviceMotionUpdateInterval = 1.0 / 30.0
        motionManager.startDeviceMotionUpdates(
            using: .xMagneticNorthZVertical,
            to: sensorQueue
        ) { [weak self] motion, _ in
            guard let self, let motion else { return }
            Task { @MainActor in self.deviceAttitude = motion.attitude }
        }
    }

    /// Avvia il monitoraggio barometrico (disponibile da iPhone 6).
    /// Restituisce la variazione di altitudine relativa all'avvio e la pressione.
    private func startAltimeter() {
        guard CMAltimeter.isRelativeAltitudeAvailable() else { return }
        altimeter.startRelativeAltitudeUpdates(to: sensorQueue) { [weak self] data, _ in
            guard let self, let data else { return }
            Task { @MainActor in
                self.relativeAltitude  = data.relativeAltitude.doubleValue
                self.relativePressure  = data.pressure.doubleValue
            }
        }
    }

    /// Avvia il riconoscimento dell'attività fisica tramite CoreMotion ML.
    /// Classifica automaticamente: ferma, camminata, corsa, guida, ciclismo.
    private func startActivityRecognition() {
        guard CMMotionActivityManager.isActivityAvailable() else { return }
        activityManager.startActivityUpdates(to: sensorQueue) { [weak self] activity in
            guard let self, let activity else { return }
            let detected: DetectedActivity
            if      activity.stationary { detected = .stationary }
            else if activity.walking    { detected = .walking }
            else if activity.running    { detected = .running }
            else if activity.automotive { detected = .automotive }
            else if activity.cycling    { detected = .cycling }
            else                        { detected = .unknown }
            Task { @MainActor in self.currentActivity = detected }
        }
    }

    /// Avvia il contatore passi e la distanza dal momento corrente.
    private func startPedometer() {
        guard CMPedometer.isStepCountingAvailable() else { return }
        pedometer.startUpdates(from: Date()) { [weak self] data, _ in
            guard let self, let data else { return }
            Task { @MainActor in
                self.stepCount       = data.numberOfSteps.intValue
                self.distanceCovered = data.distance?.doubleValue ?? 0
            }
        }
    }
}
