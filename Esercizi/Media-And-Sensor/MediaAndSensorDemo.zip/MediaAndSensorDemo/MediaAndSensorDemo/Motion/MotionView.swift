//
//  MotionView.swift
//  MediaAndSensorDemo
//
//  Visualizza in tempo reale i dati di tutti i sensori di movimento:
//  attività fisica, passi, accelerometro, giroscopio, magnetometro,
//  orientamento (attitude) e altimetro barometrico.
//

import SwiftUI
import CoreMotion

/// Vista principale per la sezione Sensori di Movimento.
/// Avvia il monitoraggio all'apparire e lo ferma alla scomparsa.
struct MotionView: View {

    @State private var motionManager = MotionManager()

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {

                    // Attività fisica corrente + passi
                    ActivityStepsCard(
                        activity: motionManager.currentActivity,
                        stepCount: motionManager.stepCount,
                        distance: motionManager.distanceCovered
                    )

                    // Accelerometro
                    if let acc = motionManager.accelerometerData {
                        SensorDataCard(title: "Accelerometro", icon: "iphone.motion") {
                            SensorAxisRow(label: "X", value: acc.x,         unit: "g",     color: .red)
                            SensorAxisRow(label: "Y", value: acc.y,         unit: "g",     color: .green)
                            SensorAxisRow(label: "Z", value: acc.z,         unit: "g",     color: .blue)
                            SensorAxisRow(label: "|a|", value: acc.magnitude, unit: "g",   color: .purple)
                        }
                    }

                    // Giroscopio
                    if let gyro = motionManager.gyroscopeData {
                        SensorDataCard(title: "Giroscopio", icon: "gyroscope") {
                            SensorAxisRow(label: "X (Pitch)", value: gyro.x, unit: "rad/s", color: .red)
                            SensorAxisRow(label: "Y (Yaw)",   value: gyro.y, unit: "rad/s", color: .green)
                            SensorAxisRow(label: "Z (Roll)",  value: gyro.z, unit: "rad/s", color: .blue)
                        }
                    }

                    // Magnetometro
                    if let mag = motionManager.magnetometerData {
                        SensorDataCard(title: "Magnetometro (Bussola)", icon: "compass.drawing") {
                            SensorAxisRow(label: "X", value: mag.x,           unit: "µT", color: .red)
                            SensorAxisRow(label: "Y", value: mag.y,           unit: "µT", color: .green)
                            SensorAxisRow(label: "Z", value: mag.z,           unit: "µT", color: .blue)
                            SensorAxisRow(label: "|B|", value: mag.magnitude, unit: "µT", color: .orange)
                        }
                    }

                    // Orientamento dispositivo (Device Motion calibrato)
                    if let att = motionManager.deviceAttitude {
                        SensorDataCard(title: "Orientamento (Attitude)", icon: "rotate.3d") {
                            SensorAxisRow(label: "Roll",  value: att.roll  * 180 / .pi, unit: "°", color: .red)
                            SensorAxisRow(label: "Pitch", value: att.pitch * 180 / .pi, unit: "°", color: .green)
                            SensorAxisRow(label: "Yaw",   value: att.yaw   * 180 / .pi, unit: "°", color: .blue)
                            // Visualizzazione grafica dell'angolo di inclinazione
                            AttitudeIndicatorView(roll: att.roll, pitch: att.pitch)
                                .frame(height: 80)
                                .padding(.top, 4)
                        }
                    }

                    // Altimetro barometrico
                    if let alt = motionManager.relativeAltitude {
                        SensorDataCard(title: "Altimetro Barometrico", icon: "mountain.2") {
                            LabeledContent("Δ Altitudine") {
                                Text(String(format: "%+.2f m", alt))
                                    .font(.system(.body, design: .monospaced).bold())
                            }
                            if let pressure = motionManager.relativePressure {
                                LabeledContent("Pressione Rel.") {
                                    Text(String(format: "%.3f kPa", pressure))
                                        .font(.system(.body, design: .monospaced))
                                }
                            }
                        }
                    }

                    // Informazioni disponibilità sensori
                    SensorAvailabilityCard(motionManager: motionManager)
                }
                .padding(.vertical)
            }
            .navigationTitle("Sensori di Movimento")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        motionManager.isMonitoring
                            ? motionManager.stopMonitoring()
                            : motionManager.startMonitoring()
                    } label: {
                        Image(systemName: motionManager.isMonitoring
                              ? "stop.circle.fill" : "play.circle.fill")
                            .imageScale(.large)
                            .foregroundStyle(motionManager.isMonitoring ? .red : .blue)
                    }
                }
            }
        }
        .onAppear  { motionManager.startMonitoring() }
        .onDisappear { motionManager.stopMonitoring() }
    }
}

// MARK: - Card attività e passi

/// Card che mostra attività fisica corrente, passi e distanza percorsa.
struct ActivityStepsCard: View {
    let activity: DetectedActivity
    let stepCount: Int
    let distance: Double

    var body: some View {
        HStack(spacing: 0) {
            // Attività
            VStack(spacing: 6) {
                Image(systemName: activityIcon)
                    .font(.system(size: 34))
                    .foregroundStyle(.blue)
                Text(activity.rawValue)
                    .font(.caption.bold())
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity)

            Divider().frame(height: 55)

            // Passi
            VStack(spacing: 2) {
                Text("\(stepCount)")
                    .font(.title.bold())
                    .foregroundStyle(.green)
                Text("Passi")
                    .font(.caption.bold())
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity)

            Divider().frame(height: 55)

            // Distanza
            VStack(spacing: 2) {
                Text(String(format: "%.0f", distance))
                    .font(.title.bold())
                    .foregroundStyle(.orange)
                Text("Metri")
                    .font(.caption.bold())
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity)
        }
        .padding()
        .background(.regularMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .padding(.horizontal)
    }

    private var activityIcon: String {
        switch activity {
        case .stationary: return "figure.stand"
        case .walking:    return "figure.walk"
        case .running:    return "figure.run"
        case .automotive: return "car.fill"
        case .cycling:    return "bicycle"
        case .unknown:    return "questionmark.circle"
        }
    }
}

// MARK: - Card generica sensore

/// Card riutilizzabile per visualizzare i dati di un sensore con titolo e icona.
struct SensorDataCard<Content: View>: View {
    let title: String
    let icon: String
    @ViewBuilder let content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label(title, systemImage: icon)
                .font(.headline)
            Divider()
            content
        }
        .padding()
        .background(.regularMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .padding(.horizontal)
    }
}

// MARK: - Riga asse sensore

/// Riga per un singolo asse con barra visiva proporzionale al valore.
struct SensorAxisRow: View {
    let label: String
    let value: Double
    let unit: String
    let color: Color

    var body: some View {
        HStack(spacing: 8) {
            // Etichetta asse
            Text(label)
                .font(.system(.caption, design: .monospaced).bold())
                .foregroundStyle(color)
                .frame(width: 52, alignment: .leading)

            // Barra di progressione normalizzata sul range -10…+10
            GeometryReader { geo in
                let normalised = min(abs(value) / 10.0, 1.0)
                ZStack(alignment: .leading) {
                    Capsule().fill(.gray.opacity(0.18))
                    Capsule()
                        .fill(color.opacity(0.75))
                        .frame(width: geo.size.width * normalised)
                }
            }
            .frame(height: 7)

            // Valore numerico con unità
            Text(String(format: "%+.3f %@", value, unit))
                .font(.system(.caption, design: .monospaced))
                .frame(width: 96, alignment: .trailing)
        }
    }
}

// MARK: - Indicatore attitude grafico

/// Rappresentazione grafica semplificata dell'orientamento del dispositivo.
struct AttitudeIndicatorView: View {
    let roll: Double   // in radianti
    let pitch: Double  // in radianti

    var body: some View {
        GeometryReader { geo in
            let cx = geo.size.width / 2
            let cy = geo.size.height / 2
            let r  = min(cx, cy) * 0.85

            Canvas { ctx, size in
                // Sfondo cerchio
                ctx.fill(Path(ellipseIn: CGRect(x: cx - r, y: cy - r, width: r*2, height: r*2)),
                         with: .color(.blue.opacity(0.15)))

                // Linea roll (rotazione laterale)
                let rollAngle = roll
                let dx = cos(rollAngle) * r
                let dy = sin(rollAngle) * r
                var linePath = Path()
                linePath.move(to: CGPoint(x: cx - dx, y: cy - dy))
                linePath.addLine(to: CGPoint(x: cx + dx, y: cy + dy))
                ctx.stroke(linePath, with: .color(.red), lineWidth: 2)

                // Cerchio pitch (inclinazione avanti/indietro)
                let pitchOffset = pitch / (.pi / 2) * r * 0.6
                ctx.fill(Path(ellipseIn: CGRect(
                    x: cx - 6, y: cy - 6 - pitchOffset,
                    width: 12, height: 12
                )), with: .color(.green))
            }
        }
    }
}

// MARK: - Card disponibilità sensori

/// Card informativa che elenca la disponibilità di ogni sensore sul dispositivo.
struct SensorAvailabilityCard: View {
    let motionManager: MotionManager

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("Disponibilità Sensori", systemImage: "checklist")
                .font(.headline)
            Divider()
            availabilityRow("Pedometro",    motionManager.isPedometerAvailable)
            availabilityRow("Altimetro",    motionManager.isAltimeterAvailable)
            availabilityRow("Activity",     CMMotionActivityManager.isActivityAvailable())
            availabilityRow("Device Motion", CMMotionManager().isDeviceMotionAvailable)
        }
        .padding()
        .background(.regularMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .padding(.horizontal)
    }

    @ViewBuilder
    private func availabilityRow(_ name: String, _ available: Bool) -> some View {
        HStack {
            Text(name).foregroundStyle(.secondary)
            Spacer()
            Label(available ? "Disponibile" : "Non disponibile",
                  systemImage: available ? "checkmark.circle.fill" : "xmark.circle.fill")
            .foregroundStyle(available ? .green : .red)
            .font(.caption)
        }
    }
}
