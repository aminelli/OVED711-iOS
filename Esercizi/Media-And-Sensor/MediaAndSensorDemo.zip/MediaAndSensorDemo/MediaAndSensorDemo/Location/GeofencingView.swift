//
//  GeofencingView.swift
//  MediaAndSensorDemo
//
//  Interfaccia per il geofencing: aggiunta di regioni circolari, mappa
//  con visualizzazione delle regioni e lista con stato ingresso/uscita.
//

import SwiftUI
import CoreLocation
import MapKit

/// Vista per la gestione del geofencing tramite CLLocationManager.
/// Mostra una mappa con le regioni monitorate e permette di aggiungerne di nuove.
struct GeofencingView: View {

    @Bindable var locationManager: LocationManager
    @State private var showingAddRegion = false

    var body: some View {
        VStack(spacing: 0) {

            // Mappa con regioni e posizione utente
            GeofenceMapView(locationManager: locationManager)
                .frame(height: 280)

            // Lista delle regioni monitorate
            List {
                // Banner informativo se il permesso "sempre" non è stato concesso
                if locationManager.authorizationState != .always {
                    Section {
                        HStack(alignment: .top, spacing: 12) {
                            Image(systemName: "exclamationmark.triangle.fill")
                                .foregroundStyle(.orange)
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Permesso \"Sempre\" Consigliato")
                                    .font(.subheadline.bold())
                                Text("Il geofencing funziona anche con \"Durante l'uso\", " +
                                     "ma per notifiche in background serve \"Sempre\".")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        Button("Richiedi Autorizzazione \"Sempre\"") {
                            locationManager.requestAlwaysAuthorization()
                        }
                        .buttonStyle(.bordered)
                    }
                }

                // Regioni attive
                Section("Regioni Monitorate (\(locationManager.monitoredRegions.count))") {
                    if locationManager.monitoredRegions.isEmpty {
                        ContentUnavailableView(
                            "Nessuna Regione",
                            systemImage: "circle.dashed",
                            description: Text("Usa + per aggiungere una regione da monitorare")
                        )
                        .listRowBackground(Color.clear)
                    } else {
                        ForEach(locationManager.monitoredRegions) { region in
                            GeofenceRegionRow(region: region)
                        }
                        .onDelete { indexSet in
                            indexSet.forEach { i in
                                locationManager.removeGeofenceRegion(
                                    identifier: locationManager.monitoredRegions[i].id
                                )
                            }
                        }
                    }
                }

                // Pulsante rimozione totale
                if !locationManager.monitoredRegions.isEmpty {
                    Button("Rimuovi Tutte le Regioni", role: .destructive) {
                        locationManager.removeAllGeofences()
                    }
                }
            }
            .listStyle(.insetGrouped)
        }
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button { showingAddRegion = true } label: {
                    Image(systemName: "plus")
                }
            }
        }
        .sheet(isPresented: $showingAddRegion) {
            AddGeofenceSheet(locationManager: locationManager)
        }
    }
}

// MARK: - Mappa geofencing

/// Mappa che mostra la posizione dell'utente e le regioni di geofencing come cerchi.
struct GeofenceMapView: View {

    @Bindable var locationManager: LocationManager
    @State private var cameraPosition: MapCameraPosition = .automatic

    var body: some View {
        Map(position: $cameraPosition) {
            // Icona posizione utente
            UserAnnotation()

            // Disegna ogni regione come cerchio colorato
            ForEach(locationManager.monitoredRegions) { region in
                // Cerchio della regione (verde = dentro, blu = fuori)
                MapCircle(
                    center: region.center.coordinate,
                    radius: region.radius
                )
                .foregroundStyle(
                    region.isInside ? .green.opacity(0.25) : .blue.opacity(0.15)
                )
                .stroke(region.isInside ? .green : .blue, lineWidth: 2)

                // Segnaposto con il nome della regione
                Annotation(region.name, coordinate: region.center.coordinate) {
                    Image(systemName: region.isInside ? "checkmark.circle.fill" : "circle.dashed")
                        .font(.title3)
                        .foregroundStyle(region.isInside ? .green : .blue)
                        .background(.white.opacity(0.8))
                        .clipShape(Circle())
                }
            }
        }
        .mapStyle(.standard(elevation: .realistic))
        .mapControls {
            MapUserLocationButton()
            MapCompass()
            MapScaleView()
        }
        .onAppear {
            // Centra la mappa sulla posizione corrente all'apertura
            if let loc = locationManager.currentLocation {
                cameraPosition = .region(MKCoordinateRegion(
                    center: loc.coordinate,
                    latitudinalMeters: 2000,
                    longitudinalMeters: 2000
                ))
            }
        }
    }
}

// MARK: - Riga regione

/// Riga per una singola regione nella lista, con stato e coordinate.
struct GeofenceRegionRow: View {
    let region: GeofenceRegion

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: region.isInside ? "checkmark.circle.fill" : "circle.dashed")
                .font(.title2)
                .foregroundStyle(region.isInside ? .green : .blue)

            VStack(alignment: .leading, spacing: 3) {
                Text(region.name)
                    .font(.headline)
                Text("Raggio: \(Int(region.radius)) m")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text(String(format: "%.5f, %.5f",
                            region.center.coordinate.latitude,
                            region.center.coordinate.longitude))
                .font(.system(.caption2, design: .monospaced))
                .foregroundStyle(.secondary)
            }

            Spacer()

            // Etichetta stato (DENTRO / FUORI)
            Text(region.isInside ? "DENTRO" : "FUORI")
                .font(.caption2.bold())
                .foregroundStyle(region.isInside ? .green : .secondary)
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(region.isInside ? .green.opacity(0.12) : Color(.systemFill))
                .clipShape(Capsule())
        }
    }
}

// MARK: - Aggiunta regione

/// Sheet per la configurazione e aggiunta di una nuova regione di geofencing.
struct AddGeofenceSheet: View {

    @Bindable var locationManager: LocationManager
    @Environment(\.dismiss) private var dismiss

    @State private var regionName   = ""
    @State private var radiusText   = "200"
    @State private var useCurrentLocation = true
    @State private var latText      = ""
    @State private var lonText      = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("Nome Regione") {
                    TextField("Es. Casa, Ufficio, Palestra…", text: $regionName)
                }

                Section("Centro della Regione") {
                    Toggle("Usa la Posizione Corrente", isOn: $useCurrentLocation)

                    if useCurrentLocation {
                        if let loc = locationManager.currentLocation {
                            LabeledContent("Coordinate Rilevate") {
                                Text(String(format: "%.5f, %.5f",
                                            loc.coordinate.latitude,
                                            loc.coordinate.longitude))
                                .font(.system(.caption, design: .monospaced))
                            }
                        } else {
                            Label("Posizione non disponibile - avvia il tracking GPS",
                                  systemImage: "location.slash")
                            .foregroundStyle(.secondary)
                        }
                    } else {
                        LabeledContent("Latitudine") {
                            TextField("Es. 45.4642", text: $latText)
                                .keyboardType(.decimalPad)
                                .multilineTextAlignment(.trailing)
                        }
                        LabeledContent("Longitudine") {
                            TextField("Es. 9.1900", text: $lonText)
                                .keyboardType(.decimalPad)
                                .multilineTextAlignment(.trailing)
                        }
                    }
                }

                Section {
                    LabeledContent("Raggio (m)") {
                        TextField("200", text: $radiusText)
                            .keyboardType(.numberPad)
                            .multilineTextAlignment(.trailing)
                    }
                    Text("Il raggio massimo supportato dal sistema è " +
                         "\(Int(CLLocationManager().maximumRegionMonitoringDistance)) m.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                } header: {
                    Text("Raggio")
                }
            }
            .navigationTitle("Nuova Regione")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Annulla") { dismiss() }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Aggiungi") {
                        addRegion()
                        dismiss()
                    }
                    .disabled(!isFormValid)
                    .bold()
                }
            }
        }
    }

    private var isFormValid: Bool {
        guard !regionName.isEmpty, let r = Double(radiusText), r > 0 else { return false }
        if useCurrentLocation { return locationManager.currentLocation != nil }
        return Double(latText) != nil && Double(lonText) != nil
    }

    private func addRegion() {
        guard let radius = Double(radiusText) else { return }
        let coordinate: CLLocationCoordinate2D
        if useCurrentLocation, let loc = locationManager.currentLocation {
            coordinate = loc.coordinate
        } else {
            guard let lat = Double(latText), let lon = Double(lonText) else { return }
            coordinate = CLLocationCoordinate2D(latitude: lat, longitude: lon)
        }
        locationManager.addGeofenceRegion(
            coordinate: coordinate,
            radius: radius,
            identifier: UUID().uuidString,
            name: regionName
        )
    }
}
