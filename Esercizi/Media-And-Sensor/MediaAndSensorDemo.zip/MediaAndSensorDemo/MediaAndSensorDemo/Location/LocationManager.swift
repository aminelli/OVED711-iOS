//
//  LocationManager.swift
//  MediaAndSensorDemo
//
//  Gestisce il posizionamento GPS, il geocoding inverso e il geofencing
//  tramite CoreLocation. Usa il modello delegate classico con dispatch
//  su MainActor per la compatibilità Swift 6 strict concurrency.
//

import CoreLocation
import UIKit
import Observation

// MARK: - Tipi di supporto

/// Stato dell'autorizzazione alla localizzazione.
enum LocationAuthState {
    case notDetermined   // L'utente non ha ancora risposto alla richiesta
    case denied          // L'utente ha negato l'accesso
    case restricted      // Limitato da parental control / MDM aziendale
    case whenInUse       // Autorizzato solo durante l'uso attivo dell'app
    case always          // Autorizzato anche in background (richiesto per geofencing)
}

/// Rappresenta una regione circolare monitorata per il geofencing.
struct GeofenceRegion: Identifiable {
    let id: String                          // Identificatore univoco (usato da CLLocationManager)
    let center: CLLocation                  // Centro geografico della regione
    let radius: CLLocationDistance          // Raggio in metri
    let name: String                        // Nome descrittivo per l'utente
    var isInside: Bool = false              // Indica se il dispositivo è attualmente dentro
}

// MARK: - LocationManager

/// Manager osservabile per CoreLocation.
/// Gestisce tracking GPS continuo, geocoding inverso e geofencing.
@Observable
@MainActor
final class LocationManager: NSObject {

    // MARK: - Proprietà osservabili

    /// Ultima posizione rilevata dal GPS.
    var currentLocation: CLLocation?

    /// Indirizzo testuale derivato dal geocoding inverso.
    var currentAddress: String?

    /// Stato corrente dell'autorizzazione alla localizzazione.
    var authorizationState: LocationAuthState = .notDetermined

    /// Indica se il tracciamento continuo è attivo.
    var isTracking: Bool = false

    /// Storico delle posizioni rilevate nella sessione corrente.
    var locationHistory: [CLLocation] = []

    /// Regioni circolari monitorate per il geofencing.
    var monitoredRegions: [GeofenceRegion] = []

    /// Messaggio di errore corrente.
    var errorMessage: String?

    // MARK: - Componente CoreLocation

    private let locationManager = CLLocationManager()

    // MARK: - Inizializzazione

    override init() {
        super.init()
        locationManager.delegate = self
        // Massima precisione per il GPS (usa più batteria)
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        // Aggiorna solo se il dispositivo si è spostato di almeno 10 metri
        locationManager.distanceFilter = 10
        updateAuthState(locationManager.authorizationStatus)
    }

    // MARK: - Gestione permessi

    /// Richiede l'autorizzazione "durante l'uso" (sufficiente per tracking in foreground).
    func requestWhenInUseAuthorization() {
        locationManager.requestWhenInUseAuthorization()
    }

    /// Richiede l'autorizzazione "sempre" (necessaria per geofencing in background).
    /// Richiede prima .whenInUse; iOS mostrerà un secondo dialog per "sempre".
    func requestAlwaysAuthorization() {
        locationManager.requestAlwaysAuthorization()
    }

    /// Apre le Impostazioni dell'app per consentire all'utente di modificare i permessi.
    func openSettings() {
        guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
        UIApplication.shared.open(url)
    }

    // MARK: - Tracking GPS

    /// Avvia il tracciamento continuo della posizione.
    /// Richiede l'autorizzazione se non ancora concessa.
    func startTracking() {
        guard authorizationState == .whenInUse || authorizationState == .always else {
            requestWhenInUseAuthorization()
            return
        }
        locationHistory.removeAll()
        locationManager.startUpdatingLocation()
        isTracking = true
    }

    /// Ferma il tracciamento continuo.
    func stopTracking() {
        locationManager.stopUpdatingLocation()
        isTracking = false
    }

    /// Richiede una singola posizione (meno consumo batteria rispetto al tracking continuo).
    func requestSingleLocation() {
        guard authorizationState == .whenInUse || authorizationState == .always else {
            requestWhenInUseAuthorization()
            return
        }
        locationManager.requestLocation()
    }

    // MARK: - Geocoding inverso

    /// Converte le coordinate GPS in un indirizzo leggibile tramite CLGeocoder.
    /// - Parameter location: La posizione di cui si vuole l'indirizzo.
    func reverseGeocode(location: CLLocation) async {
        let geocoder = CLGeocoder()
        do {
            let placemarks = try await geocoder.reverseGeocodeLocation(location)
            guard let placemark = placemarks.first else { return }

            // Costruisce una stringa indirizzo dai componenti disponibili
            var parts: [String] = []
            if let street = placemark.thoroughfare {
                // Aggiunge il numero civico se disponibile
                if let number = placemark.subThoroughfare {
                    parts.append("\(street) \(number)")
                } else {
                    parts.append(street)
                }
            }
            if let city = placemark.locality         { parts.append(city) }
            if let country = placemark.country       { parts.append(country) }
            currentAddress = parts.joined(separator: ", ")
        } catch {
            print("[Location] Geocoding inverso fallito: \(error.localizedDescription)")
        }
    }

    // MARK: - Geofencing

    /// Aggiunge e avvia il monitoraggio di una regione circolare.
    /// - Parameters:
    ///   - coordinate: Centro della regione
    ///   - radius: Raggio in metri (verrà limitato al massimo supportato dal dispositivo)
    ///   - identifier: ID univoco della regione
    ///   - name: Nome descrittivo
    func addGeofenceRegion(
        coordinate: CLLocationCoordinate2D,
        radius: CLLocationDistance,
        identifier: String,
        name: String
    ) {
        guard CLLocationManager.isMonitoringAvailable(for: CLCircularRegion.self) else {
            errorMessage = "Il geofencing non è supportato su questo dispositivo"
            return
        }

        // Clamp del raggio al massimo consentito dal sistema
        let safeRadius = min(radius, locationManager.maximumRegionMonitoringDistance)

        let clRegion = CLCircularRegion(
            center: coordinate,
            radius: safeRadius,
            identifier: identifier
        )
        // Notifica sia all'ingresso che all'uscita dalla regione
        clRegion.notifyOnEntry = true
        clRegion.notifyOnExit  = true

        locationManager.startMonitoring(for: clRegion)

        monitoredRegions.append(GeofenceRegion(
            id: identifier,
            center: CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude),
            radius: safeRadius,
            name: name
        ))

        print("[Geofence] Monitoraggio avviato: \(name) - raggio: \(Int(safeRadius))m")
    }

    /// Rimuove una regione dal monitoraggio tramite il suo identificatore.
    func removeGeofenceRegion(identifier: String) {
        for region in locationManager.monitoredRegions where region.identifier == identifier {
            locationManager.stopMonitoring(for: region)
        }
        monitoredRegions.removeAll { $0.id == identifier }
    }

    /// Rimuove tutte le regioni monitorate.
    func removeAllGeofences() {
        locationManager.monitoredRegions.forEach { locationManager.stopMonitoring(for: $0) }
        monitoredRegions.removeAll()
    }

    // MARK: - Utilità privata

    /// Mappa CLAuthorizationStatus al tipo interno LocationAuthState.
    private func updateAuthState(_ status: CLAuthorizationStatus) {
        switch status {
        case .notDetermined:       authorizationState = .notDetermined
        case .denied:              authorizationState = .denied
        case .restricted:          authorizationState = .restricted
        case .authorizedWhenInUse: authorizationState = .whenInUse
        case .authorizedAlways:    authorizationState = .always
        @unknown default:          authorizationState = .notDetermined
        }
    }
}

// MARK: - CLLocationManagerDelegate

extension LocationManager: CLLocationManagerDelegate {

    /// Chiamato quando cambia lo stato dell'autorizzazione alla localizzazione.
    nonisolated func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        Task { @MainActor in
            updateAuthState(manager.authorizationStatus)
        }
    }

    /// Chiamato con aggiornamenti della posizione (continui o singola richiesta).
    nonisolated func locationManager(
        _ manager: CLLocationManager,
        didUpdateLocations locations: [CLLocation]
    ) {
        guard let location = locations.last else { return }
        Task { @MainActor in
            self.currentLocation = location

            // Aggiunge allo storico solo se ci si è spostati di almeno 5 m dall'ultima
            if let last = locationHistory.last, location.distance(from: last) < 5 { return }
            locationHistory.append(location)

            // Aggiorna l'indirizzo tramite geocoding inverso
            await reverseGeocode(location: location)
        }
    }

    /// Chiamato in caso di errore nella localizzazione.
    nonisolated func locationManager(
        _ manager: CLLocationManager,
        didFailWithError error: Error
    ) {
        Task { @MainActor in
            self.errorMessage = "Errore localizzazione: \(error.localizedDescription)"
        }
    }

    /// Chiamato quando il dispositivo entra nella regione monitorata.
    nonisolated func locationManager(
        _ manager: CLLocationManager,
        didEnterRegion region: CLRegion
    ) {
        print("[Geofence] Ingresso nella regione: \(region.identifier)")
        Task { @MainActor in
            if let i = monitoredRegions.firstIndex(where: { $0.id == region.identifier }) {
                monitoredRegions[i].isInside = true
            }
            // Invia notifica locale per l'evento di ingresso
            await NotificationManager.shared.sendGeofenceNotification(
                region: region.identifier,
                event: "Ingresso"
            )
        }
    }

    /// Chiamato quando il dispositivo esce dalla regione monitorata.
    nonisolated func locationManager(
        _ manager: CLLocationManager,
        didExitRegion region: CLRegion
    ) {
        print("[Geofence] Uscita dalla regione: \(region.identifier)")
        Task { @MainActor in
            if let i = monitoredRegions.firstIndex(where: { $0.id == region.identifier }) {
                monitoredRegions[i].isInside = false
            }
            await NotificationManager.shared.sendGeofenceNotification(
                region: region.identifier,
                event: "Uscita"
            )
        }
    }

    /// Chiamato se il monitoraggio di una regione fallisce.
    nonisolated func locationManager(
        _ manager: CLLocationManager,
        monitoringDidFailFor region: CLRegion?,
        withError error: Error
    ) {
        Task { @MainActor in
            self.errorMessage = "Errore geofencing: \(error.localizedDescription)"
        }
    }
}
