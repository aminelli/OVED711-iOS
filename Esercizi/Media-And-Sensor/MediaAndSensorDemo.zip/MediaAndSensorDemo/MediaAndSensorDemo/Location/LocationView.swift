//
//  LocationView.swift
//  MediaAndSensorDemo
//
//  Vista GPS che mostra la posizione corrente, l'indirizzo,
//  le coordinate dettagliate e lo storico delle posizioni rilevate.
//

import SwiftUI
import CoreLocation

/// Vista per visualizzare la posizione GPS in tempo reale.
/// Mostra coordinate, indirizzo (geocoding inverso), velocità e storico.
struct LocationView: View {

    @Bindable var locationManager: LocationManager

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {

                // Banner stato autorizzazione
                LocationAuthBanner(
                    state: locationManager.authorizationState,
                    onRequestWhenInUse: { locationManager.requestWhenInUseAuthorization() },
                    onOpenSettings:     { locationManager.openSettings() }
                )

                // Dati posizione corrente
                if let location = locationManager.currentLocation {
                    LocationDataCard(
                        location: location,
                        address: locationManager.currentAddress
                    )
                } else {
                    ContentUnavailableView(
                        "Nessuna Posizione",
                        systemImage: "location.slash",
                        description: Text("Avvia il tracciamento per ottenere la posizione GPS")
                    )
                    .frame(height: 160)
                }

                // Pulsanti avvio/arresto tracking
                HStack(spacing: 12) {
                    Button {
                        locationManager.isTracking
                            ? locationManager.stopTracking()
                            : locationManager.startTracking()
                    } label: {
                        Label(
                            locationManager.isTracking ? "Ferma" : "Tracciamento",
                            systemImage: locationManager.isTracking ? "stop.circle" : "location.circle"
                        )
                        .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(locationManager.isTracking ? .red : .blue)

                    // Posizione singola (meno consumo batteria)
                    Button {
                        locationManager.requestSingleLocation()
                    } label: {
                        Label("Singola", systemImage: "location")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                    .disabled(locationManager.authorizationState == .denied ||
                              locationManager.authorizationState == .notDetermined)
                }
                .padding(.horizontal)

                // Storico posizioni
                if !locationManager.locationHistory.isEmpty {
                    LocationHistoryCard(history: locationManager.locationHistory)
                }
            }
            .padding(.vertical)
        }
        .alert("Errore", isPresented: .constant(locationManager.errorMessage != nil)) {
            Button("OK") { locationManager.errorMessage = nil }
        } message: {
            Text(locationManager.errorMessage ?? "")
        }
    }
}

// MARK: - LocationFeatureView (Contenitore)

/// Vista contenitore per la sezione Localizzazione.
/// Condivide un'unica istanza di LocationManager tra GPS e Geofencing.
struct LocationFeatureView: View {

    /// Un'unica istanza condivisa di LocationManager tra i due tab.
    @State private var locationManager = LocationManager()
    @State private var selectedTab = 0

    var body: some View {
        NavigationStack {
            TabView(selection: $selectedTab) {
                LocationView(locationManager: locationManager)
                    .tabItem { Label("GPS", systemImage: "location.fill") }
                    .tag(0)

                GeofencingView(locationManager: locationManager)
                    .tabItem { Label("Geofence", systemImage: "circle.dashed") }
                    .tag(1)
            }
            .navigationTitle("Posizione & GPS")
            .navigationBarTitleDisplayMode(.inline)
        }
        .onAppear {
            locationManager.requestWhenInUseAuthorization()
        }
    }
}

// MARK: - Viste di supporto

/// Banner che mostra lo stato dell'autorizzazione e offre azioni contestuali.
struct LocationAuthBanner: View {
    let state: LocationAuthState
    let onRequestWhenInUse: () -> Void
    let onOpenSettings: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: iconName)
                .foregroundStyle(iconColor)
                .font(.title3)

            VStack(alignment: .leading, spacing: 2) {
                Text("Localizzazione")
                    .font(.subheadline.bold())
                Text(stateDescription)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            // Mostra azione contestuale in base allo stato
            switch state {
            case .notDetermined:
                Button("Richiedi", action: onRequestWhenInUse)
                    .buttonStyle(.borderedProminent)
                    .controlSize(.small)
            case .denied, .restricted:
                Button("Impostazioni", action: onOpenSettings)
                    .buttonStyle(.bordered)
                    .controlSize(.small)
            default:
                EmptyView()
            }
        }
        .padding()
        .background(.regularMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .padding(.horizontal)
    }

    private var iconName: String {
        switch state {
        case .notDetermined:       return "questionmark.circle"
        case .denied, .restricted: return "location.slash"
        case .whenInUse, .always:  return "location.fill"
        }
    }

    private var iconColor: Color {
        switch state {
        case .notDetermined:       return .orange
        case .denied, .restricted: return .red
        case .whenInUse, .always:  return .green
        }
    }

    private var stateDescription: String {
        switch state {
        case .notDetermined: return "Permesso non ancora richiesto"
        case .denied:        return "Accesso negato - modifica nelle Impostazioni"
        case .restricted:    return "Limitato da policy di sistema"
        case .whenInUse:     return "Autorizzato durante l'uso"
        case .always:        return "Autorizzato sempre (background)"
        }
    }
}

/// Card con tutti i dati della posizione corrente.
struct LocationDataCard: View {
    let location: CLLocation
    let address: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("Posizione Corrente", systemImage: "location.fill")
                .font(.headline)

            Divider()

            // Indirizzo geocodificato (se disponibile)
            if let address {
                HStack(alignment: .top) {
                    Image(systemName: "mappin.circle.fill")
                        .foregroundStyle(.red)
                    Text(address)
                        .font(.subheadline)
                        .textSelection(.enabled)
                }
            }

            // Griglia con tutte le misure
            Grid(alignment: .leading, horizontalSpacing: 16, verticalSpacing: 6) {
                dataRow(icon: "arrow.up.arrow.down", label: "Latitudine",
                        value: String(format: "%.6f°", location.coordinate.latitude))
                dataRow(icon: "arrow.left.arrow.right", label: "Longitudine",
                        value: String(format: "%.6f°", location.coordinate.longitude))
                dataRow(icon: "mountain.2", label: "Altitudine",
                        value: String(format: "%.1f m", location.altitude))
                dataRow(icon: "scope", label: "Precisione H",
                        value: String(format: "±%.1f m", location.horizontalAccuracy))
                dataRow(icon: "scope", label: "Precisione V",
                        value: String(format: "±%.1f m", location.verticalAccuracy))
                dataRow(icon: "gauge.with.dots.needle.67percent", label: "Velocità",
                        value: location.speed > 0
                            ? String(format: "%.1f km/h", location.speed * 3.6)
                            : "Ferma")
                if location.course >= 0 {
                    dataRow(icon: "compass.drawing", label: "Direzione",
                            value: String(format: "%.0f°", location.course))
                }
            }
        }
        .padding()
        .background(.regularMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .padding(.horizontal)
    }

    @ViewBuilder
    private func dataRow(icon: String, label: String, value: String) -> some View {
        GridRow {
            HStack(spacing: 4) {
                Image(systemName: icon).frame(width: 16)
                Text(label)
            }
            .foregroundStyle(.secondary)
            .font(.caption)

            Text(value)
                .font(.system(.caption, design: .monospaced))
                .textSelection(.enabled)
        }
    }
}

/// Card compatta con lo storico delle posizioni GPS.
struct LocationHistoryCard: View {
    let history: [CLLocation]

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Storico Posizioni (\(history.count))")
                .font(.headline)
                .padding(.horizontal)

            ForEach(history.indices.reversed().prefix(8), id: \.self) { i in
                let loc = history[i]
                HStack {
                    Text("#\(i + 1)")
                        .font(.caption2.monospaced())
                        .foregroundStyle(.secondary)
                        .frame(width: 28)

                    VStack(alignment: .leading, spacing: 1) {
                        Text(String(format: "%.5f, %.5f",
                                    loc.coordinate.latitude,
                                    loc.coordinate.longitude))
                        .font(.system(.caption, design: .monospaced))

                        Text(loc.timestamp.formatted(date: .omitted, time: .complete))
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }

                    Spacer()

                    // Distanza incrementale rispetto alla posizione precedente
                    if i > 0 {
                        let dist = loc.distance(from: history[i - 1])
                        Text("+\(Int(dist))m")
                            .font(.caption2.bold())
                            .foregroundStyle(.blue)
                    }
                }
                .padding(.horizontal)
                .padding(.vertical, 3)
            }
        }
        .padding(.vertical, 10)
        .background(.regularMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .padding(.horizontal)
    }
}
