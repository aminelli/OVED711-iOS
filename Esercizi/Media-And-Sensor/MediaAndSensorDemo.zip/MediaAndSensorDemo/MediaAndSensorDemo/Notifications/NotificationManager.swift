//
//  NotificationManager.swift
//  MediaAndSensorDemo
//
//  Manager singleton per le notifiche push locali e remote (APNs).
//  Gestisce:
//  - Richiesta dei permessi utente (alert, badge, suono)
//  - Pianificazione notifiche locali con trigger temporale e calendario
//  - Ricezione di notifiche in foreground (UNUserNotificationCenterDelegate)
//  - Gestione delle azioni interattive (categorie UNNotificationCategory)
//  - Registrazione e memorizzazione del token APNs
//

import UserNotifications
import UIKit
import Observation

// MARK: - Tipi di supporto

/// Livello di urgenza di una notifica (mappato su UNNotificationInterruptionLevel).
enum NotificationPriority: String, CaseIterable, Identifiable {
    var id: String { rawValue }
    case passive   = "Passiva"      // Non interrompe (solo in centro notifiche)
    case active    = "Normale"      // Mostra banner, suono standard
    case timeSensitive = "Urgente"  // Bypassa Focus mode temporaneamente
    case critical  = "Critica"      // Bypassa sempre (richiede approvazione Apple)
}

/// Record di una notifica programmata nella sessione corrente.
struct ScheduledRecord: Identifiable {
    let id = UUID()
    let identifier: String  // ID usato in UNNotificationRequest
    let title: String
    let body: String
    let scheduledFor: Date
}

// MARK: - NotificationManager

/// Manager singleton per UserNotifications e APNs.
/// È un @MainActor singleton perché AppDelegate vi accede su main thread.
@Observable
@MainActor
final class NotificationManager: NSObject {

    // MARK: - Singleton
    static let shared = NotificationManager()

    // MARK: - Proprietà osservabili

    /// Token del dispositivo per APNs (aggiornato da AppDelegate).
    var apnsDeviceToken: String?

    /// Stato autorizzazione notifiche di sistema.
    var authorizationStatus: UNAuthorizationStatus = .notDetermined

    /// true se l'utente ha autorizzato le notifiche.
    var isAuthorized: Bool { authorizationStatus == .authorized }

    /// Lista delle notifiche programmate e in attesa di consegna.
    var pendingRequests: [UNNotificationRequest] = []

    /// Registro delle notifiche pianificate nella sessione corrente.
    var scheduledRecords: [ScheduledRecord] = []

    /// Ultima notifica ricevuta mentre l'app era attiva.
    var lastReceivedNotification: UNNotification?

    // MARK: - Inizializzazione (privata — usa .shared)
    private override init() {
        super.init()
    }

    // MARK: - Permessi

    /// Richiede l'autorizzazione per alert, badge, suono e notifiche time-sensitive.
    /// Registra l'app per le notifiche remote (APNs) se autorizzata.
    func requestAuthorization() async {
        let center = UNUserNotificationCenter.current()
        do {
            let granted = try await center.requestAuthorization(options: [
                .alert,           // Mostra il banner
                .badge,           // Aggiorna il numero sull'icona
                .sound,           // Riproduce un suono
                .providesAppNotificationSettings  // Mostra link alle impostazioni in-app
            ])
            if granted {
                // Registra per notifiche remote (restituisce token in AppDelegate)
                await UIApplication.shared.registerForRemoteNotifications()
            }
            await refreshAuthorizationStatus()
        } catch {
            print("[Notifications] Errore richiesta autorizzazione: \(error.localizedDescription)")
        }
    }

    /// Aggiorna lo stato dell'autorizzazione leggendo le impostazioni correnti.
    func refreshAuthorizationStatus() async {
        let settings = await UNUserNotificationCenter.current().notificationSettings()
        authorizationStatus = settings.authorizationStatus
    }

    // MARK: - Categorie con azioni interattive

    /// Registra le categorie di notifica con pulsanti di azione interattivi.
    /// Deve essere chiamato al lancio dell'app (prima ricezione notifiche).
    func registerCategories() {
        // Azione "Visualizza" → porta l'app in foreground
        let viewAction = UNNotificationAction(
            identifier: "ACTION_VIEW",
            title: "Visualizza",
            options: [.foreground]
        )
        // Azione "Ignora" → rimuove la notifica (distruttiva)
        let ignoreAction = UNNotificationAction(
            identifier: "ACTION_IGNORE",
            title: "Ignora",
            options: [.destructive]
        )

        // Categoria generica con entrambe le azioni
        let generalCategory = UNNotificationCategory(
            identifier: "GENERAL",
            actions: [viewAction, ignoreAction],
            intentIdentifiers: [],
            options: [.customDismissAction]
        )

        // Categoria geofencing (solo "Visualizza")
        let geofenceCategory = UNNotificationCategory(
            identifier: "GEOFENCE",
            actions: [viewAction],
            intentIdentifiers: [],
            options: []
        )

        UNUserNotificationCenter.current().setNotificationCategories([
            generalCategory, geofenceCategory
        ])
    }

    // MARK: - Pianificazione notifiche locali

    /// Pianifica una notifica locale da consegnare dopo `delay` secondi.
    /// - Returns: Identificatore della notifica pianificata.
    @discardableResult
    func scheduleTimedNotification(
        title: String,
        body: String,
        delay: TimeInterval,
        priority: NotificationPriority = .active,
        identifier: String? = nil
    ) async -> String {
        let id = identifier ?? UUID().uuidString
        let content = buildContent(title: title, body: body, priority: priority, category: "GENERAL")
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: max(1, delay), repeats: false)
        let request = UNNotificationRequest(identifier: id, content: content, trigger: trigger)

        await addRequest(request)

        let record = ScheduledRecord(
            identifier: id,
            title: title,
            body: body,
            scheduledFor: Date().addingTimeInterval(delay)
        )
        scheduledRecords.insert(record, at: 0)
        return id
    }

    /// Pianifica una notifica locale per una data/ora specifica del calendario.
    func scheduleCalendarNotification(
        title: String,
        body: String,
        date: Date,
        priority: NotificationPriority = .active
    ) async {
        let id = UUID().uuidString
        let content = buildContent(title: title, body: body, priority: priority, category: "GENERAL")
        let comps = Calendar.current.dateComponents(
            [.year, .month, .day, .hour, .minute, .second], from: date
        )
        let trigger = UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)
        await addRequest(UNNotificationRequest(identifier: id, content: content, trigger: trigger))
    }

    /// Notifica dedicata agli eventi di geofencing (ingresso/uscita regione).
    func sendGeofenceNotification(region: String, event: String) async {
        let id = "geofence_\(region)_\(event)"
        let content = buildContent(
            title: "Geofence: \(event)",
            body: "\(event) rilevato nella regione: \(region)",
            priority: .timeSensitive,
            category: "GEOFENCE"
        )
        // Piccolo ritardo per evitare race condition con l'aggiornamento UI
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        await addRequest(UNNotificationRequest(identifier: id, content: content, trigger: trigger))
    }

    // MARK: - Gestione notifiche pendenti

    /// Ricarica la lista delle notifiche pendenti da UNUserNotificationCenter.
    func refreshPendingRequests() async {
        pendingRequests = await UNUserNotificationCenter.current().pendingNotificationRequests()
    }

    /// Annulla una specifica notifica pendente tramite il suo ID.
    func cancel(identifier: String) {
        UNUserNotificationCenter.current()
            .removePendingNotificationRequests(withIdentifiers: [identifier])
        pendingRequests.removeAll { $0.identifier == identifier }
        scheduledRecords.removeAll { $0.identifier == identifier }
    }

    /// Annulla tutte le notifiche pendenti.
    func cancelAll() {
        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
        pendingRequests.removeAll()
    }

    /// Azzera il badge numerico sull'icona dell'app.
    func clearBadge() {
        UNUserNotificationCenter.current().setBadgeCount(0)
    }

    // MARK: - Helper privati

    /// Costruisce un UNMutableNotificationContent configurato con priorità e categoria.
    private func buildContent(
        title: String,
        body: String,
        priority: NotificationPriority,
        category: String
    ) -> UNMutableNotificationContent {
        let content = UNMutableNotificationContent()
        content.title              = title
        content.body               = body
        content.categoryIdentifier = category
        // Suono e livello di interruzione in base alla priorità
        switch priority {
        case .passive:
            content.sound              = nil
            content.interruptionLevel  = .passive
        case .active:
            content.sound              = .default
            content.interruptionLevel  = .active
        case .timeSensitive:
            content.sound              = .default
            content.interruptionLevel  = .timeSensitive
        case .critical:
            content.sound              = .defaultCritical
            content.interruptionLevel  = .critical
        }
        return content
    }

    /// Aggiunge una richiesta al centro notifiche e aggiorna la lista pendenti.
    private func addRequest(_ request: UNNotificationRequest) async {
        do {
            try await UNUserNotificationCenter.current().add(request)
            await refreshPendingRequests()
        } catch {
            print("[Notifications] Errore aggiunta notifica: \(error.localizedDescription)")
        }
    }
}

// MARK: - UNUserNotificationCenterDelegate

extension NotificationManager: UNUserNotificationCenterDelegate {

    /// Chiamato quando una notifica viene consegnata mentre l'app è in foreground.
    /// Restituiamo .banner + .sound + .badge + .list per mostrare la notifica normalmente.
    nonisolated func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification,
        withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void
    ) {
        completionHandler([.banner, .sound, .badge, .list])
        Task { @MainActor in self.lastReceivedNotification = notification }
    }

    /// Chiamato quando l'utente interagisce con una notifica (tap o azione personalizzata).
    nonisolated func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        didReceive response: UNNotificationResponse,
        withCompletionHandler completionHandler: @escaping () -> Void
    ) {
        let actionID = response.actionIdentifier
        let title    = response.notification.request.content.title
        print("[Notifications] Azione '\(actionID)' su notifica: \(title)")
        Task { @MainActor in self.lastReceivedNotification = response.notification }
        completionHandler()
    }
}
