//
//  NotificationsView.swift
//  MediaAndSensorDemo
//
//  Interfaccia per testare notifiche locali, visualizzare lo stato APNs
//  e gestire le notifiche pendenti.
//

import SwiftUI
import UserNotifications

/// Vista principale per la sezione Notifiche Push.
/// Permette di richiedere permessi, inviare notifiche di test
/// e visualizzare token APNs e notifiche pendenti.
struct NotificationsView: View {

    @State private var manager = NotificationManager.shared

    // Parametri per la notifica rapida
    @State private var customTitle    = "Test Notifica"
    @State private var customBody     = "Questa è una notifica di test dall'app MediaSensorDemo"
    @State private var delaySeconds   = 5.0
    @State private var priority       = NotificationPriority.active

    // Parametri per la notifica schedulata
    @State private var scheduledDate  = Date().addingTimeInterval(120)

    var body: some View {
        NavigationStack {
            List {

                // --- Sezione stato permessi ---
                Section("Autorizzazione") {
                    AuthStatusRow(status: manager.authorizationStatus)
                    if !manager.isAuthorized {
                        Button("Richiedi Permesso Notifiche") {
                            Task { await manager.requestAuthorization() }
                        }
                        .buttonStyle(.borderedProminent)
                        .frame(maxWidth: .infinity)
                        .listRowBackground(Color.clear)
                    }
                }

                // --- Token APNs ---
                if let token = manager.apnsDeviceToken {
                    Section("Token APNs (Dispositivo Reale)") {
                        Text(token)
                            .font(.system(.caption2, design: .monospaced))
                            .textSelection(.enabled)
                        Button {
                            UIPasteboard.general.string = token
                        } label: {
                            Label("Copia Token", systemImage: "doc.on.doc")
                        }
                    }
                } else {
                    Section("APNs") {
                        Label(
                            "Token non disponibile (simulatore o permesso negato)",
                            systemImage: "exclamationmark.circle"
                        )
                        .foregroundStyle(.secondary)
                        .font(.caption)
                    }
                }

                // --- Notifica rapida ---
                Section("Invia Notifica di Test") {
                    TextField("Titolo", text: $customTitle)
                    TextField("Corpo del messaggio", text: $customBody, axis: .vertical)
                        .lineLimit(2...4)

                    LabeledContent("Ritardo") {
                        Stepper("\(Int(delaySeconds)) sec",
                                value: $delaySeconds, in: 1...60, step: 1)
                    }

                    Picker("Priorità", selection: $priority) {
                        ForEach(NotificationPriority.allCases) { p in
                            Text(p.rawValue).tag(p)
                        }
                    }

                    Button {
                        sendQuickNotification()
                    } label: {
                        Label("Invia tra \(Int(delaySeconds)) secondi", systemImage: "bell.badge")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(!manager.isAuthorized || customTitle.isEmpty)
                }

                // --- Notifica schedulata ---
                Section("Notifica Schedulata") {
                    DatePicker(
                        "Data e Ora",
                        selection: $scheduledDate,
                        in: Date()...,
                        displayedComponents: [.date, .hourAndMinute]
                    )
                    Button {
                        scheduleCalendarNotification()
                    } label: {
                        Label("Schedula", systemImage: "calendar.badge.clock")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                    .disabled(!manager.isAuthorized)
                }

                // --- Notifiche pendenti ---
                Section("In Attesa (\(manager.pendingRequests.count))") {
                    if manager.pendingRequests.isEmpty {
                        Text("Nessuna notifica in attesa")
                            .foregroundStyle(.secondary)
                            .italic()
                    } else {
                        ForEach(manager.pendingRequests, id: \.identifier) { req in
                            PendingNotificationRow(request: req)
                        }
                        .onDelete { indexSet in
                            indexSet.forEach { i in
                                manager.cancel(identifier: manager.pendingRequests[i].identifier)
                            }
                        }

                        Button("Cancella Tutte", role: .destructive) {
                            manager.cancelAll()
                        }
                    }
                }

                // --- Ultima notifica ricevuta ---
                if let last = manager.lastReceivedNotification {
                    Section("Ultima Ricevuta") {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(last.request.content.title).font(.subheadline.bold())
                            Text(last.request.content.body).font(.caption)
                            Text(last.date.formatted(date: .abbreviated, time: .complete))
                                .font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle("Notifiche Push")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        manager.clearBadge()
                    } label: {
                        Image(systemName: "bell.slash")
                    }
                }
            }
        }
        .task {
            await manager.refreshAuthorizationStatus()
            await manager.refreshPendingRequests()
            manager.registerCategories()
        }
    }

    // MARK: - Azioni

    private func sendQuickNotification() {
        Task {
            await manager.scheduleTimedNotification(
                title: customTitle,
                body: customBody,
                delay: delaySeconds,
                priority: priority
            )
        }
    }

    private func scheduleCalendarNotification() {
        Task {
            await manager.scheduleCalendarNotification(
                title: "Promemoria Schedulato",
                body: "Notifica programmata per \(scheduledDate.formatted())",
                date: scheduledDate,
                priority: priority
            )
        }
    }
}

// MARK: - Viste di supporto

/// Riga con lo stato corrente dell'autorizzazione.
struct AuthStatusRow: View {
    let status: UNAuthorizationStatus

    var body: some View {
        HStack {
            Image(systemName: statusIcon)
                .foregroundStyle(statusColor)
            VStack(alignment: .leading, spacing: 2) {
                Text("Stato Permesso")
                    .font(.subheadline.bold())
                Text(statusDescription)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
    }

    private var statusIcon: String {
        switch status {
        case .authorized:   return "checkmark.circle.fill"
        case .denied:       return "xmark.circle.fill"
        case .provisional:  return "exclamationmark.circle.fill"
        default:            return "questionmark.circle.fill"
        }
    }

    private var statusColor: Color {
        switch status {
        case .authorized:  return .green
        case .denied:      return .red
        case .provisional: return .orange
        default:           return .gray
        }
    }

    private var statusDescription: String {
        switch status {
        case .notDetermined: return "Non ancora richiesto"
        case .denied:        return "Negato dall'utente - modifica in Impostazioni"
        case .authorized:    return "Autorizzato"
        case .provisional:   return "Autorizzazione provvisoria (silenzioso)"
        case .ephemeral:     return "Effimero (App Clip)"
        @unknown default:    return "Stato sconosciuto"
        }
    }
}

/// Riga per una notifica pendente.
struct PendingNotificationRow: View {
    let request: UNNotificationRequest

    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(request.content.title)
                .font(.subheadline.bold())
            Text(request.content.body)
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(2)
            // Mostra il trigger in modo leggibile
            if let trigger = request.trigger as? UNTimeIntervalNotificationTrigger {
                Text("Tra \(Int(trigger.timeInterval)) secondi")
                    .font(.caption2.bold())
                    .foregroundStyle(.blue)
            } else if let trigger = request.trigger as? UNCalendarNotificationTrigger,
                      let nextDate = trigger.nextTriggerDate() {
                Text("Il \(nextDate.formatted(date: .abbreviated, time: .shortened))")
                    .font(.caption2.bold())
                    .foregroundStyle(.purple)
            }
        }
    }
}
