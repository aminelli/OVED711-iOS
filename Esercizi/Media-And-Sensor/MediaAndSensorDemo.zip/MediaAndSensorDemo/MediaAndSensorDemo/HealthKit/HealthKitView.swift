//
//  HealthKitView.swift
//  MediaAndSensorDemo
//
//  Interfaccia HealthKit: visualizza i dati sanitari giornalieri,
//  i campioni recenti di frequenza cardiaca e permette di registrare allenamenti.
//

import SwiftUI
import HealthKit

/// Vista principale per la sezione HealthKit.
struct HealthKitView: View {

    @State private var healthManager = HealthKitManager()
    @State private var showingWorkoutSheet = false

    var body: some View {
        NavigationStack {
            Group {
                // HealthKit non disponibile (iPad)
                if !healthManager.isAvailable {
                    ContentUnavailableView(
                        "Non Disponibile",
                        systemImage: "heart.slash",
                        description: Text("HealthKit è supportato solo su iPhone.")
                    )

                // Richiesta autorizzazione
                } else if !healthManager.isAuthorized {
                    HealthAuthRequestView {
                        Task { await healthManager.requestAuthorization() }
                    }

                // Dati sanitari
                } else {
                    ScrollView {
                        VStack(spacing: 16) {
                            DailySummaryGrid(healthManager: healthManager)
                            HeartRateListCard(samples: healthManager.heartRateSamples)
                        }
                        .padding(.vertical)
                    }
                    .refreshable {
                        await healthManager.loadAllData()
                    }
                }
            }
            .navigationTitle("HealthKit")
            .toolbar {
                if healthManager.isAuthorized {
                    ToolbarItem(placement: .topBarLeading) {
                        Button {
                            Task { await healthManager.loadAllData() }
                        } label: {
                            Image(systemName: "arrow.clockwise")
                        }
                    }
                    ToolbarItem(placement: .topBarTrailing) {
                        Button {
                            showingWorkoutSheet = true
                        } label: {
                            Image(systemName: "figure.walk.circle")
                        }
                    }
                }
            }
        }
        .sheet(isPresented: $showingWorkoutSheet) {
            SaveWorkoutSheet(healthManager: healthManager)
        }
        .alert("Errore HealthKit", isPresented: .constant(healthManager.errorMessage != nil)) {
            Button("OK") { healthManager.errorMessage = nil }
        } message: {
            Text(healthManager.errorMessage ?? "")
        }
        .task {
            if healthManager.isAvailable && !healthManager.isAuthorized {
                await healthManager.requestAuthorization()
            }
        }
    }
}

// MARK: - Schermata autorizzazione

/// Schermata mostrata prima che l'utente abbia autorizzato HealthKit.
struct HealthAuthRequestView: View {
    let onAuthorize: () -> Void

    var body: some View {
        VStack(spacing: 24) {
            Image(systemName: "heart.fill")
                .font(.system(size: 64))
                .foregroundStyle(.red)
                .symbolEffect(.bounce, options: .repeating)

            Text("Accesso a HealthKit")
                .font(.title.bold())

            VStack(alignment: .leading, spacing: 8) {
                HealthPermissionRow(icon: "figure.walk",   text: "Passi e distanza")
                HealthPermissionRow(icon: "heart.fill",    text: "Frequenza cardiaca")
                HealthPermissionRow(icon: "flame.fill",    text: "Calorie attive")
                HealthPermissionRow(icon: "figure.run",    text: "Allenamenti")
            }
            .padding()
            .background(.regularMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 12))

            Text("I dati rimangono privati sul dispositivo.")
                .font(.caption)
                .foregroundStyle(.secondary)

            Button("Autorizza HealthKit", action: onAuthorize)
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
        }
        .padding()
    }
}

/// Riga con icona e testo per elencare i permessi richiesti.
struct HealthPermissionRow: View {
    let icon: String
    let text: String

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(.red)
                .frame(width: 24)
            Text(text)
                .font(.subheadline)
        }
    }
}

// MARK: - Riassunto giornaliero

/// Griglia 2×2 con le metriche principali della giornata.
struct DailySummaryGrid: View {
    let healthManager: HealthKitManager

    private let columns = [GridItem(.flexible()), GridItem(.flexible())]

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Oggi")
                .font(.title2.bold())
                .padding(.horizontal)

            LazyVGrid(columns: columns, spacing: 12) {
                HealthMetricTile(
                    icon: "figure.walk",
                    value: "\(healthManager.todayStepCount)",
                    label: "Passi",
                    subtitle: "obiettivo: 10.000",
                    color: .green,
                    progress: Double(healthManager.todayStepCount) / 10_000
                )
                HealthMetricTile(
                    icon: "heart.fill",
                    value: healthManager.latestHeartRate.map { "\(Int($0))" } ?? "—",
                    label: "Freq. Cardiaca",
                    subtitle: "bpm",
                    color: .red,
                    progress: (healthManager.latestHeartRate ?? 0) / 200
                )
                HealthMetricTile(
                    icon: "figure.run",
                    value: String(format: "%.2f", healthManager.todayDistanceKm),
                    label: "Distanza",
                    subtitle: "km",
                    color: .blue,
                    progress: healthManager.todayDistanceKm / 10
                )
                HealthMetricTile(
                    icon: "flame.fill",
                    value: String(format: "%.0f", healthManager.todayActiveCalories),
                    label: "Calorie Attive",
                    subtitle: "kcal",
                    color: .orange,
                    progress: healthManager.todayActiveCalories / 500
                )
            }
            .padding(.horizontal)
        }
    }
}

/// Tile per una singola metrica con barra di avanzamento circolare.
struct HealthMetricTile: View {
    let icon: String
    let value: String
    let label: String
    let subtitle: String
    let color: Color
    let progress: Double  // 0.0 … 1.0

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(systemName: icon)
                    .foregroundStyle(color)
                    .font(.title3)
                Spacer()
                // Indicatore circolare di progressione
                ZStack {
                    Circle()
                        .stroke(color.opacity(0.2), lineWidth: 4)
                    Circle()
                        .trim(from: 0, to: min(progress, 1.0))
                        .stroke(color, style: StrokeStyle(lineWidth: 4, lineCap: .round))
                        .rotationEffect(.degrees(-90))
                        .animation(.easeOut, value: progress)
                }
                .frame(width: 28, height: 28)
            }

            Text(value)
                .font(.title2.bold())
                .foregroundStyle(color)

            Text(label)
                .font(.caption.bold())
                .foregroundStyle(.primary)

            Text(subtitle)
                .font(.caption2)
                .foregroundStyle(.tertiary)
        }
        .padding()
        .background(.regularMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }
}

// MARK: - Lista frequenza cardiaca

/// Card con i campioni recenti di frequenza cardiaca.
struct HeartRateListCard: View {
    let samples: [HealthSample]

    var body: some View {
        if !samples.isEmpty {
            VStack(alignment: .leading, spacing: 10) {
                Label("Freq. Cardiaca Recente", systemImage: "waveform.path.ecg")
                    .font(.headline)
                    .padding(.horizontal)

                ForEach(samples.prefix(8)) { s in
                    HStack {
                        Image(systemName: "heart.fill")
                            .foregroundStyle(.red)
                            .frame(width: 20)

                        Text("\(Int(s.value)) \(s.unit)")
                            .font(.system(.body, design: .monospaced).bold())

                        Spacer()

                        Text(s.date.formatted(date: .omitted, time: .shortened))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.horizontal)
                    .padding(.vertical, 4)
                }
            }
            .padding(.vertical, 12)
            .background(.regularMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 12))
            .padding(.horizontal)
        }
    }
}

// MARK: - Sheet allenamento

/// Sheet per registrare un allenamento di camminata su HealthKit.
struct SaveWorkoutSheet: View {
    let healthManager: HealthKitManager
    @Environment(\.dismiss) private var dismiss

    @State private var durationMinutes: Double = 30
    @State private var estimatedCalories: Double = 120
    @State private var isSaving = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Tipo di Allenamento") {
                    Label("Camminata all'Aperto", systemImage: "figure.walk")
                }

                Section("Durata") {
                    Slider(value: $durationMinutes, in: 5...180, step: 5)
                    Text("\(Int(durationMinutes)) minuti")
                        .font(.headline).foregroundStyle(.blue)
                }

                Section("Calorie Bruciate (stima)") {
                    Slider(value: $estimatedCalories, in: 30...1200, step: 10)
                    Text("\(Int(estimatedCalories)) kcal")
                        .font(.headline).foregroundStyle(.orange)
                }

                Section {
                    Text("L'allenamento sarà registrato come terminato ora " +
                         "con inizio \(Int(durationMinutes)) minuti fa.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Nuovo Allenamento")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Annulla") { dismiss() }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Salva") { saveWorkout() }
                        .bold()
                        .disabled(isSaving)
                }
            }
            .overlay {
                if isSaving {
                    ProgressView("Salvataggio in corso…")
                        .padding(24)
                        .background(.regularMaterial)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }
            }
        }
    }

    private func saveWorkout() {
        isSaving = true
        let end   = Date()
        let start = end.addingTimeInterval(-durationMinutes * 60)
        Task {
            await healthManager.saveWalkingWorkout(
                startDate: start,
                endDate: end,
                calories: estimatedCalories
            )
            isSaving = false
            dismiss()
        }
    }
}
