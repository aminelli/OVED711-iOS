//
//  HealthKitManager.swift
//  MediaAndSensorDemo
//
//  Gestisce l'accesso ai dati sanitari tramite HealthKit:
//  - Lettura: passi, frequenza cardiaca, distanza, calorie attive
//  - Scrittura: allenamenti (HKWorkoutBuilder)
//  - Gestione permessi con tipo-per-tipo per lettura e scrittura
//

import HealthKit
import Observation

// MARK: - Tipi di supporto

/// Campione di dati sanitari per la visualizzazione nell'interfaccia.
struct HealthSample: Identifiable {
    let id = UUID()
    let typeName: String   // Nome del tipo (es. "Frequenza Cardiaca")
    let value: Double      // Valore numerico
    let unit: String       // Unità di misura (es. "bpm", "passi")
    let date: Date         // Data/ora del campione
}

// MARK: - HealthKitManager

/// Manager per HealthKit. Richiede, legge e scrive dati sanitari.
/// Usa HKStatisticsQuery e HKSampleQuery con async/await tramite continuation.
@Observable
@MainActor
final class HealthKitManager {

    // MARK: - Proprietà osservabili

    /// HealthKit è disponibile su iPhone ma NON su iPad.
    var isAvailable: Bool = false

    /// Indica se l'autorizzazione per i tipi richiesti è stata concessa.
    var isAuthorized: Bool = false

    /// Passi totali nel giorno corrente.
    var todayStepCount: Int = 0

    /// Ultimo valore di frequenza cardiaca (bpm).
    var latestHeartRate: Double?

    /// Distanza totale percorsa oggi (km).
    var todayDistanceKm: Double = 0

    /// Calorie attive bruciate oggi (kcal).
    var todayActiveCalories: Double = 0

    /// Campioni recenti di frequenza cardiaca (ultime 24 ore).
    var heartRateSamples: [HealthSample] = []

    /// Messaggio di errore corrente.
    var errorMessage: String?

    // MARK: - Componente HealthKit

    private let store = HKHealthStore()

    /// Tipi di quantità da leggere (share = nil → sola lettura).
    private var readTypes: Set<HKObjectType> {
        let ids: [HKQuantityTypeIdentifier] = [
            .stepCount,
            .heartRate,
            .distanceWalkingRunning,
            .activeEnergyBurned
        ]
        var set: Set<HKObjectType> = Set(ids.compactMap { HKObjectType.quantityType(forIdentifier: $0) })
        set.insert(HKObjectType.workoutType())
        return set
    }

    /// Tipi che l'app può anche scrivere.
    private var writeTypes: Set<HKSampleType> {
        var set: Set<HKSampleType> = [HKObjectType.workoutType()]
        if let t = HKObjectType.quantityType(forIdentifier: .activeEnergyBurned) { set.insert(t) }
        return set
    }

    // MARK: - Inizializzazione

    init() {
        isAvailable = HKHealthStore.isHealthDataAvailable()
    }

    // MARK: - Permessi

    /// Mostra il dialog di sistema per autorizzare lettura e scrittura dei dati sanitari.
    func requestAuthorization() async {
        guard isAvailable else {
            errorMessage = "HealthKit non è disponibile su questo dispositivo (iPad non supportato)"
            return
        }
        do {
            // iOS mostrerà un dialog per ogni tipo non ancora autorizzato
            try await store.requestAuthorization(toShare: writeTypes, read: readTypes)
            isAuthorized = true
            await loadAllData()
        } catch {
            errorMessage = "Autorizzazione HealthKit negata: \(error.localizedDescription)"
        }
    }

    // MARK: - Caricamento dati

    /// Carica in parallelo tutti i dati giornalieri.
    func loadAllData() async {
        async let steps    = fetchTodaySum(typeId: .stepCount,                 unit: .count())
        async let distance = fetchTodaySum(typeId: .distanceWalkingRunning,    unit: .meter())
        async let calories = fetchTodaySum(typeId: .activeEnergyBurned,        unit: .kilocalorie())
        async let hr       = fetchLatestSample(typeId: .heartRate,             unit: HKUnit(from: "count/min"))
        async let hrList   = fetchRecentSamples(typeId: .heartRate,            unit: HKUnit(from: "count/min"), limit: 20)

        todayStepCount        = Int(await steps    ?? 0)
        todayDistanceKm       = (await distance    ?? 0) / 1000
        todayActiveCalories   = await calories     ?? 0
        latestHeartRate       = await hr
        heartRateSamples      = (await hrList).map {
            HealthSample(typeName: "Freq. Cardiaca", value: $0.value,
                         unit: "bpm", date: $0.date)
        }
    }

    // MARK: - Query private

    /// Recupera la somma cumulativa di un tipo di quantità per il giorno corrente.
    private func fetchTodaySum(
        typeId: HKQuantityTypeIdentifier,
        unit: HKUnit
    ) async -> Double? {
        guard let type = HKQuantityType.quantityType(forIdentifier: typeId) else { return nil }
        let start = Calendar.current.startOfDay(for: Date())
        let predicate = HKQuery.predicateForSamples(
            withStart: start, end: Date(), options: .strictStartDate
        )
        return await withCheckedContinuation { cont in
            let q = HKStatisticsQuery(
                quantityType: type,
                quantitySamplePredicate: predicate,
                options: .cumulativeSum
            ) { _, result, _ in
                cont.resume(returning: result?.sumQuantity()?.doubleValue(for: unit))
            }
            store.execute(q)
        }
    }

    /// Recupera l'ultimo campione di un tipo (ordinato per data decrescente).
    private func fetchLatestSample(
        typeId: HKQuantityTypeIdentifier,
        unit: HKUnit
    ) async -> Double? {
        guard let type = HKQuantityType.quantityType(forIdentifier: typeId) else { return nil }
        // Finestra temporale: ultima ora
        let predicate = HKQuery.predicateForSamples(
            withStart: Date().addingTimeInterval(-3600), end: Date()
        )
        let sort = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)
        return await withCheckedContinuation { cont in
            let q = HKSampleQuery(
                sampleType: type, predicate: predicate,
                limit: 1, sortDescriptors: [sort]
            ) { _, samples, _ in
                let value = (samples?.first as? HKQuantitySample)?.quantity.doubleValue(for: unit)
                cont.resume(returning: value)
            }
            store.execute(q)
        }
    }

    /// Struttura ausiliaria interna per i risultati dei campioni.
    private struct RawSample { var value: Double; var date: Date }

    /// Recupera gli ultimi `limit` campioni delle ultime 24 ore.
    private func fetchRecentSamples(
        typeId: HKQuantityTypeIdentifier,
        unit: HKUnit,
        limit: Int
    ) async -> [RawSample] {
        guard let type = HKQuantityType.quantityType(forIdentifier: typeId) else { return [] }
        let predicate = HKQuery.predicateForSamples(
            withStart: Date().addingTimeInterval(-86400), end: Date()
        )
        let sort = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)
        return await withCheckedContinuation { cont in
            let q = HKSampleQuery(
                sampleType: type, predicate: predicate,
                limit: limit, sortDescriptors: [sort]
            ) { _, samples, _ in
                let result = (samples as? [HKQuantitySample])?.map {
                    RawSample(value: $0.quantity.doubleValue(for: unit), date: $0.endDate)
                } ?? []
                cont.resume(returning: result)
            }
            store.execute(q)
        }
    }

    // MARK: - Scrittura allenamento

    /// Salva un allenamento di camminata su HealthKit tramite HKWorkoutBuilder.
    /// - Parameters:
    ///   - startDate: Inizio dell'allenamento
    ///   - endDate:   Fine dell'allenamento
    ///   - calories:  Calorie attive bruciate (opzionale)
    func saveWalkingWorkout(
        startDate: Date,
        endDate: Date,
        calories: Double? = nil
    ) async {
        let config = HKWorkoutConfiguration()
        config.activityType  = .walking
        config.locationType  = .outdoor

        let builder = HKWorkoutBuilder(
            healthStore: store,
            configuration: config,
            device: .local()
        )
        do {
            try await builder.beginCollection(at: startDate)

            // Aggiunge il campione calorie se fornito
            if let kcal = calories,
               let calorieType = HKQuantityType.quantityType(forIdentifier: .activeEnergyBurned) {
                let qty = HKQuantity(unit: .kilocalorie(), doubleValue: kcal)
                let sample = HKQuantitySample(
                    type: calorieType, quantity: qty,
                    start: startDate, end: endDate
                )
                try await builder.addSamples([sample])
            }

            try await builder.endCollection(at: endDate)
            try await builder.finishWorkout()

            print("[HealthKit] Allenamento salvato con successo")
            // Ricarica i dati per riflettere il nuovo allenamento
            await loadAllData()
        } catch {
            errorMessage = "Errore salvataggio allenamento: \(error.localizedDescription)"
        }
    }
}
