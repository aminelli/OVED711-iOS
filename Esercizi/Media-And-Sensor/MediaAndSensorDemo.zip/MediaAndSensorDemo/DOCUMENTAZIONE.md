# MediaAndSensorDemo — Documentazione Tecnica

> **Versione:** 1.0 · **Piattaforma:** iOS 26+ · **Linguaggio:** Swift 6.3 · **IDE:** Xcode 26

---

## Indice

1. [Panoramica del Progetto](#panoramica)
2. [Struttura del Progetto](#struttura)
3. [Configurazione e Prerequisiti](#configurazione)
4. [Camera e AVFoundation](#camera)
5. [CoreLocation e GPS](#location)
6. [Sensori di Movimento (CoreMotion)](#motion)
7. [HealthKit](#healthkit)
8. [Push Notifications (APNs)](#notifications)
9. [Architettura e Pattern Swift 6](#architettura)
10. [Privacy e Sicurezza](#privacy)

---

## 1. Panoramica del Progetto {#panoramica}

**MediaAndSensorDemo** è un'applicazione iOS dimostrativa che mostra l'uso avanzato dei principali framework hardware e di sistema di Apple. L'app è organizzata in cinque sezioni accessibili tramite una `TabView` principale:

| Tab | Framework | Funzionalità |
|-----|-----------|--------------|
| Camera | AVFoundation | Foto, Video, QR/Barcode |
| Location | CoreLocation | GPS, Geocoding, Geofencing |
| Motion | CoreMotion | Accelerometro, Giroscopio, Pedometro |
| Health | HealthKit | Lettura/scrittura dati sanitari |
| Notifications | UserNotifications | Notifiche locali e APNs |

---

## 2. Struttura del Progetto {#struttura}

```
MediaAndSensorDemo/
├── MediaAndSensorDemoApp.swift    # Entrypoint, @UIApplicationDelegateAdaptor
├── AppDelegate.swift              # Gestione APNs, ciclo di vita UIKit
├── ContentView.swift              # TabView radice
├── Info.plist                     # Chiavi privacy, background modes
│
├── Camera/
│   ├── CameraManager.swift        # @Observable, sessione AVCapture
│   ├── CameraPreviewView.swift    # UIViewRepresentable per AVPreviewLayer
│   ├── CameraFeatureView.swift    # Contenitore tab Camera
│   ├── PhotoCaptureView.swift     # Scatto foto
│   ├── VideoRecordingView.swift   # Registrazione video + AVPlayer
│   └── BarcodeScannerView.swift   # Scanner QR/barcode + mirino
│
├── Location/
│   ├── LocationManager.swift      # @Observable, CLLocationManager delegate
│   ├── LocationView.swift         # GPS + storico + LocationFeatureView
│   └── GeofencingView.swift       # Mappa + regioni + AddGeofenceSheet
│
├── Motion/
│   ├── MotionManager.swift        # @Observable, CMMotionManager + altimetro
│   └── MotionView.swift           # Visualizzazione live di tutti i sensori
│
├── HealthKit/
│   ├── HealthKitManager.swift     # @Observable, HKHealthStore
│   └── HealthKitView.swift        # Dashboard salute + SaveWorkoutSheet
│
└── Notifications/
    ├── NotificationManager.swift  # @Observable singleton, UNUserNotificationCenter
    └── NotificationsView.swift    # UI test notifiche + lista pendenti
```

---

## 3. Configurazione e Prerequisiti {#configurazione}

### 3.1 Entitlements richiesti

Prima di compilare aprire **Xcode → Target → Signing & Capabilities** e aggiungere:

| Capability | Motivo |
|------------|--------|
| **HealthKit** | Accesso a HKHealthStore |
| **Push Notifications** | Registrazione APNs |
| **Background Modes** → *Location updates* | Geofencing in background |
| **Background Modes** → *Remote notifications* | Content-available push |

### 3.2 Aggiunta file al progetto Xcode

I file sono organizzati in cartelle su disco. In Xcode 26:
1. Selezionare il gruppo `MediaAndSensorDemo` nel navigator
2. `File → Add Files to "MediaAndSensorDemo"…`
3. Selezionare le cartelle `Camera/`, `Location/`, `Motion/`, `HealthKit/`, `Notifications/`
4. Assicurarsi che **"Create groups"** sia selezionato e il target sia spuntato

### 3.3 Info.plist

Il file `Info.plist` incluso contiene già tutte le chiavi privacy necessarie (`NSCameraUsageDescription`, `NSLocationWhenInUseUsageDescription`, ecc.). Verificare che **IPHONEOS_DEPLOYMENT_TARGET = 26.0** nelle Build Settings del target.

### 3.4 Swift 6 Strict Concurrency

Il progetto è scritto per Swift 6 con strict concurrency checking abilitato. Nelle Build Settings verificare:
```
SWIFT_STRICT_CONCURRENCY = complete
```

---

## 4. Camera e AVFoundation {#camera}

### 4.1 CameraManager

`CameraManager` è la classe centrale per AVFoundation. È marcata `@Observable @MainActor` per l'integrazione SwiftUI, e usa `nonisolated(unsafe)` per gli oggetti AVFoundation che devono essere accessibili dalla `sessionQueue`:

```swift
@Observable @MainActor
final class CameraManager: NSObject {
    nonisolated(unsafe) let captureSession = AVCaptureSession()
    nonisolated(unsafe) private let photoOutput = AVCapturePhotoOutput()
    private let sessionQueue = DispatchQueue(label: "...")
}
```

**Perché `nonisolated(unsafe)`?**  
In Swift 6, le proprietà di una classe `@MainActor` sono implicitamente isolate al main actor. Poiché `AVCaptureSession` deve essere configurata e avviata su una coda background dedicata (best practice Apple), `nonisolated(unsafe)` dice al compilatore che la thread safety è gestita manualmente tramite `sessionQueue`.

### 4.2 Flusso di permessi

```
requestPermissions()
  ├── AVCaptureDevice.requestAccess(.video)  → cameraAuthorized
  ├── AVCaptureDevice.requestAccess(.audio)  → microphoneAuthorized
  └── se cameraAuthorized → configureSession()
                              ├── addVideoInput()   (sessionQueue)
                              ├── addAudioInput()   (sessionQueue)
                              └── addOutputs()      (sessionQueue)
```

### 4.3 Scatto foto

`capturePhoto()` crea un `AVCapturePhotoSettings` con codec HEVC (se disponibile) e flash automatico. Il risultato arriva nel delegate `AVCapturePhotoCaptureDelegate.photoOutput(_:didFinishProcessingPhoto:)` che aggiorna `capturedPhoto` via `Task { @MainActor in ... }`.

### 4.4 Registrazione video

`startVideoRecording()` avvia la scrittura su un file `.mov` nella cartella Documenti. L'URL del file completato è disponibile in `recordedVideoURL`. Il playback usa `AVPlayer` tramite `AVKit.VideoPlayer`.

### 4.5 Scanner QR / Barcode

L'output `AVCaptureMetadataOutput` è configurato per riconoscere 10 formati di codici:

| Formato | Utilizzo tipico |
|---------|----------------|
| `.qr` | URL, contatti vCard, Wi-Fi |
| `.ean13` / `.ean8` | Prodotti europei |
| `.code128` | Logistica, magazzino |
| `.code39` | Settore sanitario |
| `.pdf417` | Documenti identità, biglietti |
| `.aztec` | Biglietti di trasporto |
| `.dataMatrix` | Industria, PCB |

Il delegate `AVCaptureMetadataOutputObjectsDelegate` filtra i duplicati e fornisce feedback aptico (`UINotificationFeedbackGenerator`) ad ogni nuovo codice rilevato.

---

## 5. CoreLocation e GPS {#location}

### 5.1 LocationManager

```swift
@Observable @MainActor
final class LocationManager: NSObject, CLLocationManagerDelegate {
    private let locationManager = CLLocationManager()
}
```

I metodi delegate di `CLLocationManager` sono `nonisolated` e aggiornano le proprietà tramite `Task { @MainActor in ... }`.

### 5.2 Livelli di autorizzazione

| Stato | Uso |
|-------|-----|
| `.authorizedWhenInUse` | Tracking GPS in foreground, posizione singola |
| `.authorizedAlways` | Geofencing in background, tracking background |

> ⚠️ Per il geofencing iOS richiede `.authorizedAlways`. Il sistema mostra prima un dialog `.whenInUse`, poi un secondo dialog per la promozione ad "Sempre".

### 5.3 Geofencing

Il geofencing usa `CLCircularRegion` monitorata da `CLLocationManager.startMonitoring(for:)`. Ogni regione:
- Ha un raggio limitato a `locationManager.maximumRegionMonitoringDistance`
- Notifica su ingresso (`notifyOnEntry = true`) e uscita (`notifyOnExit = true`)
- Invia una notifica locale tramite `NotificationManager.sendGeofenceNotification()`

**Limite di sistema:** iOS supporta al massimo **20 regioni** monitorate per app simultaneamente.

### 5.4 Geocoding inverso

`CLGeocoder.reverseGeocodeLocation(_:)` è una API `async throws` (iOS 15+) che restituisce un array di `CLPlacemark`. L'app estrae via/civico, città e paese per costruire una stringa indirizzo leggibile.

---

## 6. Sensori di Movimento (CoreMotion) {#motion}

### 6.1 Sensori supportati

| Sensore | API | Frequenza | Unità |
|---------|-----|-----------|-------|
| Accelerometro | `CMMotionManager.startAccelerometerUpdates` | 60 Hz | g (9.81 m/s²) |
| Giroscopio | `CMMotionManager.startGyroUpdates` | 60 Hz | rad/s |
| Magnetometro | `CMMotionManager.startMagnetometerUpdates` | 20 Hz | µT |
| Device Motion | `startDeviceMotionUpdates(using:)` | 30 Hz | quaternione/eulero |
| Altimetro | `CMAltimeter.startRelativeAltitudeUpdates` | continuo | m, kPa |
| Activity | `CMMotionActivityManager.startActivityUpdates` | eventi | enum |
| Pedometro | `CMPedometer.startUpdates(from:)` | continuo | passi, m |

### 6.2 Device Motion vs sensori raw

`CMDeviceMotion` combina i tre sensori con un filtro Kalman per eliminare deriva e rumore. Fornisce:
- **attitude** (roll, pitch, yaw) in radianti
- **gravity** e **userAcceleration** separati
- **magneticField** calibrato

Il reference frame `xMagneticNorthZVertical` allinea l'asse X al Nord magnetico e Z alla verticale.

### 6.3 Activity Recognition

`CMMotionActivityManager` usa un modello CoreML interno per classificare l'attività fisica in tempo reale: `stationary`, `walking`, `running`, `automotive`, `cycling`. Non richiede permessi espliciti su iOS 26.

---

## 7. HealthKit {#healthkit}

### 7.1 Disponibilità

HealthKit è **disponibile solo su iPhone**. Su iPad `HKHealthStore.isHealthDataAvailable()` restituisce `false`. L'app gestisce questo caso mostrando `ContentUnavailableView`.

### 7.2 Permessi granulari

iOS mostra un singolo dialog con la lista dei tipi richiesti. L'utente può autorizzare/negare ogni tipo individualmente. L'app richiede:

**Lettura:**
- `HKQuantityTypeIdentifier.stepCount`
- `HKQuantityTypeIdentifier.heartRate`
- `HKQuantityTypeIdentifier.distanceWalkingRunning`
- `HKQuantityTypeIdentifier.activeEnergyBurned`
- `HKObjectType.workoutType()`

**Scrittura:**
- `HKObjectType.workoutType()`
- `HKQuantityTypeIdentifier.activeEnergyBurned`

### 7.3 Query

| Query | Uso |
|-------|-----|
| `HKStatisticsQuery` | Somma cumulativa del giorno (passi, calorie, distanza) |
| `HKSampleQuery` | Ultimi N campioni (frequenza cardiaca) |
| `HKWorkoutBuilder` | Scrittura allenamenti strutturati |

Tutte le query sono wrappate in `withCheckedContinuation` per compatibilità con `async/await`.

### 7.4 Scrittura allenamento

`HKWorkoutBuilder` (iOS 16+) supporta il builder pattern async:
```swift
try await builder.beginCollection(at: startDate)
try await builder.addSamples([calorieSample])
try await builder.endCollection(at: endDate)
try await builder.finishWorkout()
```

---

## 8. Push Notifications (APNs) {#notifications}

### 8.1 Architettura

```
App → UIApplication.registerForRemoteNotifications()
   → Apple APNs Server
   → AppDelegate.application(_:didRegisterForRemoteNotificationsWithDeviceToken:)
   → NotificationManager.shared.apnsDeviceToken = tokenString
```

Il **device token** (32 byte, rappresentato come stringa esadecimale da 64 caratteri) identifica univocamente il dispositivo sull'infrastruttura APNs. Il backend dell'app deve salvare questo token per inviare notifiche push.

### 8.2 NotificationManager (Singleton)

`NotificationManager.shared` è un singleton `@MainActor` accessibile da:
- `AppDelegate` (aggiornamento token APNs)
- `LocationManager` (notifiche geofencing)
- `NotificationsView` (UI test)

### 8.3 Livelli di interruzione (iOS 15+)

| Livello | Enum | Comportamento |
|---------|------|---------------|
| Passive | `.passive` | Solo nel centro notifiche, nessun banner |
| Active | `.active` | Banner + suono standard |
| Time-Sensitive | `.timeSensitive` | Bypassa Focus mode temporaneamente |
| Critical | `.critical` | Bypassa sempre (richiede approvazione Apple) |

### 8.4 Azioni interattive

L'app registra due categorie di notifica:

**GENERAL** (notifiche generali):
- "Visualizza" → porta l'app in foreground (`.foreground`)
- "Ignora" → rimuove la notifica (`.destructive`)

**GEOFENCE** (eventi geofencing):
- "Visualizza" → porta l'app in foreground

### 8.5 Test su simulatore

Il simulatore **non supporta le notifiche push remote**. Per testare APNs usare un dispositivo fisico con profilo di provisioning che include la capability "Push Notifications". Le notifiche **locali** funzionano normalmente sul simulatore.

---

## 9. Architettura e Pattern Swift 6 {#architettura}

### 9.1 @Observable vs ObservableObject

Il progetto usa il macro `@Observable` (Swift 5.9 / iOS 17+) anziché `ObservableObject + @Published`. Vantaggi:
- Nessuna necessità di `@StateObject` / `@ObservedObject` — usa `@State`
- Tracciamento granulare: SwiftUI ridisegna solo le view che leggono proprietà modificate
- Supporto per `@Bindable` per binding bidirezionali

```swift
// Dichiarazione
@Observable @MainActor
final class MyManager { var value = 0 }

// Uso in SwiftUI
struct MyView: View {
    @State private var manager = MyManager()  // proprietà del lifecycle della view
    var body: some View { Text("\(manager.value)") }
}

// Binding bidirezionale su tipi reference
struct ChildView: View {
    @Bindable var manager: MyManager
}
```

### 9.2 Thread safety con @MainActor

Tutte le classi manager sono `@MainActor` per garantire che le proprietà osservabili vengano aggiornate sempre sul thread principale (richiesto da SwiftUI).

I callback su thread background (delegate AVFoundation, CoreMotion, CoreLocation) usano:
```swift
Task { @MainActor in
    self.propertyName = newValue
}
```

### 9.3 nonisolated(unsafe)

Per gli oggetti AVFoundation che devono essere accessibili dalla `sessionQueue` senza violare strict concurrency:
```swift
nonisolated(unsafe) let captureSession = AVCaptureSession()
```
La parola chiave `nonisolated(unsafe)` (Swift 5.10+) indica che la thread safety è garantita manualmente.

### 9.4 Dependency Injection via @Bindable

`LocationFeatureView` crea una singola istanza di `LocationManager` e la passa alle view figlie tramite `@Bindable`, evitando di creare più istanze con `CLLocationManager` duplicati:

```swift
struct LocationFeatureView: View {
    @State private var locationManager = LocationManager()  // istanza unica

    var body: some View {
        TabView {
            LocationView(locationManager: locationManager)   // @Bindable
            GeofencingView(locationManager: locationManager) // @Bindable
        }
    }
}
```

---

## 10. Privacy e Sicurezza {#privacy}

### 10.1 Principio del minimo privilegio

L'app richiede i permessi solo quando necessari:
- La fotocamera viene richiesta all'apertura del tab Camera
- La localizzazione viene richiesta solo quando si tenta di avviare il tracking
- HealthKit viene richiesto solo aprendo il tab Health

### 10.2 Dati locali

- **Foto e video** vengono salvati nella cartella Documenti dell'app (sandbox) o nella libreria foto (con consenso esplicito)
- **Dati HealthKit** rimangono nel database locale di Health.app
- **Token APNs** non viene persistito — viene re-richiesto ad ogni avvio

### 10.3 Nessuna trasmissione dati

L'app non trasmette dati a server remoti. Il token APNs viene solo mostrato nell'interfaccia per scopi dimostrativi — in una app di produzione va inviato al proprio backend HTTPS.

### 10.4 App Transport Security

Tutte le comunicazioni di rete (non presenti in questa demo) devono usare HTTPS. Non aggiungere chiavi `NSAppTransportSecurity` per disabilitare ATS senza valida ragione.

---

## Note di Sviluppo

### Esecuzione su Simulatore

| Feature | Simulatore | Dispositivo Fisico |
|---------|------------|-------------------|
| Foto/Video | ✅ (camera simulata) | ✅ |
| Barcode/QR | ⚠️ (usa immagini statiche) | ✅ |
| GPS | ✅ (posizione simulata) | ✅ |
| Geofencing | ⚠️ (limitato) | ✅ |
| Accelerometro | ❌ | ✅ |
| Barometro | ❌ | ✅ (iPhone 6+) |
| Activity Recognition | ❌ | ✅ |
| HealthKit | ✅ | ✅ |
| Notifiche Locali | ✅ | ✅ |
| APNs (Remote Push) | ❌ | ✅ |

### Requisiti di Build

- **Xcode:** 26.0 o superiore
- **iOS Deployment Target:** 26.0
- **Swift:** 6.3
- **Entitlements:** HealthKit, Push Notifications (vedi §3.1)

---

*Documentazione generata per MediaAndSensorDemo v1.0 — Giugno 2026*
