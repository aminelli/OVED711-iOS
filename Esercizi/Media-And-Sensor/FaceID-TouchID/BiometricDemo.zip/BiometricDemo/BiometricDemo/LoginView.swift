//
//  LoginView.swift
//  BiometricDemo
//
//  Created by Antonio Minelli on 22/06/2026.
//
//  Schermata di login con autenticazione biometrica.
//  Supporta Face ID, Touch ID e Optic ID con feedback visivo completo.
//

import SwiftUI

/// Vista di login che presenta il pulsante per l'autenticazione biometrica.
///
/// Caratteristiche:
/// - Rilevamento automatico del tipo biometrico disponibile
/// - Animazione dell'icona biometrica con effetto pulse
/// - Avvio automatico dell'autenticazione all'apertura (con ritardo 500ms)
/// - Gestione degli errori tramite Alert nativo del sistema
/// - Indicatore visivo dello stato della biometria (disponibile / non disponibile)
struct LoginView: View {

    // MARK: - ViewModel dall'ambiente SwiftUI

    /// Accede al ViewModel iniettato nell'ambiente da `BiometricDemoApp`.
    /// Usando `@Environment` invece di `@EnvironmentObject` per compatibilità con `@Observable`.
    @Environment(AuthViewModel.self) private var viewModel

    // MARK: - Stato locale della vista

    /// Controlla l'animazione dell'anello pulsante attorno all'icona biometrica
    @State private var isPulsing: Bool = false

    /// Controlla la visibilità dell'Alert di errore
    @State private var showErrorAlert: Bool = false

    // MARK: - Corpo della vista

    var body: some View {
        ZStack {
            // Sfondo scuro con gradiente — occupa tutto lo schermo
            backgroundView

            VStack(spacing: 0) {
                Spacer()

                // Sezione superiore: logo e titolo dell'app
                headerSection
                    .padding(.bottom, 60)

                // Sezione centrale: pulsante di autenticazione principale
                authenticationSection

                Spacer()

                // Sezione inferiore: stato della biometria
                statusSection
                    .padding(.bottom, 48)
            }
            .padding(.horizontal, 32)
        }
        .ignoresSafeArea()
        // Osserva i cambiamenti del messaggio di errore per aprire l'Alert
        .onChange(of: viewModel.errorMessage) { _, newValue in
            showErrorAlert = newValue != nil
        }
        // Alert nativo per comunicare gli errori di autenticazione all'utente
        .alert("Authentication Error", isPresented: $showErrorAlert) {
            Button("Retry") {
                viewModel.clearError()
                Task { await viewModel.authenticate() }
            }
            Button("Cancel", role: .cancel) {
                viewModel.clearError()
            }
        } message: {
            Text(viewModel.errorMessage ?? "An unknown error occurred.")
        }
        // Avvia l'autenticazione automaticamente all'apertura della schermata
        .task {
            // Attende che la view sia completamente visibile prima di mostrare
            // la finestra di dialogo biometrica del sistema
            try? await Task.sleep(for: .milliseconds(600))
            await viewModel.authenticate()
        }
    }

    // MARK: - Sotto-viste private

    /// Sfondo con gradiente scuro che simula un ambiente sicuro e professionale
    private var backgroundView: some View {
        LinearGradient(
            colors: [
                Color(red: 0.04, green: 0.04, blue: 0.12),
                Color(red: 0.08, green: 0.08, blue: 0.20),
                Color(red: 0.04, green: 0.08, blue: 0.18)
            ],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }

    /// Sezione header: icona animata + nome app + sottotitolo
    private var headerSection: some View {
        VStack(spacing: 20) {
            // Icona biometrica con anelli animati concentrici
            biometricIconView

            // Testo identificativo dell'applicazione
            VStack(spacing: 6) {
                Text("BiometricDemo")
                    .font(.system(size: 32, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)

                Text("Secure Authentication")
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(.white.opacity(0.5))
                    .kerning(2.5)
                    .textCase(.uppercase)
            }
        }
    }

    /// Icona biometrica con effetto di pulsazione e anello di gradiente
    private var biometricIconView: some View {
        ZStack {
            // Anello esterno animato con gradiente di colore
            Circle()
                .stroke(
                    LinearGradient(
                        colors: [.cyan, .blue, .purple, .cyan],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ),
                    lineWidth: 1.5
                )
                .frame(width: 130, height: 130)
                .scaleEffect(isPulsing ? 1.18 : 1.0)
                .opacity(isPulsing ? 0.25 : 0.7)
                .animation(
                    .easeInOut(duration: 2.2).repeatForever(autoreverses: true),
                    value: isPulsing
                )

            // Anello interno fisso
            Circle()
                .stroke(Color.white.opacity(0.06), lineWidth: 1)
                .frame(width: 110, height: 110)

            // Cerchio di sfondo con effetto vetro
            Circle()
                .fill(.ultraThinMaterial)
                .frame(width: 100, height: 100)

            // Icona SF Symbols del metodo biometrico rilevato
            Image(systemName: viewModel.biometricSymbol)
                .font(.system(size: 44, weight: .ultraLight))
                .foregroundStyle(
                    LinearGradient(
                        colors: [.cyan, .blue],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                )
                // Effetto pulse nativo di SwiftUI durante l'autenticazione in corso
                .symbolEffect(.pulse, isActive: viewModel.isAuthenticating)
        }
        .onAppear {
            // Avvia l'animazione dell'anello esterno
            isPulsing = true
        }
    }

    /// Sezione con il pulsante principale di autenticazione
    private var authenticationSection: some View {
        VStack(spacing: 16) {
            // Pulsante principale "Sign in with Face ID / Touch ID"
            authButton

            // Testo descrittivo sotto il pulsante
            Text("Your biometric data never leaves this device")
                .font(.caption)
                .foregroundStyle(.white.opacity(0.35))
                .multilineTextAlignment(.center)
                .padding(.top, 4)
        }
    }

    /// Pulsante di autenticazione con stato di caricamento integrato
    private var authButton: some View {
        Button {
            // Usa Task per chiamare la funzione async dal contesto della UI
            Task {
                await viewModel.authenticate()
            }
        } label: {
            HStack(spacing: 14) {
                // Mostra uno spinner durante l'autenticazione,
                // altrimenti l'icona del metodo biometrico
                if viewModel.isAuthenticating {
                    ProgressView()
                        .tint(.white)
                        .scaleEffect(0.85)
                } else {
                    Image(systemName: viewModel.biometricSymbol)
                        .font(.system(size: 18, weight: .medium))
                }

                Text(viewModel.isAuthenticating
                     ? "Verifying..."
                     : "Sign in with \(viewModel.biometricDisplayName)")
                    .font(.system(size: 17, weight: .semibold))
            }
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 18)
            .background(
                // Gradiente attivo quando la biometria è disponibile,
                // grigio semitrasparente quando non è utilizzabile
                Group {
                    if viewModel.isBiometricAvailable {
                        LinearGradient(
                            colors: [.cyan, Color(red: 0.1, green: 0.3, blue: 0.9)],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    } else {
                        LinearGradient(
                            colors: [Color.white.opacity(0.1), Color.white.opacity(0.1)],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    }
                }
            )
            .clipShape(RoundedRectangle(cornerRadius: 18))
            .shadow(
                color: viewModel.isBiometricAvailable ? .cyan.opacity(0.35) : .clear,
                radius: 16,
                y: 6
            )
        }
        .disabled(viewModel.isAuthenticating || !viewModel.isBiometricAvailable)
        // Micro-animazione di press sul pulsante
        .scaleEffect(viewModel.isAuthenticating ? 0.97 : 1.0)
        .animation(.spring(response: 0.25, dampingFraction: 0.7), value: viewModel.isAuthenticating)
    }

    /// Indicatore dello stato della biometria in fondo allo schermo
    private var statusSection: some View {
        HStack(spacing: 8) {
            // Pallino verde = disponibile, rosso = non disponibile
            Circle()
                .fill(viewModel.isBiometricAvailable ? Color.green : Color.red)
                .frame(width: 7, height: 7)
                .shadow(
                    color: viewModel.isBiometricAvailable ? .green : .red,
                    radius: 4
                )

            Text(viewModel.isBiometricAvailable
                 ? "\(viewModel.biometricDisplayName) is ready"
                 : "Biometrics unavailable — check Settings")
                .font(.caption2)
                .foregroundStyle(.white.opacity(0.4))
        }
    }
}

// MARK: - Preview

#Preview("Login — Face ID disponibile") {
    LoginView()
        .environment(AuthViewModel())
}
