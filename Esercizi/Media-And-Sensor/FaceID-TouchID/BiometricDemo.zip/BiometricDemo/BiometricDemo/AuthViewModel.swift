//
//  AuthViewModel.swift
//  BiometricDemo
//
//  Created by Antonio Minelli.
//
//  ViewModel principale per la gestione dello stato di autenticazione.
//  Utilizza il macro @Observable (Swift 5.9+/iOS 17+) per la reattività
//  automatica senza bisogno di @Published o ObservableObject.
//

import SwiftUI
import Observation

// MARK: - Stato di autenticazione

/// Rappresenta i possibili stati del flusso di autenticazione dell'utente.
/// Conforme a `Equatable` per poter essere usato come valore di `.animation`.
enum AuthState: Equatable {
    /// Utente non autenticato — mostra la schermata di login
    case loggedOut
    /// Autenticazione in corso — mostra indicatore di caricamento
    case authenticating
    /// Utente autenticato con successo — mostra la schermata protetta
    case loggedIn
}

// MARK: - AuthViewModel

/// ViewModel che orchestra l'intero flusso di autenticazione biometrica.
///
/// Responsabilità:
/// - Delegare le operazioni di basso livello a `BiometricAuthManager`
/// - Mantenere e aggiornare lo stato osservabile (`authState`, `errorMessage`, ecc.)
/// - Fornire proprietà calcolate convenienti per le viste SwiftUI
/// - Gestire i casi edge come il blocco biometrico con fallback al passcode
///
/// - Note: `@Observable` genera automaticamente il codice di osservazione; le viste
///   che leggono proprietà di questo ViewModel si aggiorneranno automaticamente.
///
/// - Important: `@MainActor` garantisce che tutte le modifiche allo stato
///   avvengano sul thread principale, prevenendo race condition con il rendering UI.
@Observable
@MainActor
final class AuthViewModel {

    // MARK: - Stato osservabile

    /// Stato corrente del flusso di autenticazione.
    /// Le viste usano questa proprietà per determinare quale schermata mostrare.
    var authState: AuthState = .loggedOut

    /// Messaggio di errore da presentare all'utente (es. in un Alert).
    /// `nil` indica nessun errore attivo.
    var errorMessage: String? = nil

    /// `true` mentre è in corso un tentativo di autenticazione.
    /// Usato per mostrare indicatori di caricamento e disabilitare pulsanti.
    var isAuthenticating: Bool = false

    // MARK: - Dipendenze

    /// Responsabile dell'interazione diretta con il framework LocalAuthentication.
    /// Iniettato nel costruttore per facilitare il testing (dependency injection).
    private let authManager: BiometricAuthManager

    // MARK: - Inizializzazione

    /// Crea il ViewModel con un manager opzionale.
    /// In produzione viene usato il default; nei test si inietta un mock.
    /// - Note: Il default viene creato nel corpo dell'init (già su @MainActor)
    ///   e non come valore di default del parametro, per rispettare Swift 6
    ///   strict concurrency (i default dei parametri sono nonisolated).
    init(authManager: BiometricAuthManager? = nil) {
        self.authManager = authManager ?? BiometricAuthManager()
    }

    // MARK: - Proprietà calcolate per le viste

    /// Tipo di biometria rilevata sul dispositivo corrente.
    var biometricType: BiometricType {
        authManager.biometricType
    }

    /// `true` se il dispositivo supporta e ha la biometria registrata.
    var isBiometricAvailable: Bool {
        authManager.isBiometricAvailable
    }

    /// Nome leggibile del metodo biometrico (es. "Face ID", "Touch ID").
    var biometricDisplayName: String {
        switch biometricType {
        case .faceID:   return "Face ID"
        case .touchID:  return "Touch ID"
        case .opticID:  return "Optic ID"
        case .none:     return "Biometrics"
        }
    }

    /// Nome del simbolo SF Symbols corrispondente al metodo biometrico.
    var biometricSymbol: String {
        switch biometricType {
        case .faceID:   return "faceid"
        case .touchID:  return "touchid"
        case .opticID:  return "eye.circle"
        case .none:     return "lock.fill"
        }
    }

    // MARK: - Azioni pubbliche

    /// Avvia il processo di autenticazione biometrica.
    ///
    /// Il metodo gestisce automaticamente:
    /// - Il blocco biometrico (con escalation al passcode)
    /// - La cancellazione da parte dell'utente (senza mostrare errori)
    /// - Qualsiasi altro errore (con messaggio visibile all'utente)
    func authenticate() async {
        // Azzera errori precedenti prima di ogni nuovo tentativo
        errorMessage = nil
        isAuthenticating = true
        authState = .authenticating

        // Stringa mostrata dal sistema nella finestra di dialogo biometrica
        let reason = "Authenticate to access BiometricDemo"

        defer {
            // Garantisce che isAuthenticating venga sempre ripristinato,
            // anche in caso di uscita anticipata tramite throw o return
            isAuthenticating = false
        }

        do {
            let success = try await authManager.authenticate(reason: reason)
            if success {
                // Transizione con animazione fluida alla schermata protetta
                withAnimation(.spring(response: 0.5, dampingFraction: 0.8)) {
                    authState = .loggedIn
                }
            }
        } catch BiometricAuthError.userCancel {
            // L'utente ha annullato volontariamente: torna al login senza errori
            authState = .loggedOut

        } catch BiometricAuthError.userFallback {
            // L'utente ha scelto il passcode tramite il pulsante fallback
            authState = .loggedOut
            await authenticateWithPasscodeFallback(reason: reason)

        } catch BiometricAuthError.biometryLockout {
            // Biometria bloccata per troppi tentativi: escalation automatica al passcode
            await authenticateWithPasscodeFallback(reason: reason)

        } catch {
            // Qualsiasi altro errore: mostra il messaggio e torna al login
            authState = .loggedOut
            errorMessage = error.localizedDescription
        }
    }

    /// Esegue il logout dell'utente corrente.
    ///
    /// Invalida il contesto LocalAuthentication per sicurezza, impedendo
    /// che una sessione biometrica precedente venga riutilizzata.
    func logout() {
        // Invalida il contesto LA — la prossima autenticazione richiederà
        // una nuova verifica biometrica da parte del sensore
        authManager.invalidate()

        withAnimation(.easeInOut(duration: 0.4)) {
            authState = .loggedOut
        }

        // Pulisce eventuali errori residui
        errorMessage = nil
        isAuthenticating = false
    }

    /// Cancella il messaggio di errore corrente.
    /// Tipicamente chiamato quando l'utente chiude l'Alert di errore.
    func clearError() {
        errorMessage = nil
    }

    // MARK: - Metodi privati

    /// Fallback all'autenticazione tramite passcode del dispositivo.
    /// Chiamato quando la biometria è bloccata o l'utente sceglie il fallback.
    private func authenticateWithPasscodeFallback(reason: String) async {
        do {
            let success = try await authManager.authenticateWithFallback(reason: reason)
            if success {
                withAnimation(.spring(response: 0.5, dampingFraction: 0.8)) {
                    authState = .loggedIn
                }
            }
        } catch BiometricAuthError.userCancel {
            // Anche qui, la cancellazione è silenziosa
            authState = .loggedOut
        } catch {
            authState = .loggedOut
            errorMessage = error.localizedDescription
        }
    }
}
