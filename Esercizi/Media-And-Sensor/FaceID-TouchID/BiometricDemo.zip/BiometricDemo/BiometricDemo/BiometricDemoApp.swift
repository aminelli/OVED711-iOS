//
//  BiometricDemoApp.swift
//  BiometricDemo
//
//  Created by Antonio Minelli.
//
//  Punto di ingresso dell'applicazione.
//  Crea il ViewModel una sola volta e lo inietta nell'ambiente SwiftUI
//  per renderlo disponibile a tutta la gerarchia di viste.
//

import SwiftUI

/// Punto di ingresso principale dell'applicazione BiometricDemo.
///
/// Responsabilità:
/// - Creare l'istanza singleton di `AuthViewModel` per l'intera sessione dell'app
/// - Iniettarlo nell'ambiente SwiftUI tramite `.environment(_:)`
/// - Applicare l'animazione globale per le transizioni tra stati di autenticazione
///
/// - Note: `@State` su `authViewModel` garantisce che l'istanza persista
///   per tutta la durata dell'app e che SwiftUI la osservi correttamente
///   grazie al macro `@Observable`.
@main
struct BiometricDemoApp: App {

    /// ViewModel di autenticazione — creato una sola volta, vive per tutta l'app.
    /// `@State` è necessario per far funzionare `@Observable` con l'App lifecycle.
    @State private var authViewModel = AuthViewModel()

    var body: some Scene {
        WindowGroup {
            ContentView()
                // Rende authViewModel disponibile a ContentView, LoginView,
                // HomeView e qualsiasi altra vista figlia tramite @Environment
                .environment(authViewModel)
                // Animazione globale delle transizioni: si attiva ogni volta
                // che authState cambia valore (richiede AuthState: Equatable)
                .animation(.easeInOut(duration: 0.35), value: authViewModel.authState)
        }
    }
}

