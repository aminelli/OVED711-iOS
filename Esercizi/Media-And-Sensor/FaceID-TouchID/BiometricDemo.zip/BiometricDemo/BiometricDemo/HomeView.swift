//
//  HomeView.swift
//  BiometricDemo
//
//  Created by Antonio Minelli on 22/06/2026.
//
//  Schermata protetta, accessibile solo dopo autenticazione biometrica riuscita.
//  Mostra le informazioni sulla sessione, il metodo biometrico usato
//  e le funzionalità di sicurezza implementate nell'app.
//

import SwiftUI

/// Vista principale dell'area protetta dell'applicazione.
///
/// Accessibile esclusivamente dopo una autenticazione biometrica riuscita.
/// Presenta un riepilogo delle informazioni biometriche e di sicurezza
/// e offre la funzione di logout con richiesta di conferma.
struct HomeView: View {

    // MARK: - ViewModel dall'ambiente SwiftUI

    /// ViewModel condiviso per accedere ai dati e gestire il logout
    @Environment(AuthViewModel.self) private var viewModel

    // MARK: - Stato locale della vista

    /// Controlla l'animazione di entrata della schermata (fade + traslazione)
    @State private var hasAppeared: Bool = false

    /// Controlla la visibilità del dialogo di conferma logout
    @State private var showLogoutConfirmation: Bool = false

    // MARK: - Corpo della vista

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    // 1. Banner di benvenuto con icona di successo
                    welcomeBanner
                        .padding(.top, 8)

                    // 2. Scheda: informazioni sul metodo biometrico usato
                    biometricInfoCard

                    // 3. Scheda: funzionalità di sicurezza implementate
                    securityFeaturesCard

                    // 4. Scheda: dati della sessione corrente
                    sessionCard
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 32)
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("Dashboard")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    // Pulsante di logout nella barra di navigazione
                    Button {
                        showLogoutConfirmation = true
                    } label: {
                        Label("Sign Out", systemImage: "rectangle.portrait.and.arrow.right")
                            .foregroundStyle(.red)
                    }
                }
            }
            // Dialogo di conferma prima di eseguire il logout
            .confirmationDialog(
                "Sign Out of BiometricDemo",
                isPresented: $showLogoutConfirmation,
                titleVisibility: .visible
            ) {
                // Azione distruttiva: esegue il logout invalidando il contesto LA
                Button("Sign Out", role: .destructive) {
                    viewModel.logout()
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("You will need to authenticate again to access the app.")
            }
        }
        // Animazione di entrata: la vista appare con fade + leggero movimento dal basso
        .opacity(hasAppeared ? 1.0 : 0.0)
        .offset(y: hasAppeared ? 0 : 24)
        .onAppear {
            withAnimation(.spring(response: 0.55, dampingFraction: 0.85).delay(0.05)) {
                hasAppeared = true
            }
        }
    }

    // MARK: - Sotto-viste: Banner di benvenuto

    /// Banner verde con icona checkmark — conferma visiva del successo dell'autenticazione
    private var welcomeBanner: some View {
        HStack(spacing: 16) {
            // Icona di conferma con sfondo colorato
            ZStack {
                Circle()
                    .fill(
                        LinearGradient(
                            colors: [.green.opacity(0.2), .cyan.opacity(0.15)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 56, height: 56)

                Image(systemName: "checkmark.shield.fill")
                    .font(.system(size: 26))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.green, .cyan],
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    )
                    // Effetto bounce al momento dell'apparizione
                    .symbolEffect(.bounce, value: hasAppeared)
            }

            VStack(alignment: .leading, spacing: 4) {
                Text("Authentication Successful")
                    .font(.headline)
                    .foregroundStyle(.primary)

                Text("Signed in via \(viewModel.biometricDisplayName)")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            Spacer()
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 14)
                .fill(Color(.secondarySystemGroupedBackground))
        )
    }

    // MARK: - Sotto-viste: Scheda informazioni biometria

    /// Scheda con i dettagli del metodo biometrico disponibile sul dispositivo
    private var biometricInfoCard: some View {
        cardContainer(header: "Biometric Information", headerIcon: viewModel.biometricSymbol) {
            VStack(spacing: 0) {
                infoRow(
                    icon: viewModel.biometricSymbol,
                    color: .blue,
                    title: "Authentication Method",
                    value: viewModel.biometricDisplayName
                )

                cardDivider()

                infoRow(
                    icon: "checkmark.seal.fill",
                    color: .green,
                    title: "Sensor Status",
                    value: viewModel.isBiometricAvailable ? "Available & Enrolled" : "Unavailable"
                )

                cardDivider()

                infoRow(
                    icon: "cpu.fill",
                    color: .purple,
                    title: "Security Chip",
                    value: securityChipName
                )

                cardDivider()

                infoRow(
                    icon: "lock.shield.fill",
                    color: .orange,
                    title: "Security Level",
                    value: securityLevelDescription
                )
            }
        }
    }

    // MARK: - Sotto-viste: Scheda funzionalità di sicurezza

    /// Scheda che elenca le pratiche di sicurezza adottate nell'implementazione
    private var securityFeaturesCard: some View {
        cardContainer(header: "Security Implementation", headerIcon: "shield.lefthalf.filled") {
            VStack(spacing: 0) {
                featureRow(
                    icon: "arrow.triangle.2.circlepath",
                    color: .blue,
                    title: "Fresh LAContext",
                    detail: "Nuovo contesto ad ogni autenticazione"
                )

                cardDivider()

                featureRow(
                    icon: "xmark.circle",
                    color: .red,
                    title: "Context Invalidation",
                    detail: "Contesto invalidato al logout"
                )

                cardDivider()

                featureRow(
                    icon: "exclamationmark.triangle.fill",
                    color: .orange,
                    title: "Lockout Recovery",
                    detail: "Fallback automatico al passcode"
                )

                cardDivider()

                featureRow(
                    icon: "swift",
                    color: Color(red: 0.95, green: 0.4, blue: 0.1),
                    title: "Swift 6 Concurrency",
                    detail: "async/await + MainActor isolation"
                )

                cardDivider()

                featureRow(
                    icon: "eye.slash.fill",
                    color: .teal,
                    title: "On-Device Only",
                    detail: "Nessun dato biometrico inviato in rete"
                )
            }
        }
    }

    // MARK: - Sotto-viste: Scheda sessione

    /// Scheda con i metadati della sessione corrente
    private var sessionCard: some View {
        cardContainer(header: "Current Session", headerIcon: "clock.fill") {
            VStack(spacing: 0) {
                infoRow(
                    icon: "calendar.badge.checkmark",
                    color: .teal,
                    title: "Authenticated At",
                    value: Date().formatted(date: .abbreviated, time: .shortened)
                )

                cardDivider()

                infoRow(
                    icon: "iphone.gen3",
                    color: .indigo,
                    title: "Platform",
                    value: "iOS 26"
                )

                cardDivider()

                infoRow(
                    icon: "swift",
                    color: Color(red: 0.95, green: 0.4, blue: 0.1),
                    title: "Swift Version",
                    value: "Swift 6.3"
                )
            }
        }
        .padding(.bottom, 4)
    }

    // MARK: - Componenti riutilizzabili

    /// Contenitore generico per le schede informative.
    ///
    /// - Parameters:
    ///   - header: Titolo della sezione
    ///   - headerIcon: Icona SF Symbols per l'intestazione
    ///   - content: Contenuto della scheda (closure ViewBuilder)
    private func cardContainer<Content: View>(
        header: String,
        headerIcon: String,
        @ViewBuilder content: () -> Content
    ) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            // Intestazione sezione con icona e testo maiuscolo
            Label(header, systemImage: headerIcon)
                .font(.footnote.weight(.semibold))
                .foregroundStyle(.secondary)
                .textCase(.uppercase)
                .kerning(0.4)
                .padding(.leading, 4)

            // Contenuto con angoli arrotondati e sfondo di sistema
            content()
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color(.secondarySystemGroupedBackground))
                )
        }
    }

    /// Riga informativa con icona colorata, titolo e valore
    private func infoRow(icon: String, color: Color, title: String, value: String) -> some View {
        HStack(spacing: 12) {
            // Icona con sfondo colorato arrotondato
            iconBadge(name: icon, color: color)

            Text(title)
                .font(.body)
                .foregroundStyle(.primary)

            Spacer()

            Text(value)
                .font(.body)
                .foregroundStyle(.secondary)
                .lineLimit(1)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
    }

    /// Riga funzionalità con icona, titolo e descrizione dettagliata + spunta verde
    private func featureRow(icon: String, color: Color, title: String, detail: String) -> some View {
        HStack(spacing: 12) {
            iconBadge(name: icon, color: color)

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.body)
                    .foregroundStyle(.primary)

                Text(detail)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            // Spunta verde: indica che la funzionalità è attiva
            Image(systemName: "checkmark.circle.fill")
                .foregroundStyle(.green)
                .font(.callout)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
    }

    /// Badge icona con sfondo colorato arrotondato (usato nelle righe delle schede)
    private func iconBadge(name: String, color: Color) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 7)
                .fill(color.opacity(0.15))
                .frame(width: 32, height: 32)

            Image(systemName: name)
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(color)
        }
    }

    /// Divisore interno alle schede, con rientro per allinearlo al testo
    private func cardDivider() -> some View {
        Divider()
            .padding(.leading, 60)
    }

    // MARK: - Proprietà di supporto

    /// Nome del chip di sicurezza basato sul tipo biometrico
    private var securityChipName: String {
        switch viewModel.biometricType {
        case .faceID, .opticID: return "Neural Engine"
        case .touchID:          return "Secure Enclave"
        case .none:             return "N/A"
        }
    }

    /// Descrizione del livello di sicurezza biometrica
    private var securityLevelDescription: String {
        switch viewModel.biometricType {
        case .faceID:   return "Very High — 3D depth map"
        case .touchID:  return "High — fingerprint scan"
        case .opticID:  return "Very High — iris scan"
        case .none:     return "Standard — passcode only"
        }
    }
}

// MARK: - Preview

#Preview("Home — autenticato") {
    // Simula uno stato di login per visualizzare la HomeView nel canvas
    let vm = AuthViewModel()
    return HomeView()
        .environment(vm)
}
