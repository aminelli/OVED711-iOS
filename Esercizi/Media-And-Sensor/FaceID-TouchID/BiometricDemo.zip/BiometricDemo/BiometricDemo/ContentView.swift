//
//  ContentView.swift
//  BiometricDemo
//
//  Created by Antonio Minelli on 22/06/2026.
//
//  Vista radice dell'applicazione: funge da router tra LoginView e HomeView
//  in base allo stato di autenticazione corrente nel ViewModel.
//

import SwiftUI

/// Vista radice che gestisce la navigazione tra le schermate dell'app.
///
/// Non contiene logica di business: legge il solo `authState` dal ViewModel
/// e renderizza la vista appropriata con transizioni animate.
///
/// Flusso di navigazione:
/// ```
/// .loggedOut / .authenticating  →  LoginView
/// .loggedIn                     →  HomeView
/// ```
struct ContentView: View {

    /// Accede al ViewModel iniettato nell'ambiente da `BiometricDemoApp`
    @Environment(AuthViewModel.self) private var viewModel

    var body: some View {
        // `Group` con `switch` permette transizioni animate tra viste diverse
        Group {
            switch viewModel.authState {
            case .loggedOut, .authenticating:
                // Schermata di login — visibile quando l'utente non è autenticato
                // o mentre l'autenticazione è in corso
                LoginView()
                    .transition(
                        .asymmetric(
                            // Entrata: appare sfumando e scalando leggermente
                            insertion: .opacity.combined(with: .scale(scale: 0.96)),
                            // Uscita: scompare sfumando e scalando verso l'alto
                            removal: .opacity.combined(with: .scale(scale: 1.04))
                        )
                    )

            case .loggedIn:
                // Schermata protetta — visibile solo dopo autenticazione riuscita
                HomeView()
                    .transition(
                        .asymmetric(
                            // Entrata: scivola da destra sfumando
                            insertion: .opacity.combined(with: .move(edge: .trailing)),
                            // Uscita: scivola verso sinistra sfumando
                            removal: .opacity.combined(with: .move(edge: .leading))
                        )
                    )
            }
        }
        // L'animazione delle transizioni è gestita da BiometricDemoApp
        // tramite il modificatore .animation sul WindowGroup
    }
}

// MARK: - Preview

#Preview("ContentView — login") {
    ContentView()
        .environment(AuthViewModel())
}

