//
//  BiometricAuthManager.swift
//  BiometricDemo
//
//  Created by Antonio Minelli on 22/06/2026.
//
//  Gestione centralizzata dell'autenticazione biometrica tramite il framework
//  LocalAuthentication di Apple. Supporta Face ID, Touch ID e Optic ID.
//  Progettato per la piena compatibilità con Swift 6 strict concurrency.
//

// @preconcurrency rimuove i warning di Sendable per i tipi ObjC (es. LAContext)
// non ancora completamente annotati per la concorrenza Swift 6.
@preconcurrency import LocalAuthentication
import Foundation

// MARK: - Tipi di biometria supportati

/// Rappresenta il tipo di biometria hardware disponibile sul dispositivo corrente.
enum BiometricType {
    /// Nessuna biometria disponibile o non abilitata
    case none
    /// Face ID — disponibile su iPhone X e successivi, iPad Pro con chip M-series
    case faceID
    /// Touch ID — disponibile su iPhone con tasto Home fisico, iPad e MacBook
    case touchID
    /// Optic ID — disponibile su Apple Vision Pro
    case opticID
}

// MARK: - Errori di autenticazione biometrica

/// Errori tipizzati che possono verificarsi durante il processo di autenticazione biometrica.
/// Ciascun caso mappa un codice LAError a un messaggio leggibile dall'utente.
enum BiometricAuthError: LocalizedError {
    /// L'autenticazione è fallita (ad es. Face/Touch ID non riconosciuto)
    case authenticationFailed
    /// L'utente ha premuto "Annulla" nella finestra di dialogo del sistema
    case userCancel
    /// L'utente ha scelto il metodo di autenticazione alternativo (fallback)
    case userFallback
    /// Il sistema operativo ha annullato l'autenticazione (es. chiamata in arrivo)
    case systemCancel
    /// Il passcode del dispositivo non è stato impostato nelle Impostazioni
    case passcodeNotSet
    /// La biometria non è fisicamente disponibile su questo dispositivo
    case biometryNotAvailable
    /// Nessun dato biometrico registrato nelle Impostazioni del dispositivo
    case biometryNotEnrolled
    /// La biometria è temporaneamente bloccata per troppi tentativi falliti
    case biometryLockout
    /// Errore generico non classificato, con descrizione testuale
    case unknown(String)

    /// Descrizione localizzata dell'errore, mostrata all'utente nell'interfaccia
    var errorDescription: String? {
        switch self {
        case .authenticationFailed:
            return "Authentication failed. Please try again."
        case .userCancel:
            return "Authentication was cancelled."
        case .userFallback:
            return "Passcode authentication selected."
        case .systemCancel:
            return "Authentication was cancelled by the system."
        case .passcodeNotSet:
            return "Device passcode is not configured. Please set one in Settings."
        case .biometryNotAvailable:
            return "Biometric authentication is not available on this device."
        case .biometryNotEnrolled:
            return "No biometric data enrolled. Please configure Face ID or Touch ID in Settings."
        case .biometryLockout:
            return "Biometric authentication is locked due to too many failed attempts."
        case .unknown(let message):
            return "An unexpected error occurred: \(message)"
        }
    }
}

// MARK: - BiometricAuthManager

/// Manager responsabile dell'interazione con il framework LocalAuthentication.
///
/// - Important: La classe è isolata su `@MainActor` per garantire che tutti gli
///   aggiornamenti di stato e le letture di proprietà avvengano sul thread principale,
///   rispettando i requisiti di Swift 6 strict concurrency.
///
/// - Note: Per ogni tentativo di autenticazione viene creato un nuovo `LAContext`
///   per evitare riuso di sessioni precedenti, migliorando la sicurezza complessiva.
@MainActor
final class BiometricAuthManager {

    // MARK: - Stato privato

    /// Contesto di autenticazione LocalAuthentication.
    /// Viene ricreato ad ogni chiamata di autenticazione per sicurezza.
    private var context: LAContext

    // MARK: - Inizializzazione

    init() {
        // Crea il contesto iniziale — verrà sostituito ad ogni autenticazione
        self.context = LAContext()
    }

    // MARK: - Proprietà calcolate pubbliche

    /// Rileva il tipo di sensore biometrico disponibile sul dispositivo.
    /// Crea un contesto temporaneo per la sola interrogazione del tipo,
    /// senza consumare il contesto di autenticazione corrente.
    var biometricType: BiometricType {
        let probe = LAContext()
        var error: NSError?

        // canEvaluatePolicy popola anche il campo biometryType prima di restituire
        guard probe.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) else {
            return .none
        }

        switch probe.biometryType {
        case .faceID:   return .faceID
        case .touchID:  return .touchID
        case .opticID:  return .opticID
        case .none:     return .none
        @unknown default:
            // Gestione difensiva per futuri tipi biometrici non ancora noti
            return .none
        }
    }

    /// Indica se l'autenticazione biometrica è utilizzabile sul dispositivo corrente.
    /// Restituisce `false` se la biometria non è disponibile, non è registrata o è bloccata.
    var isBiometricAvailable: Bool {
        let probe = LAContext()
        var error: NSError?
        return probe.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error)
    }

    // MARK: - Autenticazione biometrica pura

    /// Esegue l'autenticazione biometrica (Face ID / Touch ID) in modo asincrono.
    ///
    /// Il metodo utilizza `withCheckedThrowingContinuation` per bridging
    /// con la callback-based API di `LAContext.evaluatePolicy`.
    ///
    /// - Parameter reason: Stringa mostrata all'utente nella finestra di dialogo
    ///   del sistema per spiegare perché viene richiesta l'autenticazione.
    /// - Returns: `true` se l'autenticazione biometrica ha avuto successo.
    /// - Throws: `BiometricAuthError` con dettaglio del motivo del fallimento.
    func authenticate(reason: String) async throws -> Bool {
        // Crea un nuovo contesto ad ogni tentativo per evitare stati residui
        let ctx = LAContext()

        // Personalizzazione della finestra di dialogo del sistema
        ctx.localizedCancelTitle   = "Cancel"      // Testo pulsante annulla
        ctx.localizedFallbackTitle = "Use Passcode" // Testo pulsante fallback al passcode

        // Salva il contesto corrente per poterlo invalidare al logout
        self.context = ctx

        // Verifica preventiva della disponibilità biometrica
        var policyError: NSError?
        guard ctx.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &policyError) else {
            throw Self.mapError(policyError)
        }

        // Bridge dalla callback API alla concorrenza Swift tramite continuazione
        return try await withCheckedThrowingContinuation { continuation in
            ctx.evaluatePolicy(
                .deviceOwnerAuthenticationWithBiometrics,
                localizedReason: reason
            ) { success, authError in
                // Questa closure viene eseguita su una coda privata di LocalAuthentication
                if success {
                    continuation.resume(returning: true)
                } else {
                    continuation.resume(throwing: Self.mapError(authError as NSError?))
                }
            }
        }
    }

    // MARK: - Autenticazione con fallback al passcode

    /// Esegue l'autenticazione con policy `deviceOwnerAuthentication`, che accetta
    /// sia biometria sia il passcode del dispositivo come secondo fattore.
    ///
    /// Utile quando la biometria è bloccata (`biometryLockout`) o non disponibile.
    ///
    /// - Parameter reason: Stringa mostrata all'utente nella finestra di dialogo.
    /// - Returns: `true` se l'autenticazione (biometrica o passcode) ha avuto successo.
    /// - Throws: `BiometricAuthError` in caso di fallimento.
    func authenticateWithFallback(reason: String) async throws -> Bool {
        let ctx = LAContext()
        ctx.localizedCancelTitle = "Cancel"
        self.context = ctx

        var policyError: NSError?
        // deviceOwnerAuthentication abilita sia biometria sia passcode come metodi validi
        guard ctx.canEvaluatePolicy(.deviceOwnerAuthentication, error: &policyError) else {
            throw Self.mapError(policyError)
        }

        return try await withCheckedThrowingContinuation { continuation in
            ctx.evaluatePolicy(
                .deviceOwnerAuthentication,
                localizedReason: reason
            ) { success, authError in
                if success {
                    continuation.resume(returning: true)
                } else {
                    continuation.resume(throwing: Self.mapError(authError as NSError?))
                }
            }
        }
    }

    // MARK: - Lifecycle

    /// Invalida il contesto di autenticazione corrente e ne crea uno nuovo pulito.
    ///
    /// Deve essere chiamato al logout per garantire che una successiva autenticazione
    /// richieda una nuova verifica biometrica, senza riutilizzare sessioni precedenti.
    func invalidate() {
        context.invalidate()
        context = LAContext()
    }

    // MARK: - Mapping degli errori (metodo statico nonisolated)

    /// Mappa un `NSError` del framework LocalAuthentication al tipo `BiometricAuthError`.
    ///
    /// Il metodo è `nonisolated` e `static` perché viene chiamato dall'interno
    /// di closure `@Sendable` (continuation) che girano fuori dall'actor principale.
    nonisolated static func mapError(_ error: NSError?) -> BiometricAuthError {
        guard let error else {
            // Nessun oggetto errore: autenticazione fallita per motivo sconosciuto
            return .authenticationFailed
        }

        // Mapping esplicito di tutti i codici LAError documentati da Apple
        switch LAError.Code(rawValue: error.code) {
        case .authenticationFailed:
            return .authenticationFailed
        case .userCancel:
            return .userCancel
        case .userFallback:
            return .userFallback
        case .systemCancel:
            return .systemCancel
        case .passcodeNotSet:
            return .passcodeNotSet
        case .biometryNotAvailable, .touchIDNotAvailable:
            return .biometryNotAvailable
        case .biometryNotEnrolled, .touchIDNotEnrolled:
            return .biometryNotEnrolled
        case .biometryLockout, .touchIDLockout:
            return .biometryLockout
        default:
            // Codice errore non riconosciuto: propaga la descrizione originale
            return .unknown(error.localizedDescription)
        }
    }
}
