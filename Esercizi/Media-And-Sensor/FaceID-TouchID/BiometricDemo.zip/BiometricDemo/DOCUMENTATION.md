# BiometricDemo — Documentazione Tecnica

> Applicazione dimostrativa per l'autenticazione biometrica avanzata su iOS 26  
> Tecnologie: **Swift 6.3 · SwiftUI · LocalAuthentication framework**

---

## Indice

1. [Panoramica](#1-panoramica)
2. [Architettura del progetto](#2-architettura-del-progetto)
3. [Struttura dei file](#3-struttura-dei-file)
4. [Componenti principali](#4-componenti-principali)
   - [BiometricAuthManager](#41-biometricauthmanager)
   - [AuthViewModel](#42-authviewmodel)
   - [LoginView](#43-loginview)
   - [HomeView](#44-homeview)
   - [ContentView](#45-contentview)
   - [BiometricDemoApp](#46-biometricdemoapp)
5. [Flusso di autenticazione](#5-flusso-di-autenticazione)
6. [Gestione degli errori](#6-gestione-degli-errori)
7. [Concorrenza Swift 6](#7-concorrenza-swift-6)
8. [Configurazione del progetto Xcode](#8-configurazione-del-progetto-xcode)
9. [Best practices adottate](#9-best-practices-adottate)
10. [Testing](#10-testing)
11. [Note di sicurezza](#11-note-di-sicurezza)

---

## 1. Panoramica

**BiometricDemo** è una mini-app dimostrativa che illustra l'utilizzo avanzato del framework `LocalAuthentication` di Apple per implementare un sistema di login sicuro tramite:

| Metodo | Dispositivo | Tecnologia |
|--------|-------------|------------|
| **Face ID** | iPhone X+, iPad Pro M-series | Neural Engine + mappa 3D del volto |
| **Touch ID** | iPhone con tasto Home, iPad, MacBook | Secure Enclave + impronta digitale |
| **Optic ID** | Apple Vision Pro | Scansione dell'iride |

L'app dimostra pattern avanzati compatibili con **Swift 6 strict concurrency**, `@Observable`, e le API di transizione di **SwiftUI**.

---

## 2. Architettura del progetto

Il progetto segue il pattern **MVVM (Model–View–ViewModel)** con separazione netta delle responsabilità:

```
┌─────────────────────────────────────────────────────────────────┐
│                        SwiftUI Views                             │
│  BiometricDemoApp → ContentView → LoginView / HomeView          │
└──────────────────────────┬──────────────────────────────────────┘
                           │ @Environment(AuthViewModel)
┌──────────────────────────▼──────────────────────────────────────┐
│                      AuthViewModel                               │
│  @Observable · @MainActor · Gestione stati · Error handling      │
└──────────────────────────┬──────────────────────────────────────┘
                           │ dependency injection
┌──────────────────────────▼──────────────────────────────────────┐
│                   BiometricAuthManager                           │
│  @MainActor · LAContext · async/await · nonisolated static      │
└──────────────────────────┬──────────────────────────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────────────┐
│            LocalAuthentication Framework (Apple SDK)             │
│  LAContext · LAPolicy · LABiometryType · LAError                 │
└─────────────────────────────────────────────────────────────────┘
```

### Principi architetturali

- **Single Source of Truth**: `AuthViewModel` è l'unica fonte dello stato di autenticazione
- **Dependency Injection**: `BiometricAuthManager` viene iniettato nel ViewModel (facilita il testing)
- **Actor Isolation**: tutto lo stato modificabile risiede su `@MainActor`
- **Separazione UI/Logica**: le viste non contengono nessuna logica di business

---

## 3. Struttura dei file

```
BiometricDemo/
├── BiometricDemoApp.swift       # Entry point — crea e inietta AuthViewModel
├── ContentView.swift            # Router principale tra login e home
├── BiometricAuthManager.swift   # Wrapper LocalAuthentication (Model)
├── AuthViewModel.swift          # ViewModel con stato osservabile
├── LoginView.swift              # Schermata di login con biometria
└── HomeView.swift               # Schermata protetta post-autenticazione
```

---

## 4. Componenti principali

### 4.1 BiometricAuthManager

**File**: `BiometricAuthManager.swift`  
**Ruolo**: Astrae l'interazione con `LAContext` e il framework `LocalAuthentication`.

#### Tipi definiti

```swift
enum BiometricType { case none, faceID, touchID, opticID }
enum BiometricAuthError: LocalizedError { ... }
```

#### Metodi principali

| Metodo | Policy usata | Descrizione |
|--------|-------------|-------------|
| `authenticate(reason:)` | `.deviceOwnerAuthenticationWithBiometrics` | Solo biometria, nessun fallback automatico |
| `authenticateWithFallback(reason:)` | `.deviceOwnerAuthentication` | Biometria + passcode come alternativa |
| `invalidate()` | — | Invalida il contesto corrente (chiamato al logout) |

#### Dettaglio: bridge callback → async/await

Il framework `LocalAuthentication` usa callback (completion handler). Per integrarsi con `async/await` di Swift si usa `withCheckedThrowingContinuation`:

```swift
return try await withCheckedThrowingContinuation { continuation in
    ctx.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics,
                       localizedReason: reason) { success, error in
        if success {
            continuation.resume(returning: true)
        } else {
            continuation.resume(throwing: Self.mapError(error as NSError?))
        }
    }
}
```

> **Nota Swift 6**: Il metodo `mapError` è dichiarato `nonisolated static` per poter essere chiamato dalla closure `@Sendable` della continuation, che gira su una coda privata di `LocalAuthentication`.

---

### 4.2 AuthViewModel

**File**: `AuthViewModel.swift`  
**Ruolo**: Orchestra il flusso di autenticazione e mantiene lo stato osservabile.

#### Stato osservabile

```swift
var authState: AuthState       // .loggedOut | .authenticating | .loggedIn
var errorMessage: String?      // nil = nessun errore attivo
var isAuthenticating: Bool     // true durante il tentativo in corso
```

#### Metodo `authenticate()`

```
authenticate()
    │
    ├─► BiometricAuthManager.authenticate()
    │       ├─ success → authState = .loggedIn
    │       ├─ .userCancel → authState = .loggedOut (silenzioso)
    │       ├─ .userFallback → authenticateWithPasscodeFallback()
    │       ├─ .biometryLockout → authenticateWithPasscodeFallback()
    │       └─ altri errori → errorMessage = error.localizedDescription
    │
    └─► (defer) isAuthenticating = false
```

#### Proprietà calcolate per le viste

| Proprietà | Tipo | Descrizione |
|-----------|------|-------------|
| `biometricType` | `BiometricType` | Tipo di sensore rilevato |
| `isBiometricAvailable` | `Bool` | Biometria disponibile e registrata |
| `biometricDisplayName` | `String` | "Face ID", "Touch ID", "Optic ID" |
| `biometricSymbol` | `String` | Nome SF Symbol corrispondente |

---

### 4.3 LoginView

**File**: `LoginView.swift`  
**Ruolo**: Schermata di accesso con pulsante biometrico e feedback visivo.

#### Funzionalità

- **Auto-launch**: avvia automaticamente l'autenticazione 600ms dopo l'apertura
- **Animazione pulsante**: scala e opacità animate in base a `isAuthenticating`
- **Icona adattiva**: mostra `faceid`, `touchid` o `lock.fill` in base al dispositivo
- **Alert errori**: presenta un `Alert` nativo con pulsanti "Retry" e "Cancel"
- **Indicatore di stato**: pallino verde/rosso che indica la disponibilità della biometria

#### Ciclo di vita

```
.task { }
    └─► Task.sleep(600ms)
    └─► viewModel.authenticate()
```

---

### 4.4 HomeView

**File**: `HomeView.swift`  
**Ruolo**: Area protetta accessibile solo post-autenticazione.

#### Sezioni della schermata

1. **Welcome Banner** — icona checkmark con gradiente verde + nome del metodo usato
2. **Biometric Information** — tipo di sensore, stato, chip di sicurezza, livello
3. **Security Implementation** — riepilogo delle pratiche di sicurezza adottate
4. **Current Session** — orario di autenticazione, piattaforma, versione Swift

#### Logout

Il logout è protetto da un `confirmationDialog` con azione `.destructive` che chiama `viewModel.logout()`, il quale:
1. Chiama `authManager.invalidate()` per invalidare il contesto `LAContext`
2. Imposta `authState = .loggedOut` con animazione

---

### 4.5 ContentView

**File**: `ContentView.swift`  
**Ruolo**: Router puro — nessuna logica, solo switch su `authState`.

```swift
switch viewModel.authState {
case .loggedOut, .authenticating:
    LoginView()
        .transition(.asymmetric(insertion: ..., removal: ...))
case .loggedIn:
    HomeView()
        .transition(.asymmetric(insertion: ..., removal: ...))
}
```

Le transizioni sono asimmetriche:
- **Login → Home**: `HomeView` scivola da destra
- **Home → Login**: `LoginView` appare in scala da centro

---

### 4.6 BiometricDemoApp

**File**: `BiometricDemoApp.swift`  
**Ruolo**: Entry point — crea il ViewModel e lo inietta nell'ambiente.

```swift
@State private var authViewModel = AuthViewModel()

var body: some Scene {
    WindowGroup {
        ContentView()
            .environment(authViewModel)
            .animation(.easeInOut(duration: 0.35), value: authViewModel.authState)
    }
}
```

> **Perché `@State` sull'App?** Con il macro `@Observable`, la proprietà deve essere `@State` per essere osservata correttamente da SwiftUI nel contesto App lifecycle. Senza `@State`, SwiftUI non traccerà le dipendenze.

---

## 5. Flusso di autenticazione

```
Apertura app
     │
     ▼
ContentView legge authState (.loggedOut)
     │
     ▼
LoginView appare
     │
     ▼ (dopo 600ms)
viewModel.authenticate()
     │
     ├─► LAContext.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics)
     │         │
     │    Face ID / Touch ID
     │         │
     │    ┌────┴────┐
     │  successo   fallimento
     │    │            │
     │    ▼            ├─ .userCancel → loggedOut (silenzioso)
     │  loggedIn       ├─ .biometryLockout → passcode fallback
     │    │            ├─ .biometryNotEnrolled → alert utente
     │    ▼            └─ altri → alert utente
     │ HomeView
     │
     └── (logout) → invalidate() → loggedOut → LoginView
```

---

## 6. Gestione degli errori

Tutti gli errori `LAError` vengono mappati al tipo `BiometricAuthError`:

| `LAError` | `BiometricAuthError` | Comportamento UI |
|-----------|---------------------|-----------------|
| `.authenticationFailed` | `.authenticationFailed` | Alert con messaggio + retry |
| `.userCancel` | `.userCancel` | Ritorno silenzioso al login |
| `.userFallback` | `.userFallback` | Escalation al passcode |
| `.systemCancel` | `.systemCancel` | Alert con messaggio |
| `.passcodeNotSet` | `.passcodeNotSet` | Alert + link alle Impostazioni |
| `.biometryNotAvailable` | `.biometryNotAvailable` | Pulsante disabilitato |
| `.biometryNotEnrolled` | `.biometryNotEnrolled` | Alert + link alle Impostazioni |
| `.biometryLockout` | `.biometryLockout` | Escalation automatica al passcode |

---

## 7. Concorrenza Swift 6

L'app è progettata per essere completamente compatibile con **Swift 6 strict concurrency**.

### Actor Isolation

| Componente | Isolation | Motivo |
|------------|-----------|--------|
| `BiometricAuthManager` | `@MainActor` | Accede a `LAContext` e proprietà di stato |
| `AuthViewModel` | `@MainActor` | Aggiorna proprietà `@Observable` usate dalla UI |
| `LoginView`, `HomeView`, `ContentView` | `@MainActor` (implicito SwiftUI) | Viste SwiftUI |

### `nonisolated static`

Il metodo `mapError` in `BiometricAuthManager` è dichiarato `nonisolated static` perché:
- La closure della `withCheckedThrowingContinuation` è `@Sendable`
- Viene eseguita su una coda privata di `LocalAuthentication` (non su `@MainActor`)
- Il metodo lavora solo con tipi valore (`NSError?` → `BiometricAuthError`) quindi è thread-safe

### `@preconcurrency import LocalAuthentication`

Usato per sopprimere warning di Sendable su tipi `LAContext` non ancora completamente annotati nel SDK. Questo è il pattern raccomandato da Apple per framework legacy in transizione.

### `defer` per la pulizia dello stato

```swift
defer {
    isAuthenticating = false
}
```

Garantisce che `isAuthenticating` venga sempre reimpostato a `false`, anche in caso di errori o uscite anticipate, evitando stati inconsistenti nella UI.

---

## 8. Configurazione del progetto Xcode

### Permesso obbligatorio: NSFaceIDUsageDescription

Per usare Face ID, è **obbligatorio** aggiungere la chiave `NSFaceIDUsageDescription` nell'`Info.plist` del target. Senza questa chiave, l'app va in crash su dispositivi con Face ID.

**Metodo 1 — via Xcode (consigliato):**
1. Seleziona il target `BiometricDemo` nel Project Navigator
2. Scheda **Info**
3. Premi **+** sotto "Custom iOS Target Properties"
4. Aggiungi: `Privacy - Face ID Usage Description`
5. Valore: `"BiometricDemo uses Face ID to securely authenticate your identity."`

**Metodo 2 — via Info.plist (XML):**
```xml
<key>NSFaceIDUsageDescription</key>
<string>BiometricDemo uses Face ID to securely authenticate your identity.</string>
```

> **Nota**: `NSFaceIDUsageDescription` è richiesto **solo per Face ID**. Touch ID non richiede una chiave di privacy separata nell'Info.plist.

### Requisiti minimi

| Impostazione | Valore |
|-------------|--------|
| iOS Deployment Target | iOS 26.0+ |
| Swift Language Version | Swift 6 |
| Capabilities richieste | Nessuna aggiuntiva (LocalAuthentication è incluso) |

---

## 9. Best practices adottate

### 1. Nuovo LAContext per ogni autenticazione
```swift
// ✅ Crea un nuovo contesto ad ogni tentativo
let ctx = LAContext()
```
Riutilizzare lo stesso `LAContext` può portare a comportamenti indefiniti dopo un errore o un'invalidazione. Un contesto fresco garantisce uno stato pulito.

### 2. Invalidazione del contesto al logout
```swift
func invalidate() {
    context.invalidate()
    context = LAContext()
}
```
Chiamare `invalidate()` al logout impedisce che una sessione biometrica attiva venga riutilizzata, anche in scenari di race condition.

### 3. Gestione del blocco biometrico
Quando `LAError.biometryLockout` viene restituito (dopo 5 tentativi falliti su Face ID / 3 su Touch ID), l'app esegue automaticamente il fallback a `deviceOwnerAuthentication` che accetta il passcode, senza interrompere il flusso dell'utente.

### 4. Testo localizzabile per `localizedReason`
La stringa passata a `evaluatePolicy(_:localizedReason:)` viene mostrata direttamente all'utente nella finestra di dialogo del sistema. Deve essere:
- Chiara e specifica sul perché viene richiesta l'autenticazione
- Localizzata in produzione (usare `NSLocalizedString`)

### 5. Verifica preventiva con `canEvaluatePolicy`
Prima di chiamare `evaluatePolicy`, si verifica sempre la disponibilità con `canEvaluatePolicy`. Questo permette di:
- Disabilitare il pulsante di login se la biometria non è disponibile
- Fornire messaggi di errore specifici prima ancora di tentare l'autenticazione

### 6. Separazione tra biometria pura e fallback
L'app offre due percorsi distinti:
- `authenticate()` → **solo biometria** (più restrittivo)
- `authenticateWithFallback()` → **biometria + passcode** (più permissivo, usato come escalation)

Questo permette un controllo granulare sul livello di sicurezza richiesto.

---

## 10. Testing

### Unit Testing di BiometricAuthManager

Per testare `BiometricAuthManager` in isolamento, si consiglia di definire un protocollo:

```swift
protocol BiometricAuthenticating {
    var biometricType: BiometricType { get }
    var isBiometricAvailable: Bool { get }
    func authenticate(reason: String) async throws -> Bool
    func authenticateWithFallback(reason: String) async throws -> Bool
    func invalidate()
}

extension BiometricAuthManager: BiometricAuthenticating {}

// Mock per i test
final class MockBiometricAuthManager: BiometricAuthenticating {
    var shouldSucceed = true
    var errorToThrow: BiometricAuthError?
    // ...
}
```

### Test del ViewModel

```swift
@Test func testSuccessfulAuthentication() async throws {
    let mock = MockBiometricAuthManager()
    mock.shouldSucceed = true
    let vm = AuthViewModel(authManager: mock)
    
    await vm.authenticate()
    
    #expect(vm.authState == .loggedIn)
    #expect(vm.errorMessage == nil)
}
```

### Test su simulatore

Il simulatore iOS supporta la simulazione di Face ID/Touch ID:
- **Xcode → Features → Face ID → Enrolled** — abilita Face ID simulato
- **Xcode → Features → Face ID → Matching Face** — simula autenticazione riuscita
- **Xcode → Features → Face ID → Non-matching Face** — simula autenticazione fallita

---

## 11. Note di sicurezza

### Dati biometrici
I dati biometrici (template del volto, impronta digitale) sono gestiti **esclusivamente dal Secure Enclave** del dispositivo Apple. L'app **non ha mai accesso** ai dati biometrici grezzi: riceve solo un risultato booleano (`success/failure`) dalla valutazione della policy.

### Nessuna trasmissione di rete
L'autenticazione biometrica avviene interamente on-device. Nessun dato sensibile viene trasmesso a server esterni.

### Validità della sessione
Questa implementazione dimostrativa non implementa una scadenza della sessione. In un'app di produzione, si consiglia di:
- Invalidare il contesto dopo un timeout di inattività
- Richiedere nuova autenticazione dopo il ritorno in foreground
- Implementare un token di sessione lato server che scade

### Jailbreak detection
Su dispositivi con jailbreak, il Secure Enclave potrebbe essere compromesso. Per app ad alta criticità (banking, healthcare) si raccomanda di integrare meccanismi di rilevamento del jailbreak (es. tramite `DeviceCheck` o `App Attest`).

---

*Documentazione generata il 22 giugno 2026 — BiometricDemo v1.0*
