//
//  SecDemoTests.swift
//  SecDemoTests
//
//  Created by Antonio Minelli on 24/06/2026.
//

import Testing
@testable import SecDemo

struct SecDemoTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
        // Swift Testing Documentation
        // https://developer.apple.com/documentation/testing
    }

}
