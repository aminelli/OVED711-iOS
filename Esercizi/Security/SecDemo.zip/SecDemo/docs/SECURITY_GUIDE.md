# SecDemo — Guida alla Sicurezza iOS

Documentazione tecnica completa del progetto **SecDemo** (iOS 26 · Swift 6.3).  
Copre i tre pilastri della sicurezza applicativa iOS dimostrati nell'app.

---

## Indice

- [SecDemo — Guida alla Sicurezza iOS](#secdemo--guida-alla-sicurezza-ios)
  - [Indice](#indice)
  - [1. CryptoKit — Primitivi Crittografici](#1-cryptokit--primitivi-crittografici)
    - [1.1 AES-GCM — Cifratura Simmetrica AEAD](#11-aes-gcm--cifratura-simmetrica-aead)
      - [Proprietà di sicurezza](#proprietà-di-sicurezza)
      - [Utilizzo in SecDemo](#utilizzo-in-secdemo)
      - [Gestione del SealedBox](#gestione-del-sealedbox)
    - [1.2 Curve25519 — ECDH e Scambio Chiave](#12-curve25519--ecdh-e-scambio-chiave)
      - [Proprietà della curva](#proprietà-della-curva)
      - [Protocollo ECDH](#protocollo-ecdh)
      - [Utilizzo in SecDemo](#utilizzo-in-secdemo-1)
    - [1.3 HKDF — Derivazione Chiavi](#13-hkdf--derivazione-chiavi)
      - [Struttura in due fasi](#struttura-in-due-fasi)
      - [Parametri](#parametri)
      - [Utilizzo in SecDemo](#utilizzo-in-secdemo-2)
    - [1.4 Hashing e HMAC](#14-hashing-e-hmac)
      - [Funzioni Hash SHA-2](#funzioni-hash-sha-2)
      - [HMAC (Hash-based Message Authentication Code)](#hmac-hash-based-message-authentication-code)
  - [2. Keychain \& Secure Enclave](#2-keychain--secure-enclave)
    - [2.1 Classi di Item Keychain](#21-classi-di-item-keychain)
      - [Operazioni CRUD](#operazioni-crud)
    - [2.2 Attributi di Accessibilità (`kSecAttrAccessible*`)](#22-attributi-di-accessibilità-ksecattraccessible)
    - [2.3 Access Control con Biometria](#23-access-control-con-biometria)
      - [Flag disponibili](#flag-disponibili)
      - [LAContext — personalizzazione del prompt](#lacontext--personalizzazione-del-prompt)
    - [2.4 Secure Enclave](#24-secure-enclave)
      - [Generazione chiave P-256 nel Secure Enclave](#generazione-chiave-p-256-nel-secure-enclave)
      - [Operazioni supportate](#operazioni-supportate)
      - [Firma e verifica](#firma-e-verifica)
    - [2.5 App Group Keychain Sharing](#25-app-group-keychain-sharing)
  - [3. SSL Pinning \& App Hardening](#3-ssl-pinning--app-hardening)
    - [3.1 Certificate Pinning vs Public Key Pinning](#31-certificate-pinning-vs-public-key-pinning)
      - [Confronto](#confronto)
      - [Come generare l'hash SPKI per Public Key Pinning](#come-generare-lhash-spki-per-public-key-pinning)
    - [3.2 Flusso URLSessionDelegate Challenge](#32-flusso-urlsessiondelegate-challenge)
      - [Implementazione del delegato](#implementazione-del-delegato)
    - [3.3 App Transport Security (ATS)](#33-app-transport-security-ats)
      - [Requisiti ATS di default](#requisiti-ats-di-default)
      - [Configurazione Info.plist](#configurazione-infoplist)
      - [Requisiti per Face ID (Info.plist)](#requisiti-per-face-id-infoplist)
  - [4. File del Progetto](#4-file-del-progetto)
  - [5. Configurazione Xcode](#5-configurazione-xcode)
    - [Capabilities richieste per la demo completa](#capabilities-richieste-per-la-demo-completa)
    - [Note sul Secure Enclave](#note-sul-secure-enclave)
    - [Certificato per Certificate Pinning](#certificato-per-certificate-pinning)
  - [6. Riferimenti](#6-riferimenti)
    - [Documentazione Apple Ufficiale](#documentazione-apple-ufficiale)
    - [Standard e RFC](#standard-e-rfc)
    - [OWASP Mobile](#owasp-mobile)

---

## 1. CryptoKit — Primitivi Crittografici

**Apple CryptoKit** (introdotto in iOS 13) è il framework Swift per operazioni crittografiche di alto livello. Espone primitivi standardizzati e sicuri, eliminando la necessità di usare direttamente CommonCrypto o librerie di terze parti.

Vantaggi rispetto a CommonCrypto:
- API Swift nativa, type-safe
- Integrazione con Secure Enclave
- Resistenza agli errori di implementazione (nessun padding manuale, nonce automatici, ecc.)
- Constant-time comparison per prevenire timing attacks

---

### 1.1 AES-GCM — Cifratura Simmetrica AEAD

**AES-GCM** (Advanced Encryption Standard — Galois/Counter Mode) è la modalità di cifratura raccomandata per dati a riposo e in transito. È una cifratura **AEAD** (Authenticated Encryption with Associated Data).

#### Proprietà di sicurezza

| Proprietà | Dettaglio |
|-----------|-----------|
| **Riservatezza** | Il testo è cifrato con AES in modalità CTR (stream cipher) |
| **Integrità** | Un authentication tag a 128 bit (GHASH) verifica che il ciphertext non sia stato modificato |
| **Autenticità** | Il tag garantisce che il messaggio provenga da chi possiede la chiave |
| **Dimensione chiave** | 128, 192 o 256 bit (consigliato: 256 bit) |
| **Nonce** | 96 bit (12 byte), DEVE essere univoco per ogni cifratura con la stessa chiave |

> ⚠️ **Attenzione critica al nonce**: riutilizzare lo stesso nonce con la stessa chiave causa il completo collasso della sicurezza (possibile recupero del keystream e della chiave).

#### Utilizzo in SecDemo

```swift
// 1. Genera chiave AES-256 tramite CSPRNG
let key = SymmetricKey(size: .bits256)

// 2. Genera nonce casuale (96 bit)
let nonce = try AES.GCM.Nonce()

// 3. Cifra: produce SealedBox = nonce (12B) + ciphertext + tag (16B)
let sealedBox = try AES.GCM.seal(plaintextData, using: key, nonce: nonce)

// 4. Decifra: verifica il tag PRIMA di decifrare
let decryptedData = try AES.GCM.open(sealedBox, using: key)
// → CryptoKitError.authenticationFailure se il tag non corrisponde
```

#### Gestione del SealedBox

Il `SealedBox` può essere serializzato in tre formati:
- **combined**: `nonce (12B) || ciphertext || tag (16B)` — unico `Data` per la trasmissione
- **componenti separati**: utile per protocolli che trasmettono nonce, ciphertext e tag separatamente

---

### 1.2 Curve25519 — ECDH e Scambio Chiave

**Curve25519** è una curva ellittica di Montgomery progettata da Daniel J. Bernstein. L'algoritmo **X25519** implementa Elliptic Curve Diffie-Hellman (ECDH) su questa curva.

#### Proprietà della curva

| Proprietà | Valore |
|-----------|--------|
| **Equazione** | y² = x³ + 486662x² + x su GF(2²⁵⁵ - 19) |
| **Sicurezza effettiva** | ~128 bit (equivalente ad AES-128) |
| **Resistenza side-channel** | Alta (operazioni a tempo costante) |
| **Chiave privata** | Scalare random a 256 bit |
| **Chiave pubblica** | Coordinata x del punto su curva (32 byte) |

#### Protocollo ECDH

```
Alice:                              Bob:
privA, pubA = KeyGen()              privB, pubB = KeyGen()
                                    
pubA ──────────────────────────→
←────────────────────────────── pubB

secret_A = X25519(privA, pubB)      secret_B = X25519(privB, pubA)
                                    
secret_A == secret_B  ✓  (proprietà matematica del DH)
```

#### Utilizzo in SecDemo

```swift
// Generazione coppia di chiavi
let alicePrivate = Curve25519.KeyAgreement.PrivateKey()
let alicePublic = alicePrivate.publicKey  // trasmissibile in chiaro

// Scambio di chiavi
let sharedSecret = try alicePrivate.sharedSecretFromKeyAgreement(with: bobPublic)

// Il SharedSecret NON è estraibile direttamente: usare HKDF per derivare una chiave
let sessionKey = sharedSecret.hkdfDerivedSymmetricKey(
    using: SHA256.self,
    salt: saltData,
    sharedInfo: infoData,
    outputByteCount: 32
)
```

> **CryptoKit** offre anche `P256.KeyAgreement`, `P384.KeyAgreement` e `P521.KeyAgreement` per le curve NIST, ma Curve25519 è la scelta preferita per nuovi protocolli.

---

### 1.3 HKDF — Derivazione Chiavi

**HKDF** (HMAC-based Key Derivation Function, RFC 5869) è la funzione di derivazione chiavi raccomandata per trasformare materiale grezzo (es: SharedSecret ECDH) in chiavi pronte all'uso.

#### Struttura in due fasi

```
IKM (Input Key Material)
    │
    ▼
┌─────────────────────────────────┐
│  FASE EXTRACT                   │
│  PRK = HMAC-Hash(salt, IKM)     │  → Pseudorandom Key (32 byte con SHA-256)
└─────────────────────────────────┘
    │ PRK
    ▼
┌─────────────────────────────────┐
│  FASE EXPAND                    │
│  T(1) = HMAC-Hash(PRK, info||1) │
│  T(2) = HMAC-Hash(PRK, T(1)||info||2)  │  → Output Key Material (OKM)
│  ...                            │
└─────────────────────────────────┘
    │
    ▼
  OKM (chiave derivata pronta all'uso)
```

#### Parametri

| Parametro | Ruolo | Note |
|-----------|-------|-------|
| **IKM** | Input grezzo | Es: SharedSecret ECDH, password utente |
| **salt** | Randomizzazione | Non segreto; migliora uniformità. Se omesso, usa zero-string |
| **info** | Contesto/Scopo | Distingue chiavi diverse. Es: `"enc"` vs `"mac"` |
| **outputByteCount** | Lunghezza output | Max 255 × len(Hash). 32 byte per AES-256 |

#### Utilizzo in SecDemo

```swift
let derivedKey = HKDF<SHA256>.deriveKey(
    inputKeyMaterial: SymmetricKey(data: sharedSecret),
    salt: saltData,                          // random, non segreto
    info: "SecDemo-Encryption-v1".data(using: .utf8)!,
    outputByteCount: 32                      // AES-256
)
```

---

### 1.4 Hashing e HMAC

#### Funzioni Hash SHA-2

| Algoritmo | Output | Utilizzi |
|-----------|--------|---------|
| **SHA-256** | 32 byte | Uso generale, certificati, firma digitale |
| **SHA-384** | 48 byte | TLS 1.3, protezione intermedie |
| **SHA-512** | 64 byte | Massima sicurezza, ottimale su CPU 64-bit |

```swift
let digest = SHA256.hash(data: messageData)
// Digest è Sequence<UInt8>; per Data: Data(digest)
```

#### HMAC (Hash-based Message Authentication Code)

L'HMAC combina una chiave segreta con una funzione hash per fornire sia **integrità** che **autenticità** del messaggio.

```
HMAC(K, m) = H( (K ⊕ opad) || H( (K ⊕ ipad) || m ) )
```

**Proprietà di sicurezza:**
- Resistente a forgery senza la chiave segreta
- Usa constant-time comparison (`HMAC.isValidAuthenticationCode`) per prevenire timing attacks
- Diverso da una firma digitale: richiede che entrambe le parti condividano la stessa chiave

```swift
let hmacKey = SymmetricKey(size: .bits256)
let code = HMAC<SHA256>.authenticationCode(for: data, using: hmacKey)

// Verifica con constant-time comparison
let isValid = HMAC<SHA256>.isValidAuthenticationCode(code, authenticating: data, using: hmacKey)
```

---

## 2. Keychain & Secure Enclave

Il **Keychain** di iOS è un database cifrato a livello di sistema che sopravvive alle reinstallazioni dell'app (su iOS), sincronizzabile tramite iCloud Keychain.

**Architettura di sicurezza:**
- I dati nel Keychain sono cifrati con chiavi derivate dal passcode del dispositivo e dall'hardware
- Il Secure Enclave gestisce le chiavi di cifratura del Keychain nelle classi ThisDeviceOnly
- L'accesso è controllato da Access Control Lists (ACL) definiti dagli attributi dell'item

---

### 2.1 Classi di Item Keychain

| Classe | Costante | Identificatori | Utilizzo tipico |
|--------|----------|---------------|-----------------|
| **Generic Password** | `kSecClassGenericPassword` | service + account | Credenziali app, token API |
| **Internet Password** | `kSecClassInternetPassword` | server + port + protocol + account | Credenziali web |
| **Certificate** | `kSecClassCertificate` | issuer + serial number | Certificati X.509 |
| **Key** | `kSecClassKey` | application tag + key type | Chiavi crittografiche |
| **Identity** | `kSecClassIdentity` | cert + private key | Client TLS |

#### Operazioni CRUD

```swift
// CREATE
SecItemAdd(attributes as CFDictionary, nil)

// READ
SecItemCopyMatching(query as CFDictionary, &result)

// UPDATE (preferibile a delete+add: mantiene gli altri attributi)
SecItemUpdate(query as CFDictionary, attributesToUpdate as CFDictionary)

// DELETE
SecItemDelete(query as CFDictionary)
```

---

### 2.2 Attributi di Accessibilità (`kSecAttrAccessible*`)

L'attributo `kSecAttrAccessible` definisce **quando** un item può essere letto.

| Costante | Accessibile | Backup | Consigliato per |
|----------|-------------|--------|----------------|
| `kSecAttrAccessibleWhenUnlocked` | Dispositivo sbloccato | ✓ iCloud | Uso generico con backup |
| `kSecAttrAccessibleWhenUnlockedThisDeviceOnly` | Dispositivo sbloccato | ✗ | **Dati sensibili** — default consigliato |
| `kSecAttrAccessibleAfterFirstUnlock` | Dal primo sblocco post-riavvio | ✓ | Background refresh |
| `kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly` | Dal primo sblocco | ✗ | Background, senza backup |
| `kSecAttrAccessibleWhenPasscodeSetThisDeviceOnly` | Sbloccato + passcode attivo | ✗ | App bancarie e sanitarie |
| `kSecAttrAccessibleAlways` ⚠️ | Sempre (anche da bloccato) | ✓ | **Da evitare** |

> ⚠️ `kSecAttrAccessibleAlways` e `kSecAttrAccessibleAlwaysThisDeviceOnly` sono **deprecati** da iOS 12. Non usarli per dati sensibili.

**Regola pratica:**
- Se l'app non necessita di background processing → `WhenUnlockedThisDeviceOnly`
- Se l'app ha background fetch/push notifications → `AfterFirstUnlockThisDeviceOnly`
- Per massima sicurezza (banking, health) → `WhenPasscodeSetThisDeviceOnly`

---

### 2.3 Access Control con Biometria

`SecAccessControl` permette di associare politiche di autenticazione agli item Keychain.

#### Flag disponibili

| Flag | Comportamento |
|------|--------------|
| `.biometryAny` | Face ID o Touch ID (qualsiasi biometria registrata). L'item rimane valido se si aggiungono nuove impronte. |
| `.biometryCurrentSet` | Solo la biometria attualmente registrata. L'item diventa inaccessibile se si aggiunge una nuova biometria. Più sicuro per app bancarie. |
| `.userPresence` | Biometria o passcode (fallback automatico). |
| `.devicePasscode` | Solo passcode, nessuna biometria. |
| `.applicationPassword` | Password applicativa aggiuntiva (oltre alla biometria). |
| `.privateKeyUsage` | Obbligatorio per chiavi Secure Enclave. |

```swift
var error: Unmanaged<CFError>?
let accessControl = SecAccessControlCreateWithFlags(
    kCFAllocatorDefault,
    kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
    [.biometryAny],    // oppure .biometryCurrentSet per massima sicurezza
    &error
)!
```

#### LAContext — personalizzazione del prompt

```swift
let context = LAContext()
context.localizedReason = "Autenticati per accedere ai dati sensibili"
// Opzionale: riusa l'autenticazione per N secondi (default: 0)
context.touchIDAuthenticationAllowableReuseDuration = 5.0

// Passa il context alla query Keychain
let query: [CFString: Any] = [
    ...
    kSecUseAuthenticationContext: context
]
```

---

### 2.4 Secure Enclave

Il **Secure Enclave** è un coprocessore sicuro dedicato presente nei chip Apple A7+.

**Caratteristiche hardware:**
- Memoria isolata dal processore principale
- Canale di comunicazione cifrato con il Touch/Face ID sensor
- Esegue il proprio microkernel separato da iOS
- Le chiavi private non possono **mai** essere estratte, nemmeno con accesso root

**Dispositivi supportati:**
- iPhone 5S e successivi
- iPad Air (1ª gen), iPad mini 2 e successivi
- Apple Watch (tutte le generazioni)
- Mac con chip T1, T2, M1, M2, M3, M4

#### Generazione chiave P-256 nel Secure Enclave

```swift
// Verifica disponibilità (false su simulatore)
guard SecureEnclave.isAvailable else { return }

// Crea access control per la chiave
let accessControl = SecAccessControlCreateWithFlags(
    kCFAllocatorDefault,
    kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
    [.privateKeyUsage, .biometryAny],
    &error
)!

// Genera la chiave nel Secure Enclave
let privateKey = try SecureEnclave.P256.Signing.PrivateKey(
    accessControl: accessControl
)

// dataRepresentation: token opaco (NON la chiave privata in chiaro!)
// Salvare nel Keychain per riutilizzo futuro
let keyReference = privateKey.dataRepresentation
```

#### Operazioni supportate

| Operazione | Tipo CryptoKit |
|-----------|---------------|
| **Firma ECDSA** | `SecureEnclave.P256.Signing.PrivateKey` |
| **Key Agreement (ECDH)** | `SecureEnclave.P256.KeyAgreement.PrivateKey` |

#### Firma e verifica

```swift
// Firma (richiede biometria se configurata)
let signature = try privateKey.signature(for: messageData)
// → DER-encoded ECDSA-P256 signature

// Verifica (fuori dal Secure Enclave, con chiave pubblica)
let isValid = privateKey.publicKey.isValidSignature(signature, for: messageData)
```

---

### 2.5 App Group Keychain Sharing

L'attributo `kSecAttrAccessGroup` permette a più app dello stesso team di condividere item nel Keychain.

**Prerequisiti in Xcode:**
1. Abilitare **Keychain Sharing** in Target → Signing & Capabilities
2. Aggiungere il gruppo: es. `group.com.secdemo.shared`
3. Stesso **provisioning profile** per tutte le app del gruppo

**Formato dell'access group:**
- `<team_id>.<bundle_seed_id>` — condivisione standard tra app
- `group.<nome_gruppo>` — App Groups (richiede App Groups capability separata)

```swift
let query: [CFString: Any] = [
    kSecClass:           kSecClassGenericPassword,
    kSecAttrService:     "com.secdemo.shared",
    kSecAttrAccount:     "shared-token",
    kSecValueData:       tokenData,
    kSecAttrAccessGroup: "group.com.secdemo.shared",  // <-- condivisione
    kSecAttrAccessible:  kSecAttrAccessibleWhenUnlockedThisDeviceOnly
]
```

---

## 3. SSL Pinning & App Hardening

### 3.1 Certificate Pinning vs Public Key Pinning

**Problema:** Un attaccante con un certificato valido (emesso da una CA compromessa o installata sul dispositivo) può intercettare il traffico HTTPS.

**Soluzione:** L'app incorpora il materiale crittografico del server legittimo e lo verifica ad ogni connessione.

#### Confronto

| | Certificate Pinning | Public Key Pinning |
|-|--------------------|--------------------|
| **Cosa si pinna** | Certificato DER completo | Hash SHA-256 della chiave pubblica |
| **Sicurezza** | ⭐⭐⭐ Massima | ⭐⭐ Alta |
| **Rinnovo certificato** | Richiede aggiornamento app | ✓ Sopravvive se la chiave rimane uguale |
| **Cambio chiave** | Richiede aggiornamento app | Richiede aggiornamento app |
| **Complessità** | Bassa | Media |
| **Consigliato per** | Ambienti controllati, certificati a lunga durata | Applicazioni con rinnovi frequenti |

#### Come generare l'hash SPKI per Public Key Pinning

```bash
# 1. Scarica il certificato del server
openssl s_client -connect api.example.com:443 </dev/null 2>/dev/null \
  | openssl x509 -outform DER -out server.der

# 2. Estrai la chiave pubblica in formato DER e calcola l'hash SHA-256
openssl x509 -inform DER -in server.der -pubkey -noout \
  | openssl pkey -pubin -outform DER \
  | openssl dgst -sha256 -binary \
  | openssl base64

# Output (esempio): rMKvjSXpRlwEBVT0V0M8i0F3LQn3LAF8L/3UVzUgV0k=
```

**Best practice:** Includi sempre **almeno 2 hash** (certificato corrente + backup per il prossimo rinnovo) per evitare denial-of-service se il certificato primario scade inaspettatamente.

---

### 3.2 Flusso URLSessionDelegate Challenge

```
Client                    URLSession              Server
  │                           │                      │
  │─── GET https://... ───────►│                      │
  │                           │──── TCP SYN ─────────►│
  │                           │◄─── TLS ServerHello ──│
  │                           │   (certificato TLS)   │
  │                           │                       │
  │◄── urlSession(_:didReceive challenge:) ────────────│
  │    [authMethod = NSURLAuthenticationMethodServerTrust]
  │                           │                       │
  │  1. SecTrustEvaluateWithError()  ← validazione CA │
  │  2. pinning check               ← logica custom   │
  │  3. completionHandler(...)                        │
  │     • .useCredential    → connessione accettata   │
  │     • .cancelAuthChallenge → connessione rifiutata│
  │                           │                       │
  │◄── risposta HTTP ─────────│◄──────────────────────│
```

#### Implementazione del delegato

```swift
final class PinningDelegate: NSObject, URLSessionDelegate, @unchecked Sendable {

    func urlSession(
        _ session: URLSession,
        didReceive challenge: URLAuthenticationChallenge,
        completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void
    ) {
        guard challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust,
              let serverTrust = challenge.protectionSpace.serverTrust else {
            completionHandler(.performDefaultHandling, nil)
            return
        }

        // PASSO 1: Valida CA (NON saltare mai questo passo!)
        var cfError: CFError?
        guard SecTrustEvaluateWithError(serverTrust, &cfError) else {
            completionHandler(.cancelAuthenticationChallenge, nil)
            return
        }

        // PASSO 2: Applica pinning custom
        let isPinned = verifyPublicKeyPinning(serverTrust)

        if isPinned {
            completionHandler(.useCredential, URLCredential(trust: serverTrust))
        } else {
            // Loggare in produzione per rilevare attacchi MITM
            completionHandler(.cancelAuthenticationChallenge, nil)
        }
    }
}
```

---

### 3.3 App Transport Security (ATS)

**ATS** è il framework di sicurezza di rete di iOS, attivo per default da iOS 9. Impone requisiti minimi per tutte le connessioni di rete.

#### Requisiti ATS di default

| Requisito | Valore |
|-----------|--------|
| Protocollo | HTTPS obbligatoria (HTTP bloccata) |
| Versione TLS | Minimo TLS 1.2 (TLS 1.3 preferito da iOS 13) |
| Forward Secrecy | ECDHE obbligatoria |
| Certificati | SHA-256 minimo; RSA ≥2048 bit o ECC ≥256 bit |
| SHA-1 | Rifiutato |

#### Configurazione Info.plist

```xml
<key>NSAppTransportSecurity</key>
<dict>
    <!-- Eccezione per un dominio specifico (es: API interna) -->
    <key>NSExceptionDomains</key>
    <dict>
        <key>api.internal.example.com</key>
        <dict>
            <!-- Permettere TLS 1.0 per server legacy (sconsigliato) -->
            <key>NSExceptionMinimumTLSVersion</key>
            <string>TLSv1.2</string>
            <!-- Includere sotto-domini -->
            <key>NSIncludesSubdomains</key>
            <true/>
        </dict>
    </dict>
    
    <!-- ⚠️ MAI in produzione: disabilita ATS per tutti i domini -->
    <!-- <key>NSAllowsArbitraryLoads</key><true/> -->
</dict>
```

> ⚠️ `NSAllowsArbitraryLoads: true` **disabilita completamente ATS** e richiede giustificazione obbligatoria in fase di App Store Review. Non usarlo in produzione.

#### Requisiti per Face ID (Info.plist)

Per usare la biometria con il Keychain, è obbligatorio dichiarare l'utilizzo:

```xml
<key>NSFaceIDUsageDescription</key>
<string>Autenticazione con Face ID per proteggere i tuoi dati sensibili</string>
```

---

## 4. File del Progetto

```
SecDemo/
├── SecDemoApp.swift              # Entry point dell'app
├── ContentView.swift             # Hub di navigazione principale
│
├── CryptoKitManager.swift        # Manager operazioni CryptoKit
│   └── Primitivi: AES-GCM, Curve25519, HKDF, SHA-2, HMAC
│
├── CryptoKitDemoView.swift       # UI interattiva CryptoKit
│
├── KeychainManager.swift         # Manager Keychain & Secure Enclave
│   └── Generic/Internet Password, Biometria, SE, App Group
│
├── KeychainDemoView.swift        # UI interattiva Keychain
│
├── SSLPinningManager.swift       # Manager SSL Pinning
│   └── URLSessionDelegate, Certificate Pinning, Public Key Pinning
│
├── SSLPinningDemoView.swift      # UI interattiva SSL Pinning
│
└── Assets.xcassets/              # Risorse grafiche
```

---

## 5. Configurazione Xcode

### Capabilities richieste per la demo completa

| Capability | Necessaria per | Configurazione |
|------------|---------------|----------------|
| **Face ID** | Biometric Keychain | `NSFaceIDUsageDescription` in Info.plist |
| **Keychain Sharing** | App Group Keychain | Target → Signing & Capabilities |
| **App Groups** | `group.com.secdemo.shared` | Target → Signing & Capabilities |

### Note sul Secure Enclave

- Il Secure Enclave **non è disponibile sul simulatore**. Le operazioni SE restituiscono `SecureEnclave.isAvailable == false`.
- Per testare la biometria sul simulatore: Simulator → Features → Face ID → Enrolled
- Per testare il Secure Enclave, è necessario un dispositivo fisico con iOS 26.

### Certificato per Certificate Pinning

Per testare il Certificate Pinning:
1. Esporta il certificato DER del server: `openssl s_client -connect host:443 </dev/null | openssl x509 -outform DER -out server_cert.der`
2. Trascina `server_cert.der` nel Project Navigator di Xcode
3. Assicurati che sia incluso in "Copy Bundle Resources" del target

---

## 6. Riferimenti

### Documentazione Apple Ufficiale

- [CryptoKit](https://developer.apple.com/documentation/cryptokit) — Framework crittografia Swift
- [Keychain Services](https://developer.apple.com/documentation/security/keychain_services) — API portachiavi
- [Secure Enclave](https://developer.apple.com/documentation/cryptokit/secureenclave) — Coprocessore sicuro
- [LocalAuthentication](https://developer.apple.com/documentation/localauthentication) — Biometria
- [App Transport Security](https://developer.apple.com/documentation/security/preventing_insecure_network_connections) — ATS

### Standard e RFC

- [RFC 5869](https://tools.ietf.org/html/rfc5869) — HKDF
- [RFC 2104](https://tools.ietf.org/html/rfc2104) — HMAC
- [RFC 7748](https://tools.ietf.org/html/rfc7748) — Curve25519 (X25519)
- [NIST FIPS 197](https://nvlpubs.nist.gov/nistpubs/FIPS/NIST.FIPS.197.pdf) — AES
- [NIST SP 800-38D](https://nvlpubs.nist.gov/nistpubs/Legacy/SP/nistspecialpublication800-38d.pdf) — AES-GCM

### OWASP Mobile

- [OWASP Mobile Top 10](https://owasp.org/www-project-mobile-top-10/)
- [MASVS — Mobile Application Security Verification Standard](https://mobile-security.gitbook.io/masvs/)
- [Cryptography](https://mobile-security.gitbook.io/mobile-security-testing-guide/ios-testing-guide/0x06e-testing-cryptography) — iOS Testing Guide


