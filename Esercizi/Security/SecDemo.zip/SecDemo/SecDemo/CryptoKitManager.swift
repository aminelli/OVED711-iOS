//
//  CryptoKitManager.swift
//  SecDemo
//
//  Created by Antonio Minelli on 24/06/2026.
//
//  Dimostra l'uso avanzato di CryptoKit su iOS 26 / Swift 6.3:
//  - AES-GCM: cifratura simmetrica autenticata (AEAD)
//  - Curve25519: scambio chiavi Diffie-Hellman su curva ellittica
//  - HKDF: derivazione deterministiche di chiavi da materiale grezzo
//  - SHA-2 e HMAC: hashing crittografico e autenticazione dei messaggi

import Foundation
import CryptoKit

// MARK: - Modelli di risultato

/// Risultato di una cifratura AES-GCM.
/// Tutti i campi sono `Data` per garantire la conformità a `Sendable`.
struct AESEncryptionResult: Sendable {
    /// Testo cifrato (senza nonce e tag)
    let ciphertext: Data
    /// Nonce a 96 bit usato per la cifratura (NON riutilizzare con la stessa chiave!)
    let nonceData: Data
    /// Authentication tag a 128 bit (verifica integrità e autenticità)
    let tag: Data
    /// Chiave simmetrica AES-256 serializzata (in un'app reale non va mai salvata in chiaro)
    let keyData: Data
}

/// Risultato di uno scambio di chiavi Curve25519 (X25519 ECDH)
struct ECDHResult: Sendable {
    /// Chiave pubblica di Alice in formato raw X9.63 (32 byte)
    let alicePublicKeyData: Data
    /// Chiave pubblica di Bob in formato raw X9.63 (32 byte)
    let bobPublicKeyData: Data
    /// Segreto condiviso calcolato da entrambe le parti (identico per Alice e Bob)
    let sharedSecret: Data
}

/// Risultato della derivazione HKDF
struct HKDFResult: Sendable {
    /// Materiale chiave di input (IKM) — grezzo, non ancora utilizzabile direttamente
    let inputKeyMaterial: Data
    /// Chiave derivata pronta all'uso (AES-256 in questo esempio)
    let derivedKeyData: Data
    /// Sale crittografico (randomico, non segreto, migliora la sicurezza)
    let salt: Data
    /// Informazione di contesto (distingue chiavi derivate per scopi diversi)
    let info: Data
}

/// Risultato degli hash e HMAC calcolati su un messaggio
struct HashResult: Sendable {
    let sha256: String
    let sha384: String
    let sha512: String
    let hmacSHA256: String
    let hmacSHA384: String
    let hmacSHA512: String
    /// Chiave HMAC usata per il calcolo (in un'app reale va protetta nel Keychain)
    let hmacKeyHex: String
    /// Conferma che la verifica HMAC-SHA256 è andata a buon fine
    let hmacVerified: Bool
}

// MARK: - CryptoKitManager

/// Manager principale per tutte le operazioni crittografiche con Apple CryptoKit.
///
/// Ogni metodo è progettato per illustrare chiaramente un primitivo crittografico,
/// con commenti che spiegano le scelte di design e le best practice.
///
/// - Note: La classe è `@MainActor` e `@Observable` per integrazione diretta con SwiftUI.
@MainActor
@Observable
final class CryptoKitManager {

    // MARK: - Stato osservabile (letto direttamente dalle SwiftUI View)

    var aesResult: AESEncryptionResult?
    var aesDecryptedText: String?
    var ecdhResult: ECDHResult?
    var hkdfResult: HKDFResult?
    var hashResult: HashResult?
    var errorMessage: String?
    var isProcessing: Bool = false

    // MARK: - AES-GCM (Cifratura Simmetrica AEAD)

    /// Cifra un testo in chiaro con AES-256-GCM.
    ///
    /// **AES-GCM** (Advanced Encryption Standard - Galois/Counter Mode) è una
    /// modalità di cifratura **AEAD** (Authenticated Encryption with Associated Data):
    ///
    /// - **Riservatezza**: il testo viene cifrato con AES in modalità CTR
    /// - **Integrità e Autenticità**: un authentication tag a 128 bit (calcolato con GHASH)
    ///   garantisce che il ciphertext non sia stato manomesso
    ///
    /// Parametri fondamentali:
    /// - **Chiave**: 256 bit generati con SecRandomCopyBytes (CSPRNG)
    /// - **Nonce**: 96 bit casuali, DEVE essere univoco per ogni cifratura con la stessa chiave.
    ///   Riutilizzare il nonce causa il completo collasso della sicurezza (key stream reuse).
    ///
    /// - Parameter plaintext: Il testo in chiaro da cifrare
    func encryptWithAESGCM(plaintext: String) {
        isProcessing = true
        errorMessage = nil

        Task {
            do {
                // Genera una chiave simmetrica AES-256 usando il CSPRNG del sistema.
                // SymmetricKey usa internamente SecRandomCopyBytes — mai usare Random o arc4random.
                let key = SymmetricKey(size: .bits256)

                // Genera un nonce casuale di 96 bit (12 byte).
                // In GCM, un nonce di 96 bit consente fino a 2^32 cifrature per chiave.
                // Superato questo limite, la chiave va ruotata.
                let nonce = try AES.GCM.Nonce()

                guard let plaintextData = plaintext.data(using: .utf8) else {
                    self.errorMessage = "Impossibile convertire il testo in UTF-8"
                    self.isProcessing = false
                    return
                }

                // AES.GCM.seal() cifra e autentica il messaggio in un unico passaggio.
                // Il SealedBox contiene: nonce (12B) + ciphertext (nB) + tag (16B)
                let sealedBox = try AES.GCM.seal(plaintextData, using: key, nonce: nonce)

                // Serializza i componenti come Data per poterli passare tra task/thread.
                // In produzione: chiave e nonce non vanno mai trasmessi insieme al ciphertext!
                let nonceData = Data(nonce)
                let keyData = key.withUnsafeBytes { Data($0) }

                self.aesResult = AESEncryptionResult(
                    ciphertext: sealedBox.ciphertext,
                    nonceData: nonceData,
                    tag: sealedBox.tag,
                    keyData: keyData
                )
                self.aesDecryptedText = nil
                self.isProcessing = false
            } catch {
                self.errorMessage = "Errore AES-GCM encrypt: \(error.localizedDescription)"
                self.isProcessing = false
            }
        }
    }

    /// Decifra un messaggio cifrato con AES-256-GCM, verificando l'authentication tag.
    ///
    /// La verifica del tag avviene **prima** della decifratura (Encrypt-then-MAC semantics).
    /// Se il tag non corrisponde (ciphertext manomesso), viene lanciato
    /// `CryptoKitError.authenticationFailure` senza restituire alcun dato in chiaro.
    ///
    /// - Parameter result: Il risultato di una cifratura AES-GCM precedente
    func decryptWithAESGCM(result: AESEncryptionResult) {
        isProcessing = true
        errorMessage = nil

        Task {
            do {
                // Ricostruisce il nonce dai byte salvati
                let nonce = try AES.GCM.Nonce(data: result.nonceData)

                // Ricostruisce la chiave simmetrica
                let key = SymmetricKey(data: result.keyData)

                // Riassembla il SealedBox dai suoi componenti
                let sealedBox = try AES.GCM.SealedBox(
                    nonce: nonce,
                    ciphertext: result.ciphertext,
                    tag: result.tag
                )

                // AES.GCM.open() verifica il tag prima di decifrare.
                // Se il tag fallisce → CryptoKitError.authenticationFailure.
                // Questo protegge da padding oracle e altri attacchi sul ciphertext.
                let decryptedData = try AES.GCM.open(sealedBox, using: key)

                self.aesDecryptedText = String(data: decryptedData, encoding: .utf8)
                self.isProcessing = false
            } catch {
                // CryptoKitError.authenticationFailure → tag non valido → dati manomessi
                self.errorMessage = "Errore AES-GCM decrypt: \(error.localizedDescription)"
                self.isProcessing = false
            }
        }
    }

    // MARK: - Curve25519 (ECDH / X25519 Key Agreement)

    /// Dimostra lo scambio di chiavi Elliptic Curve Diffie-Hellman con Curve25519.
    ///
    /// **Curve25519** è la curva ellittica Montgomery y² = x³ + 486662x² + x su GF(2²⁵⁵-19).
    /// L'algoritmo **X25519** implementa ECDH su questa curva.
    ///
    /// Proprietà di sicurezza:
    /// - Sicurezza equivalente ad AES-128 (~128 bit di sicurezza effettiva)
    /// - Resistente ad attacchi side-channel (timing, cache)
    /// - Nessun parametro segreto: la curva è fissa e verificabile
    ///
    /// Protocollo simulato (Alice ↔ Bob):
    /// ```
    /// Alice:  privA, pubA = gen()          Bob: privB, pubB = gen()
    ///         pubA → Bob                        pubB → Alice
    ///         secret = X25519(privA, pubB)       secret = X25519(privB, pubA)
    ///         → secret uguale per entrambi!
    /// ```
    func performCurve25519ECDH() {
        isProcessing = true
        errorMessage = nil

        Task {
            do {
                // Genera la coppia di chiavi di Alice.
                // La chiave privata è sempre un scalare casuale a 256 bit.
                let alicePrivate = Curve25519.KeyAgreement.PrivateKey()
                let alicePublic = alicePrivate.publicKey

                // Genera la coppia di chiavi di Bob (indipendente da Alice)
                let bobPrivate = Curve25519.KeyAgreement.PrivateKey()
                let bobPublic = bobPrivate.publicKey

                // Alice calcola il segreto condiviso usando:
                // - la propria chiave PRIVATA
                // - la chiave PUBBLICA di Bob (ricevuta via canale insicuro)
                let aliceSharedSecret = try alicePrivate.sharedSecretFromKeyAgreement(
                    with: bobPublic
                )

                // Bob calcola lo stesso segreto condiviso usando:
                // - la propria chiave PRIVATA
                // - la chiave PUBBLICA di Alice (ricevuta via canale insicuro)
                let bobSharedSecret = try bobPrivate.sharedSecretFromKeyAgreement(
                    with: alicePublic
                )

                // Il SharedSecret non è estraibile direttamente come Data per ragioni di sicurezza.
                // Va derivato tramite HKDF o simili (mai usare il SharedSecret grezzo come chiave).
                let aliceSecretData = aliceSharedSecret.withUnsafeBytes { Data($0) }
                let bobSecretData = bobSharedSecret.withUnsafeBytes { Data($0) }

                // Verifica fondamentale del protocollo: i due segreti DEVONO coincidere
                guard aliceSecretData == bobSecretData else {
                    self.errorMessage = "Errore critico: i segreti ECDH non coincidono!"
                    self.isProcessing = false
                    return
                }

                self.ecdhResult = ECDHResult(
                    alicePublicKeyData: alicePublic.rawRepresentation,
                    bobPublicKeyData: bobPublic.rawRepresentation,
                    sharedSecret: aliceSecretData
                )
                self.isProcessing = false
            } catch {
                self.errorMessage = "Errore ECDH Curve25519: \(error.localizedDescription)"
                self.isProcessing = false
            }
        }
    }

    // MARK: - HKDF (Key Derivation Function)

    /// Deriva chiavi crittografiche robuste da materiale grezzo con HKDF.
    ///
    /// **HKDF** (RFC 5869) è una KDF basata su HMAC, composta da due fasi:
    ///
    /// **Fase 1 — Extract:**
    /// `PRK = HMAC-Hash(salt, IKM)`
    /// Condensa l'Input Key Material (IKM) in una Pseudorandom Key (PRK).
    /// Il sale migliora l'uniformità della distribuzione della PRK.
    ///
    /// **Fase 2 — Expand:**
    /// `OKM = T(1) || T(2) || ... dove T(i) = HMAC-Hash(PRK, T(i-1) || info || i)`
    /// Espande la PRK nella chiave di output desiderata.
    /// Il campo `info` distingue chiavi derivate per scopi diversi dallo stesso IKM.
    ///
    /// Utilizzi tipici:
    /// - Derivare chiavi di sessione dal segreto condiviso ECDH
    /// - Ottenere chiavi separate per cifratura e MAC da un'unica master key
    ///
    /// - Parameter inputKeyMaterial: Materiale grezzo da derivare (es: SharedSecret ECDH)
    func deriveKeyWithHKDF(inputKeyMaterial: Data) {
        isProcessing = true
        errorMessage = nil

        Task {
            // Sale: valore random non segreto. Migliora sicurezza contro attacchi pre-calcolati.
            // Può essere pubblico se condiviso out-of-band con il peer.
            let saltKey = SymmetricKey(size: .bits256)
            let saltData = saltKey.withUnsafeBytes { Data($0) }

            // Info: stringa di contesto che lega la chiave derivata al suo scopo specifico.
            // Usando info diversi si ottengono chiavi diverse dallo stesso IKM + salt.
            // Esempio: "encryption" → chiave per AES-GCM, "authentication" → chiave per HMAC
            let infoString = "SecDemo-AES256-Encryption-v1"
            let infoData = infoString.data(using: .utf8)!

            // Deriva 32 byte (256 bit) → chiave AES-256
            // HKDF<SHA256> usa SHA-256 come funzione hash sottostante
            let derivedKey = HKDF<SHA256>.deriveKey(
                inputKeyMaterial: SymmetricKey(data: inputKeyMaterial),
                salt: saltData,
                info: infoData,
                outputByteCount: 32  // 32 byte = 256 bit per AES-256
            )

            let derivedKeyData = derivedKey.withUnsafeBytes { Data($0) }

            self.hkdfResult = HKDFResult(
                inputKeyMaterial: inputKeyMaterial,
                derivedKeyData: derivedKeyData,
                salt: saltData,
                info: infoData
            )
            self.isProcessing = false
        }
    }

    // MARK: - Hashing e HMAC

    /// Calcola hash SHA-2 e codici di autenticazione HMAC per un messaggio.
    ///
    /// **Hash SHA-2 (Secure Hash Algorithm 2):**
    /// - `SHA-256`: 256 bit — uso generale, firma digitale, certificati
    /// - `SHA-384`: 384 bit — maggiore sicurezza con impatto moderato su performance
    /// - `SHA-512`: 512 bit — massima sicurezza SHA-2, ottimale su CPU 64-bit
    ///
    /// Gli hash sono funzioni a senso unico (one-way): dato H(m) non è computazionalmente
    /// possibile ricavare m, né trovare m' ≠ m tale che H(m) = H(m').
    ///
    /// **HMAC (Hash-based Message Authentication Code, RFC 2104):**
    /// `HMAC(K, m) = H((K ⊕ opad) || H((K ⊕ ipad) || m))`
    ///
    /// A differenza di un semplice hash, HMAC richiede una chiave segreta condivisa.
    /// Fornisce sia **integrità** che **autenticità** del messaggio.
    /// Usato in JWT, TLS, API authentication, ecc.
    ///
    /// - Parameter message: Il messaggio da hashare e autenticare
    func computeHashAndHMAC(message: String) {
        isProcessing = true
        errorMessage = nil

        Task {
            guard let messageData = message.data(using: .utf8) else {
                self.errorMessage = "Impossibile convertire il messaggio in UTF-8"
                self.isProcessing = false
                return
            }

            // --- SHA-2 Hashing ---

            // SHA-256: input di lunghezza arbitraria → digest a 256 bit (32 byte)
            let sha256Digest = SHA256.hash(data: messageData)

            // SHA-384: basato su SHA-512, troncato a 384 bit (48 byte)
            let sha384Digest = SHA384.hash(data: messageData)

            // SHA-512: digest a 512 bit (64 byte), ottimale su architetture 64-bit
            let sha512Digest = SHA512.hash(data: messageData)

            // --- HMAC ---

            // Genera una chiave HMAC casuale a 256 bit.
            // In produzione, questa chiave va condivisa in modo sicuro con il peer
            // (es: derivata tramite HKDF dallo SharedSecret ECDH).
            let hmacKey = SymmetricKey(size: .bits256)
            let hmacKeyData = hmacKey.withUnsafeBytes { Data($0) }

            // HMAC-SHA256: authentication code di 32 byte
            let hmacSHA256 = HMAC<SHA256>.authenticationCode(for: messageData, using: hmacKey)

            // HMAC-SHA384: authentication code di 48 byte
            let hmacSHA384 = HMAC<SHA384>.authenticationCode(for: messageData, using: hmacKey)

            // HMAC-SHA512: authentication code di 64 byte
            let hmacSHA512 = HMAC<SHA512>.authenticationCode(for: messageData, using: hmacKey)

            // Verifica HMAC: confronto in tempo costante (constant-time comparison)
            // per prevenire timing attacks. HMAC.isValidAuthenticationCode usa
            // internamente una comparazione a tempo costante.
            let isHMACValid = HMAC<SHA256>.isValidAuthenticationCode(
                hmacSHA256,
                authenticating: messageData,
                using: hmacKey
            )

            self.hashResult = HashResult(
                sha256: Data(sha256Digest).hexString,
                sha384: Data(sha384Digest).hexString,
                sha512: Data(sha512Digest).hexString,
                hmacSHA256: Data(hmacSHA256).hexString,
                hmacSHA384: Data(hmacSHA384).hexString,
                hmacSHA512: Data(hmacSHA512).hexString,
                hmacKeyHex: hmacKeyData.hexString,
                hmacVerified: isHMACValid
            )
            self.isProcessing = false
        }
    }
}

// MARK: - Estensioni Helper

extension Data {
    /// Converte Data in rappresentazione esadecimale lowercase per la visualizzazione
    var hexString: String {
        map { String(format: "%02x", $0) }.joined()
    }
}
