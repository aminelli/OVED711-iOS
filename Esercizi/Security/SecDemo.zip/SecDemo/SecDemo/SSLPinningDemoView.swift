//
//  SSLPinningDemoView.swift
//  SecDemo
//
//  Created by Antonio Minelli on 24/06/2026.
//
//  Interfaccia utente per la dimostrazione SSL Pinning e App Hardening.

import SwiftUI

struct SSLPinningDemoView: View {

    @State private var manager = SSLPinningManager()
    @State private var customURL: String = "https://httpbin.org/get"
    @State private var showATSInfo: Bool = false

    var body: some View {
        List {

            // ── Panoramica SSL Pinning ────────────────────────────────────────
            Section {
                VStack(alignment: .leading, spacing: 10) {
                    Label("SSL/TLS Certificate Pinning", systemImage: "lock.shield.fill")
                        .font(.headline)

                    Text("Tecnica di difesa contro attacchi Man-in-the-Middle (MITM). L'app verifica che il certificato TLS del server corrisponda a uno previsto, indipendentemente dalla CA trust store del sistema.")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    // Confronto approcci
                    VStack(alignment: .leading, spacing: 8) {
                        ForEach(PinningMode.allCases, id: \.self) { mode in
                            PinningModeRow(mode: mode)
                        }
                    }
                    .padding(10)
                    .background(.blue.opacity(0.04), in: RoundedRectangle(cornerRadius: 10))
                }
                .padding(.vertical, 4)
            } header: {
                Text("Panoramica")
            }

            // ── Selezione modalità ───────────────────────────────────────────
            Section {
                VStack(alignment: .leading, spacing: 10) {
                    Label("Configura e testa il pinning", systemImage: "gear")
                        .font(.headline)

                    // Selezione modalità di pinning
                    Picker("Modalità Pinning", selection: $manager.selectedMode) {
                        ForEach(PinningMode.allCases, id: \.self) { mode in
                            Text(mode.rawValue).tag(mode)
                        }
                    }
                    .pickerStyle(.segmented)

                    Text(manager.selectedMode.description)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .padding(6)
                        .background(.secondary.opacity(0.1), in: RoundedRectangle(cornerRadius: 6))

                    // URL di destinazione
                    TextField("URL HTTPS da testare", text: $customURL)
                        .textFieldStyle(.roundedBorder)
                        .keyboardType(.URL)
                        .autocorrectionDisabled()
                        .textInputAutocapitalization(.never)

                    Button {
                        manager.makeRequest(to: customURL, mode: manager.selectedMode)
                    } label: {
                        HStack {
                            Image(systemName: manager.selectedMode.systemImage)
                            Text("Esegui richiesta con \(manager.selectedMode.rawValue)")
                        }
                        .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(manager.isLoading || customURL.isEmpty)
                }
                .padding(.vertical, 4)
            } header: {
                Text("Test Pinning")
            }

            // ── Log challenge TLS ────────────────────────────────────────────
            if !manager.tlsChallengeLog.isEmpty {
                Section {
                    VStack(alignment: .leading, spacing: 4) {
                        ForEach(Array(manager.tlsChallengeLog.enumerated()), id: \.offset) { _, log in
                            Text(log)
                                .font(.system(.caption2, design: .monospaced))
                                .foregroundStyle(logColor(for: log))
                        }
                    }
                    .padding(8)
                    .background(.black.opacity(0.03), in: RoundedRectangle(cornerRadius: 8))
                } header: {
                    Text("Log Challenge TLS")
                }
            }

            // ── Risultato richiesta ──────────────────────────────────────────
            if let result = manager.requestResult {
                Section {
                    VStack(alignment: .leading, spacing: 10) {
                        // Status della richiesta
                        HStack {
                            Image(systemName: result.success ? "checkmark.circle.fill" : "xmark.circle.fill")
                                .foregroundStyle(result.success ? .green : .red)
                            VStack(alignment: .leading) {
                                Text(result.success ? "Connessione riuscita" : "Connessione fallita")
                                    .font(.subheadline.bold())
                                if let statusCode = result.statusCode {
                                    Text("HTTP \(statusCode)")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }
                        }

                        if let error = result.error {
                            Text("Errore: \(error)")
                                .font(.caption)
                                .foregroundStyle(.red)
                        }

                        // Informazioni certificato server
                        if let certInfo = result.serverCertInfo {
                            Divider()
                            VStack(alignment: .leading, spacing: 6) {
                                Text("Certificato Server")
                                    .font(.caption.bold())
                                    .foregroundStyle(.secondary)
                                CertInfoRow(label: "Subject", value: certInfo.subject)
                                CertInfoRow(label: "Algoritmo chiave", value: certInfo.publicKeyAlgorithm)
                                CertInfoRow(label: "Lunghezza chiave", value: "\(certInfo.publicKeySize) bit")
                                CertInfoRow(label: "Hash chiave pub. (SHA-256/Base64)",
                                             value: certInfo.publicKeySHA256)
                                CertInfoRow(label: "Hash certificato (SHA-256)",
                                             value: certInfo.certSHA256.prefix(40) + "…")
                            }
                        }

                        // Anteprima risposta
                        if let preview = result.responsePreview {
                            Divider()
                            Text("Risposta (anteprima)")
                                .font(.caption.bold())
                                .foregroundStyle(.secondary)
                            Text(preview)
                                .font(.system(.caption2, design: .monospaced))
                                .lineLimit(8)
                        }
                    }
                } header: {
                    Text("Risultato")
                }
            }

            // ── App Transport Security (ATS) ─────────────────────────────────
            Section {
                DisclosureGroup("App Transport Security (ATS)", isExpanded: $showATSInfo) {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("ATS è un framework di sicurezza di rete di iOS, attivo per default da iOS 9.")
                            .font(.caption)
                            .foregroundStyle(.secondary)

                        ATSRequirementRow(
                            icon: "lock.fill",
                            title: "HTTPS obbligatoria",
                            desc: "Tutto il traffico deve usare TLS (HTTP semplice bloccato)"
                        )
                        ATSRequirementRow(
                            icon: "arrow.up.forward.circle.fill",
                            title: "TLS 1.2 minimo",
                            desc: "iOS 13+ preferisce TLS 1.3 con Forward Secrecy (ECDHE)"
                        )
                        ATSRequirementRow(
                            icon: "doc.text.fill",
                            title: "Certificati SHA-256+",
                            desc: "SHA-1 non accettato. RSA ≥2048 bit o ECC ≥256 bit"
                        )
                        ATSRequirementRow(
                            icon: "key.fill",
                            title: "Perfect Forward Secrecy",
                            desc: "ECDHE richiesto: ogni sessione ha chiavi temporanee uniche"
                        )

                        Divider()

                        Text("Configurazione Info.plist (eccezioni per domini specifici):")
                            .font(.caption.bold())

                        Text(atsInfoPlistExample)
                            .font(.system(.caption2, design: .monospaced))
                            .padding(8)
                            .background(.secondary.opacity(0.1), in: RoundedRectangle(cornerRadius: 6))

                        Text("⚠️ Non usare NSAllowsArbitraryLoads=true in produzione!")
                            .font(.caption)
                            .foregroundStyle(.orange)
                    }
                    .padding(.top, 8)
                }
                .font(.subheadline.bold())
            } header: {
                Text("App Hardening")
            }
        }
        .navigationTitle("SSL Pinning & Hardening")
        .navigationBarTitleDisplayMode(.large)
        .overlay {
            if manager.isLoading {
                ProgressView("Connessione in corso…")
                    .padding()
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12))
            }
        }
    }

    // MARK: - Helper

    /// Restituisce il colore del log in base al prefisso emoji
    private func logColor(for log: String) -> Color {
        if log.hasPrefix("🔴") { return .red }
        if log.hasPrefix("🟢") { return .green }
        if log.hasPrefix("🟡") { return .yellow }
        if log.hasPrefix("🔵") { return .blue }
        if log.hasPrefix("⚠️") { return .orange }
        return .secondary
    }

    private let atsInfoPlistExample = """
    <key>NSAppTransportSecurity</key>
    <dict>
      <!-- Eccezione per un dominio specifico -->
      <key>NSExceptionDomains</key>
      <dict>
        <key>api.example.com</key>
        <dict>
          <!-- NON permettere HTTP -->
          <key>NSExceptionAllowsInsecureHTTPLoads</key>
          <false/>
          <!-- Includi sotto-domini -->
          <key>NSIncludesSubdomains</key>
          <true/>
        </dict>
      </dict>
    </dict>
    """
}

// MARK: - Componenti UI

private struct PinningModeRow: View {
    let mode: PinningMode

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: mode.systemImage)
                .foregroundStyle(.blue)
                .frame(width: 20)
            VStack(alignment: .leading, spacing: 2) {
                Text(mode.rawValue)
                    .font(.caption.bold())
                Text(mode.description)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
        }
    }
}

private struct CertInfoRow: View {
    let label: String
    let value: any StringProtocol

    var body: some View {
        VStack(alignment: .leading, spacing: 1) {
            Text(label)
                .font(.caption2)
                .foregroundStyle(.secondary)
            Text(value)
                .font(.system(.caption2, design: .monospaced))
                .lineLimit(2)
                .truncationMode(.middle)
        }
    }
}

private struct ATSRequirementRow: View {
    let icon: String
    let title: String
    let desc: String

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: icon)
                .foregroundStyle(.blue)
                .frame(width: 18)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.caption.bold())
                Text(desc)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
        }
    }
}

#Preview {
    NavigationStack {
        SSLPinningDemoView()
    }
}
