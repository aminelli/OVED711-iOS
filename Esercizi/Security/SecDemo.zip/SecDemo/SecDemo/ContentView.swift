//
//  ContentView.swift
//  SecDemo
//
//  Created by Antonio Minelli on 24/06/2026.
//
//  Schermata principale dell'app: hub di navigazione verso le tre aree tematiche
//  di sicurezza iOS dimostrate in questo progetto.

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            List {
                // ── Intestazione ────────────────────────────────────────────
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack(spacing: 12) {
                            Image(systemName: "lock.shield.fill")
                                .font(.largeTitle)
                                .foregroundStyle(.blue)
                            VStack(alignment: .leading) {
                                Text("SecDemo")
                                    .font(.title2.bold())
                                Text("iOS 26 · Swift 6.3 · Security")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        Text("Demo avanzata di CryptoKit, Keychain, Secure Enclave e SSL Pinning con best practice Apple.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 6)
                }

                // ── Sezione 1: CryptoKit ─────────────────────────────────────
                Section {
                    NavigationLink(destination: CryptoKitDemoView()) {
                        TopicRow(
                            icon: "lock.rectangle.stack.fill",
                            iconColor: .blue,
                            title: "CryptoKit",
                            subtitle: "Primitivi crittografici Apple",
                            tags: ["AES-GCM", "Curve25519", "HKDF", "SHA-2", "HMAC"]
                        )
                    }
                } header: {
                    Text("Crittografia")
                }

                // ── Sezione 2: Keychain & Secure Enclave ─────────────────────
                Section {
                    NavigationLink(destination: KeychainDemoView()) {
                        TopicRow(
                            icon: "key.fill",
                            iconColor: .orange,
                            title: "Keychain & Secure Enclave",
                            subtitle: "Storage sicuro e protezione hardware",
                            tags: ["kSecClass*", "kSecAttrAccessible*", "Face ID", "SE P-256", "App Group"]
                        )
                    }
                } header: {
                    Text("Portachiavi")
                }

                // ── Sezione 3: SSL Pinning & Hardening ───────────────────────
                Section {
                    NavigationLink(destination: SSLPinningDemoView()) {
                        TopicRow(
                            icon: "network.badge.shield.half.filled",
                            iconColor: .green,
                            title: "SSL Pinning & App Hardening",
                            subtitle: "Difesa da attacchi MITM e ATS",
                            tags: ["Certificate Pinning", "Public Key Pinning", "ATS", "URLSessionDelegate"]
                        )
                    }
                } header: {
                    Text("Sicurezza di rete")
                }

                // ── Note tecniche ────────────────────────────────────────────
                Section {
                    VStack(alignment: .leading, spacing: 6) {
                        TechNoteRow(icon: "info.circle", text: "Secure Enclave richiede dispositivo fisico (non simulatore)")
                        TechNoteRow(icon: "info.circle", text: "Biometria richiede entitlement NSFaceIDUsageDescription in Info.plist")
                        TechNoteRow(icon: "info.circle", text: "App Group Keychain richiede capability Keychain Sharing in Xcode")
                        TechNoteRow(icon: "info.circle", text: "SSL Pinning demo in modalità permissiva (allowUnpinnedForDemo=true)")
                    }
                    .padding(.vertical, 4)
                } header: {
                    Text("Note")
                }
            }
            .navigationTitle("Security Demo")
            .navigationBarTitleDisplayMode(.large)
        }
    }
}

// MARK: - Componenti UI

/// Riga di navigazione per un argomento principale
private struct TopicRow: View {
    let icon: String
    let iconColor: Color
    let title: String
    let subtitle: String
    let tags: [String]

    var body: some View {
        HStack(spacing: 14) {
            // Icona colorata
            Image(systemName: icon)
                .font(.title2)
                .foregroundStyle(iconColor)
                .frame(width: 44, height: 44)
                .background(iconColor.opacity(0.12), in: RoundedRectangle(cornerRadius: 10))

            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.headline)
                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)

                // Tag scrollabili
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 4) {
                        ForEach(tags, id: \.self) { tag in
                            Text(tag)
                                .font(.system(size: 10, weight: .medium, design: .monospaced))
                                .padding(.horizontal, 6)
                                .padding(.vertical, 2)
                                .background(iconColor.opacity(0.12), in: Capsule())
                                .foregroundStyle(iconColor)
                        }
                    }
                }
            }
        }
        .padding(.vertical, 4)
    }
}

/// Riga per note tecniche/prerequisiti
private struct TechNoteRow: View {
    let icon: String
    let text: String

    var body: some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: icon)
                .font(.caption)
                .foregroundStyle(.blue)
                .frame(width: 14)
            Text(text)
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
    }
}

#Preview {
    ContentView()
}
