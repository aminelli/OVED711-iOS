//
//  KeychainDemoView.swift
//  SecDemo
//
//  Created by Antonio Minelli on 24/06/2026.
//
//  Interfaccia utente per la dimostrazione del Keychain e Secure Enclave.

import SwiftUI

struct KeychainDemoView: View {

    @State private var manager = KeychainManager()

    // Input per le varie sezioni
    @State private var genericPassword: String = "P@ssw0rd-Demo-2026"
    @State private var updatedPassword: String = "N3wP@ssw0rd-Updated"
    @State private var biometricSecret: String = "SuperSecretBiometric"
    @State private var internetUsername: String = "tony@example.com"
    @State private var internetPassword: String = "InternetP@ss"
    @State private var internetServer: String = "api.example.com"
    @State private var seMessage: String = "Firma questo messaggio con Secure Enclave"
    @State private var appGroupSecret: String = "SharedAppGroupSecret"

    var body: some View {
        List {

            // ── Panoramica classi Keychain ────────────────────────────────────
            Section {
                VStack(alignment: .leading, spacing: 8) {
                    Label("Classi di item Keychain", systemImage: "list.bullet.rectangle")
                        .font(.headline)
                    Group {
                        KeychainClassRow(icon: "key.fill", color: .blue,
                                         name: "kSecClassGenericPassword",
                                         desc: "Credenziali app (service + account)")
                        KeychainClassRow(icon: "globe", color: .green,
                                         name: "kSecClassInternetPassword",
                                         desc: "Credenziali web (server + porta + protocollo)")
                        KeychainClassRow(icon: "doc.badge.ellipsis", color: .orange,
                                         name: "kSecClassCertificate",
                                         desc: "Certificati X.509 DER-encoded")
                        KeychainClassRow(icon: "key.horizontal.fill", color: .purple,
                                         name: "kSecClassKey",
                                         desc: "Chiavi crittografiche (RSA, EC, AES)")
                    }
                }
                .padding(.vertical, 4)
            } header: {
                Text("Classi Item")
            }

            // ── Generic Password CRUD ─────────────────────────────────────────
            Section {
                VStack(alignment: .leading, spacing: 10) {
                    Label("Generic Password — CRUD completo", systemImage: "key.fill")
                        .font(.headline)

                    TextField("Password da salvare", text: $genericPassword)
                        .textFieldStyle(.roundedBorder)

                    // Accessibilità: mostra le opzioni kSecAttrAccessible*
                    AccessibilityInfoView()

                    HStack(spacing: 8) {
                        ActionButton(title: "Salva", icon: "plus.circle", color: .blue) {
                            manager.saveGenericPassword(genericPassword)
                        }
                        ActionButton(title: "Leggi", icon: "eye", color: .green) {
                            manager.readGenericPassword()
                        }
                        ActionButton(title: "Elimina", icon: "trash", color: .red) {
                            manager.deleteGenericPassword()
                        }
                    }
                    .disabled(manager.isProcessing)

                    TextField("Nuovo valore (aggiorna)", text: $updatedPassword)
                        .textFieldStyle(.roundedBorder)

                    ActionButton(title: "Aggiorna con SecItemUpdate", icon: "arrow.clockwise", color: .orange) {
                        manager.updateGenericPassword(updatedPassword)
                    }
                    .disabled(manager.isProcessing)
                }
                .padding(.vertical, 4)
            } header: {
                Text("Generic Password")
            }

            // ── Internet Password ─────────────────────────────────────────────
            Section {
                VStack(alignment: .leading, spacing: 10) {
                    Label("Internet Password", systemImage: "globe")
                        .font(.headline)

                    Text("Include server, porta, protocollo e tipo di autenticazione.")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    TextField("Server", text: $internetServer)
                        .textFieldStyle(.roundedBorder)
                    TextField("Username", text: $internetUsername)
                        .textFieldStyle(.roundedBorder)
                    SecureField("Password", text: $internetPassword)
                        .textFieldStyle(.roundedBorder)

                    ActionButton(title: "Salva credenziali web", icon: "lock.fill", color: .blue) {
                        manager.saveInternetPassword(
                            username: internetUsername,
                            password: internetPassword,
                            server: internetServer
                        )
                    }
                    .disabled(manager.isProcessing)
                }
                .padding(.vertical, 4)
            } header: {
                Text("Internet Password")
            }

            // ── Biometric Access Control ──────────────────────────────────────
            Section {
                VStack(alignment: .leading, spacing: 10) {
                    Label("Access Control — Face ID / Touch ID", systemImage: "faceid")
                        .font(.headline)

                    Text("Il segreto richiede autenticazione biometrica per essere letto. Usa SecAccessControlCreateWithFlags con .biometryAny.")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    // Panoramica flag Access Control
                    VStack(alignment: .leading, spacing: 4) {
                        AccessControlFlagRow(flag: ".biometryAny",
                                             desc: "Qualsiasi biometria registrata (consigliato)")
                        AccessControlFlagRow(flag: ".biometryCurrentSet",
                                             desc: "Solo biometrie attuali — invalida a nuova impronta")
                        AccessControlFlagRow(flag: ".userPresence",
                                             desc: "Biometria O passcode")
                        AccessControlFlagRow(flag: ".devicePasscode",
                                             desc: "Solo passcode, nessuna biometria")
                    }
                    .padding(8)
                    .background(.orange.opacity(0.05), in: RoundedRectangle(cornerRadius: 8))

                    TextField("Segreto da proteggere", text: $biometricSecret)
                        .textFieldStyle(.roundedBorder)

                    HStack(spacing: 8) {
                        ActionButton(title: "Salva (no prompt)", icon: "plus.circle", color: .blue) {
                            manager.saveBiometricSecret(biometricSecret)
                        }
                        ActionButton(title: "Leggi (Face ID)", icon: "faceid", color: .green) {
                            manager.readBiometricSecret()
                        }
                    }
                    .disabled(manager.isProcessing)
                }
                .padding(.vertical, 4)
            } header: {
                Text("Access Control Biometrico")
            }

            // ── Secure Enclave ────────────────────────────────────────────────
            Section {
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Label("Secure Enclave — P-256", systemImage: "cpu.fill")
                            .font(.headline)
                        Spacer()
                        // Indicatore disponibilità
                        Label(
                            manager.secureEnclaveAvailable ? "Disponibile" : "Non disponibile",
                            systemImage: manager.secureEnclaveAvailable ? "checkmark.circle.fill" : "xmark.circle.fill"
                        )
                        .font(.caption)
                        .foregroundStyle(manager.secureEnclaveAvailable ? .green : .red)
                    }

                    Text("Genera e usa chiavi P-256 protette da hardware. La chiave privata non può mai essere estratta dal chip.")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    if !manager.secureEnclaveAvailable {
                        Label("Secure Enclave non disponibile su simulatore. Testa su dispositivo fisico.", systemImage: "info.circle")
                            .font(.caption)
                            .foregroundStyle(.orange)
                    }

                    ActionButton(title: "Genera chiave SE + salva tag Keychain", icon: "plus.circle.fill", color: .purple) {
                        manager.generateSecureEnclaveKey()
                    }
                    .disabled(manager.isProcessing || !manager.secureEnclaveAvailable)

                    if !manager.secureEnclavePublicKey.isEmpty {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Chiave pubblica P-256 (hex)")
                                .font(.caption2.bold())
                                .foregroundStyle(.secondary)
                            Text(manager.secureEnclavePublicKey.prefix(60) + "…")
                                .font(.system(.caption2, design: .monospaced))
                                .lineLimit(2)
                        }
                    }

                    TextField("Messaggio da firmare con SE", text: $seMessage, axis: .vertical)
                        .textFieldStyle(.roundedBorder)
                        .lineLimit(2)

                    ActionButton(title: "Firma con Secure Enclave (Face ID)", icon: "signature", color: .purple) {
                        manager.signWithSecureEnclaveKey(message: seMessage)
                    }
                    .disabled(manager.isProcessing || !manager.secureEnclaveAvailable)
                }
                .padding(.vertical, 4)
            } header: {
                Text("Secure Enclave")
            }

            // ── App Group Keychain ────────────────────────────────────────────
            Section {
                VStack(alignment: .leading, spacing: 10) {
                    Label("App Group Keychain Sharing", systemImage: "person.2.fill")
                        .font(.headline)

                    Text("Condividi item nel Keychain tra più app dello stesso team tramite kSecAttrAccessGroup. Richiede l'entitlement Keychain Sharing in Xcode.")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    // Steps di configurazione
                    VStack(alignment: .leading, spacing: 4) {
                        ConfigStepRow(number: "1", text: "Target → Signing & Capabilities")
                        ConfigStepRow(number: "2", text: "Aggiungi \"Keychain Sharing\" capability")
                        ConfigStepRow(number: "3", text: "Inserisci: group.com.secdemo.shared")
                        ConfigStepRow(number: "4", text: "Stesso provisioning profile per tutte le app")
                    }
                    .padding(8)
                    .background(.green.opacity(0.05), in: RoundedRectangle(cornerRadius: 8))

                    TextField("Segreto condiviso", text: $appGroupSecret)
                        .textFieldStyle(.roundedBorder)

                    ActionButton(title: "Salva in App Group Keychain", icon: "square.and.arrow.up", color: .green) {
                        manager.saveToAppGroupKeychain(appGroupSecret)
                    }
                    .disabled(manager.isProcessing)
                }
                .padding(.vertical, 4)
            } header: {
                Text("App Group Sharing")
            }

            // ── Risultato operazione ──────────────────────────────────────────
            if !manager.lastResult.isEmpty || manager.errorMessage != nil {
                Section {
                    if !manager.lastResult.isEmpty {
                        Text(manager.lastResult)
                            .font(.system(.caption, design: .monospaced))
                            .foregroundStyle(.primary)
                    }
                    if let error = manager.errorMessage {
                        Label(error, systemImage: "exclamationmark.triangle.fill")
                            .foregroundStyle(.red)
                            .font(.caption)
                    }
                } header: {
                    Text("Risultato")
                }
            }
        }
        .navigationTitle("Keychain & Secure Enclave")
        .navigationBarTitleDisplayMode(.large)
        .overlay {
            if manager.isProcessing {
                ProgressView("Operazione in corso…")
                    .padding()
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12))
            }
        }
    }
}

// MARK: - Componenti UI riutilizzabili

private struct KeychainClassRow: View {
    let icon: String
    let color: Color
    let name: String
    let desc: String

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: icon)
                .foregroundStyle(color)
                .frame(width: 20)
            VStack(alignment: .leading, spacing: 1) {
                Text(name)
                    .font(.system(.caption, design: .monospaced))
                Text(desc)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
        }
    }
}

private struct AccessControlFlagRow: View {
    let flag: String
    let desc: String

    var body: some View {
        HStack(alignment: .top, spacing: 6) {
            Text(flag)
                .font(.system(.caption2, design: .monospaced))
                .foregroundStyle(.blue)
                .frame(minWidth: 140, alignment: .leading)
            Text(desc)
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
    }
}

private struct AccessibilityInfoView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text("Accessibilità usata: kSecAttrAccessibleWhenUnlockedThisDeviceOnly")
                .font(.caption2)
                .foregroundStyle(.secondary)
            Text("→ Sicuro: nessun backup iCloud, accessibile solo da sbloccato")
                .font(.caption2)
                .foregroundStyle(.green)
        }
        .padding(6)
        .background(.blue.opacity(0.04), in: RoundedRectangle(cornerRadius: 6))
    }
}

private struct ConfigStepRow: View {
    let number: String
    let text: String

    var body: some View {
        HStack(spacing: 8) {
            Text(number)
                .font(.caption2.bold())
                .foregroundStyle(.white)
                .frame(width: 16, height: 16)
                .background(.green, in: Circle())
            Text(text)
                .font(.caption2)
        }
    }
}

private struct ActionButton: View {
    let title: String
    let icon: String
    let color: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Label(title, systemImage: icon)
                .font(.caption)
        }
        .buttonStyle(.bordered)
        .tint(color)
    }
}

#Preview {
    NavigationStack {
        KeychainDemoView()
    }
}
