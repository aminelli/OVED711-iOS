//
//  SecDemoApp.swift
//  SecDemo
//
//  Created by Antonio Minelli on 24/06/2026.
//

import SwiftUI

@main
struct SecDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
