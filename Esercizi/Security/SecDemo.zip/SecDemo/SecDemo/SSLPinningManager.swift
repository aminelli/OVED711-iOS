//
//  SSLPinningManager.swift
//  SecDemo
//
//  Created by Antonio Minelli on 24/06/2026.
//
//  Implementa SSL/TLS Certificate Pinning e Public Key Pinning.
//  Protegge l'app da attacchi Man-in-the-Middle (MITM) tramite URLSessionDelegate.
//
//  Configurazione ATS (App Transport Security) — Info.plist:
//  Per il pinning su host specifici, ATS deve permettere la connessione:
//  <key>NSAppTransportSecurity</key>
//  <dict>
//    <key>NSExceptionDomains</key>
//    <dict>
//      <key>httpbin.org</key>
//      <dict>
//        <key>NSExceptionAllowsInsecureHTTPLoads</key><false/>
//        <key>NSIncludesSubdomains</key><true/>
//      </dict>
//    </dict>
//  </dict>
//  NOTA: disabilitare NSAllowsArbitraryLoads in produzione!

import Foundation
import CryptoKit
import Security

// MARK: - Modalità di Pinning

/// Strategia di SSL Pinning da applicare alle connessioni
enum PinningMode: String, CaseIterable, Sendable {

    /// Nessun pinning: accetta qualsiasi certificato valido della CA store iOS.
    /// ⚠️ Non sicuro contro MITM con certificati di CA intermedie compromesse.
    case none = "Nessun Pinning"

    /// Certificate Pinning: confronta il certificato server completo (DER) con quello
    /// incorporato nell'app. Massima sicurezza ma richiede aggiornamento app ad ogni rinnovo.
    case certificate = "Certificate Pinning"

    /// Public Key Pinning: confronta solo l'hash SHA-256 dell'SPKI del server.
    /// Sopravvive al rinnovo del certificato se la chiave privata rimane invariata.
    /// Approccio consigliato per la maggior parte delle applicazioni.
    case publicKey = "Public Key Pinning"

    var description: String {
        switch self {
        case .none:
            return "Validazione standard iOS CA trust store"
        case .certificate:
            return "Confronto DER completo del certificato server"
        case .publicKey:
            return "Confronto hash SHA-256 della chiave pubblica SPKI"
        }
    }

    var systemImage: String {
        switch self {
        case .none:       return "shield"
        case .certificate: return "doc.text.magnifyingglass"
        case .publicKey:   return "key.radiowaves.forward.fill"
        }
    }
}

// MARK: - Modello risultato richiesta

/// Risultato di una richiesta HTTP effettuata con SSL Pinning
struct PinnedRequestResult: Sendable {
    let url: String
    let statusCode: Int?
    let pinningMode: PinningMode
    let success: Bool
    let error: String?
    let responsePreview: String?
    let serverCertInfo: ServerCertInfo?
}

/// Informazioni estratte dal certificato server durante la challenge
struct ServerCertInfo: Sendable {
    let subject: String
    let publicKeyAlgorithm: String
    let publicKeySize: Int
    let publicKeySHA256: String  // Hash SHA-256 della chiave pubblica
    let certSHA256: String       // Hash SHA-256 del certificato DER completo
}

// MARK: - Configurazione Pinning

/// Configurazione immutabile e Sendable per il delegate di pinning.
/// Separata dal manager @MainActor per evitare problemi di concorrenza.
struct PinningConfiguration: Sendable {
    let mode: PinningMode

    /// Hash SHA-256 Base64-encoded delle chiavi pubbliche SPKI da pinnare.
    ///
    /// Come generare l'hash per il tuo server (terminale macOS):
    /// ```bash
    /// # 1. Scarica il certificato
    /// openssl s_client -connect api.example.com:443 </dev/null 2>/dev/null \
    ///   | openssl x509 -outform DER -out server.der
    ///
    /// # 2. Estrai la chiave pubblica e calcola l'hash SPKI
    /// openssl x509 -inform DER -in server.der -pubkey -noout \
    ///   | openssl pkey -pubin -outform DER \
    ///   | openssl dgst -sha256 -binary \
    ///   | openssl base64
    /// ```
    ///
    /// In produzione: includi sempre almeno 2 hash (certificato corrente + backup)
    /// per evitare un denial-of-service se il certificato primario scade.
    let pinnedPublicKeyHashes: Set<String>

    /// URL del file .der del certificato pinnato nel bundle dell'app.
    /// Nil se si usa solo public key pinning.
    let pinnedCertificateURL: URL?

    /// Se true, accetta anche certificati non ancora matchati (modalità demo/test)
    let allowUnpinnedForDemo: Bool
}

// MARK: - SSLPinningManager

/// Manager per connessioni di rete con SSL/TLS Pinning attivo.
///
/// **Cos'è un attacco MITM (Man-in-the-Middle)?**
/// Un attaccante si interpone tra il client e il server, presentando un certificato
/// valido ma diverso da quello del server legittimo (es: emesso da una CA compromessa
/// o installata manualmente sul dispositivo dell'utente).
///
/// **Come funziona il SSL Pinning:**
/// 1. L'app incorpora il certificato (o la sua chiave pubblica) del server
/// 2. Durante ogni connessione, il server presenta il suo certificato
/// 3. URLSessionDelegate intercetta la challenge di autenticazione server
/// 4. L'app confronta il certificato ricevuto con quello pinnato
/// 5. Se non corrisponde → connessione rifiutata → protezione MITM attiva
///
/// **ATS (App Transport Security):**
/// ATS è un framework di sicurezza di iOS che impone:
/// - Connessioni HTTPS per tutto il traffico di rete
/// - TLS 1.2+ (iOS 9+), TLS 1.3 preferito (iOS 13+)
/// - Forward Secrecy obbligatoria (ECDHE)
/// - Certificati SHA-256+, chiavi RSA ≥2048 bit o ECC ≥256 bit
/// Configurazione in Info.plist tramite NSAppTransportSecurity
@MainActor
@Observable
final class SSLPinningManager {

    // MARK: - Stato osservabile

    var requestResult: PinnedRequestResult?
    var isLoading: Bool = false
    var selectedMode: PinningMode = .publicKey
    var demoURL: String = "https://httpbin.org/get"

    // MARK: - Log delle challenge TLS

    var tlsChallengeLog: [String] = []

    // MARK: - Configurazione pinning

    /// Hash SHA-256 SPKI di esempio. In produzione, sostituire con gli hash reali del server.
    /// Vedi commento in PinningConfiguration per le istruzioni di generazione.
    private let examplePinnedHashes: Set<String> = [
        // Hash placeholder — sostituire con l'hash reale del server target
        "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB=",
        // Hash di backup (previsionale per il prossimo rinnovo certificato)
        "CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC="
    ]

    // MARK: - Esecuzione richiesta con pinning

    /// Esegue una richiesta GET con la modalità di pinning selezionata.
    ///
    /// Il delegate SSLPinningDelegate gestisce la challenge TLS intercettando
    /// `urlSession(_:didReceive:completionHandler:)`.
    ///
    /// - Parameters:
    ///   - urlString: URL di destinazione (deve essere HTTPS)
    ///   - mode: Modalità di pinning da applicare
    func makeRequest(to urlString: String, mode: PinningMode) {
        isLoading = true
        requestResult = nil
        tlsChallengeLog.removeAll()

        Task {
            guard let url = URL(string: urlString),
                  url.scheme == "https" else {
                // ATS impone HTTPS: le connessioni HTTP semplici sono bloccate per default
                requestResult = PinnedRequestResult(
                    url: urlString,
                    statusCode: nil,
                    pinningMode: mode,
                    success: false,
                    error: "URL non valido o non HTTPS. ATS richiede connessioni sicure.",
                    responsePreview: nil,
                    serverCertInfo: nil
                )
                isLoading = false
                return
            }

            // Configurazione della sessione: nessuna cache per evitare di bypassare il pinning
            let config = URLSessionConfiguration.ephemeral
            config.timeoutIntervalForRequest = 15

            let pinningConfig = PinningConfiguration(
                mode: mode,
                pinnedPublicKeyHashes: examplePinnedHashes,
                pinnedCertificateURL: Bundle.main.url(forResource: "server_cert", withExtension: "der"),
                allowUnpinnedForDemo: true // modalità demo: non blocca connessioni con hash non noti
            )

            // Il delegate viene creato con una closure per riportare il log sul main actor
            let logHandler: @Sendable (String) -> Void = { [weak self] message in
                Task { @MainActor in
                    self?.tlsChallengeLog.append(message)
                }
            }

            // Inizializza URLSession con il delegate di pinning
            // delegateQueue: nil → il delegate verrà chiamato su una coda del sistema
            let delegate = SSLPinningDelegate(configuration: pinningConfig, logHandler: logHandler)
            let session = URLSession(configuration: config, delegate: delegate, delegateQueue: nil)

            do {
                let (data, response) = try await session.data(from: url)
                let httpResponse = response as? HTTPURLResponse
                let preview = String(data: data, encoding: .utf8).map { String($0.prefix(800)) }

                requestResult = PinnedRequestResult(
                    url: urlString,
                    statusCode: httpResponse?.statusCode,
                    pinningMode: mode,
                    success: true,
                    error: nil,
                    responsePreview: preview,
                    serverCertInfo: delegate.capturedCertInfo
                )
            } catch {
                requestResult = PinnedRequestResult(
                    url: urlString,
                    statusCode: nil,
                    pinningMode: mode,
                    success: false,
                    error: error.localizedDescription,
                    responsePreview: nil,
                    serverCertInfo: delegate.capturedCertInfo
                )
            }

            isLoading = false
        }
    }
}

// MARK: - SSLPinningDelegate

/// Delegato URLSession che implementa la logica di SSL/TLS Pinning.
///
/// **Flusso della challenge TLS:**
/// ```
/// Client → SYN → Server
///          ← TLS ServerHello + Certificato
/// URLSession → urlSession(_:didReceive:completionHandler:)
///              [qui: verifico il certificato]
///              → .useCredential (accetto) | .cancelAuthenticationChallenge (rifiuto)
/// ```
///
/// **Best practice di sicurezza:**
/// 1. Validare SEMPRE la catena di certificati con SecTrustEvaluateWithError PRIMA del pinning
/// 2. NON saltare la validazione CA per implementare solo il pinning custom
/// 3. Usare session.configuration.ephemeral per evitare cache
/// 4. Implementare fallback con almeno 2 hash pinnati (corrente + backup)
/// 5. Loggare i fallimenti di pinning per rilevare attacchi MITM
final class SSLPinningDelegate: NSObject, URLSessionDelegate, @unchecked Sendable {

    private let configuration: PinningConfiguration
    private let logHandler: (@Sendable (String) -> Void)?

    /// Informazioni estratte dal certificato durante la challenge (per visualizzazione)
    private(set) var capturedCertInfo: ServerCertInfo?

    init(configuration: PinningConfiguration, logHandler: (@Sendable (String) -> Void)? = nil) {
        self.configuration = configuration
        self.logHandler = logHandler
    }

    // MARK: - URLSessionDelegate

    /// Punto centrale del SSL Pinning: gestisce la challenge di autenticazione server.
    ///
    /// Questo metodo viene invocato da URLSession per ogni connessione HTTPS.
    /// Il parametro `challenge` contiene il SecTrust con il certificato del server.
    ///
    /// La decisione finale viene comunicata tramite `completionHandler`:
    /// - `.performDefaultHandling`: delega la validazione a iOS (nessun pinning)
    /// - `.useCredential(URLCredential(trust:))`: accetta la connessione
    /// - `.cancelAuthenticationChallenge`: rifiuta la connessione (pinning fallito)
    func urlSession(
        _ session: URLSession,
        didReceive challenge: URLAuthenticationChallenge,
        completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void
    ) {
        // Verifica che il tipo di sfida sia NSURLAuthenticationMethodServerTrust (TLS server cert)
        // Altri tipi di sfida (es: client certificate, HTTP Basic) vengono ignorati qui
        guard challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust,
              let serverTrust = challenge.protectionSpace.serverTrust else {
            logHandler?("⚪ Challenge non-TLS: delegata al comportamento predefinito")
            completionHandler(.performDefaultHandling, nil)
            return
        }

        let host = challenge.protectionSpace.host
        logHandler?("🔵 TLS Challenge ricevuta per host: \(host)")

        // ──────────────────────────────────────────────────────────────────
        // STEP 1: Valida la catena di certificati con il CA trust store iOS
        // ──────────────────────────────────────────────────────────────────
        // FONDAMENTALE: NON saltare questo passo! Il pinning custom non sostituisce
        // la validazione della catena CA. Verificare entrambi garantisce:
        // - Il certificato è valido e non scaduto (validazione CA)
        // - Il certificato appartiene al server atteso (pinning)
        var cfError: CFError?
        let isTrustValid = SecTrustEvaluateWithError(serverTrust, &cfError)

        guard isTrustValid else {
            let errorDesc = cfError.map { String(describing: $0) } ?? "Trust evaluation fallita"
            logHandler?("🔴 Validazione CA fallita: \(errorDesc)")
            // Rifiuta: certificato non valido per la CA store iOS (scaduto, self-signed, ecc.)
            completionHandler(.cancelAuthenticationChallenge, nil)
            return
        }
        logHandler?("🟢 Validazione CA iOS: PASSATA")

        // ──────────────────────────────────────────────────────────────────
        // STEP 2: Estrai informazioni dal certificato per la visualizzazione
        // ──────────────────────────────────────────────────────────────────
        capturedCertInfo = extractCertInfo(from: serverTrust)

        // ──────────────────────────────────────────────────────────────────
        // STEP 3: Applica la logica di pinning specifica
        // ──────────────────────────────────────────────────────────────────
        let isPinned: Bool

        switch configuration.mode {

        case .none:
            // Nessun pinning: accetta se la CA validation è passata (step 1)
            isPinned = true
            logHandler?("⚪ Modalità: nessun pinning (solo CA validation)")

        case .certificate:
            // Certificate Pinning: confronta il certificato DER completo
            isPinned = verifyCertificatePinning(serverTrust: serverTrust)
            logHandler?("🔍 Certificate pinning: \(isPinned ? "✓ MATCH" : "✗ NO MATCH")")

        case .publicKey:
            // Public Key Pinning: confronta l'hash SHA-256 della chiave pubblica
            isPinned = verifyPublicKeyPinning(serverTrust: serverTrust)
            logHandler?("🔍 Public key pinning: \(isPinned ? "✓ MATCH" : "✗ NO MATCH")")
        }

        // ──────────────────────────────────────────────────────────────────
        // STEP 4: Decide se accettare o rifiutare la connessione
        // ──────────────────────────────────────────────────────────────────
        if isPinned {
            logHandler?("🟢 Pinning SUPERATO → connessione accettata")
            let credential = URLCredential(trust: serverTrust)
            completionHandler(.useCredential, credential)
        } else if configuration.allowUnpinnedForDemo {
            // Modalità DEMO ONLY: accetta anche se il pin non corrisponde
            // RIMUOVERE in produzione!
            logHandler?("🟡 Pinning FALLITO ma modalità demo attiva → accetto per visualizzazione")
            let credential = URLCredential(trust: serverTrust)
            completionHandler(.useCredential, credential)
        } else {
            // Produzione: rifiuta la connessione
            // In produzione: loggare l'evento per rilevare potenziali attacchi MITM
            logHandler?("🔴 Pinning FALLITO → connessione rifiutata (possibile MITM!)")
            completionHandler(.cancelAuthenticationChallenge, nil)
        }
    }

    // MARK: - Certificate Pinning

    /// Verifica il certificato server confrontandolo con il certificato pinnato nel bundle.
    ///
    /// Questo approccio confronta byte per byte il certificato DER.
    /// È il più sicuro ma richiede un aggiornamento dell'app ad ogni rinnovo del certificato.
    ///
    /// Il file .der si incorpora nel bundle:
    /// 1. Xcode → Project Navigator → drag & drop del file .der
    /// 2. Assicurarsi che sia nel "Copy Bundle Resources" del target
    ///
    /// - Parameter serverTrust: SecTrust ricevuto nella challenge
    /// - Returns: true se il certificato corrisponde a quello pinnato
    private func verifyCertificatePinning(serverTrust: SecTrust) -> Bool {
        // Recupera la catena di certificati dal server (iOS 15+: SecTrustCopyCertificateChain)
        guard let certChain = SecTrustCopyCertificateChain(serverTrust) as? [SecCertificate],
              let serverLeafCert = certChain.first else {
            logHandler?("⚠️ Impossibile ottenere la catena di certificati")
            return false
        }

        // Estrae i dati DER del certificato foglia (leaf certificate) del server
        let serverCertData = SecCertificateCopyData(serverLeafCert) as Data

        // Carica il certificato pinnato dal bundle dell'app
        guard let pinnedURL = configuration.pinnedCertificateURL,
              let pinnedCertData = try? Data(contentsOf: pinnedURL) else {
            // Certificato non trovato nel bundle → fallback a allow in demo mode
            logHandler?("⚠️ Certificato pinnato non trovato nel bundle (server_cert.der)")
            return configuration.allowUnpinnedForDemo
        }

        // Confronto byte per byte: sicuro perché usa == su Data (constant-time comparison)
        return serverCertData == pinnedCertData
    }

    // MARK: - Public Key Pinning

    /// Verifica la chiave pubblica del server confrontando il suo hash SHA-256
    /// con quelli nella lista degli hash pinnati.
    ///
    /// **SPKI (Subject Public Key Info):**
    /// Struttura ASN.1 che contiene sia l'OID dell'algoritmo che i dati della chiave pubblica.
    /// Hashando l'SPKI (non solo la chiave grezza) si garantisce che l'hash sia
    /// sensibile anche all'algoritmo usato.
    ///
    /// NOTA: `SecKeyCopyExternalRepresentation` restituisce la chiave in formato raw
    /// (non SPKI completo). Per un SPKI hash certificato, usare la libreria TrustKit
    /// oppure costruire manualmente l'header ASN.1.
    ///
    /// - Parameter serverTrust: SecTrust ricevuto nella challenge
    /// - Returns: true se l'hash della chiave pubblica è tra quelli pinnati
    private func verifyPublicKeyPinning(serverTrust: SecTrust) -> Bool {
        guard let certChain = SecTrustCopyCertificateChain(serverTrust) as? [SecCertificate],
              let serverLeafCert = certChain.first else {
            return false
        }

        // Estrae la chiave pubblica dal certificato foglia
        guard let publicKey = SecCertificateCopyKey(serverLeafCert) else {
            logHandler?("⚠️ Impossibile estrarre la chiave pubblica dal certificato")
            return false
        }

        // Serializza la chiave pubblica (formato dipendente dall'algoritmo:
        // - RSA: PKCS#1 DER
        // - EC: X9.63 uncompressed point (04 || x || y)
        var extractError: Unmanaged<CFError>?
        guard let publicKeyData = SecKeyCopyExternalRepresentation(publicKey, &extractError) as Data? else {
            logHandler?("⚠️ Impossibile serializzare la chiave pubblica")
            return false
        }

        // Calcola SHA-256 della rappresentazione della chiave pubblica
        let sha256Hash = SHA256.hash(data: publicKeyData)
        let hashBase64 = Data(sha256Hash).base64EncodedString()

        logHandler?("🔑 Hash SHA-256 chiave pubblica server: \(hashBase64)")

        // Verifica se l'hash è tra quelli pinnati
        let isPinned = configuration.pinnedPublicKeyHashes.contains(hashBase64)

        if !isPinned {
            logHandler?("ℹ️ Hash non nella lista: aggiungi '\(hashBase64)' a pinnedPublicKeyHashes")
        }

        return isPinned
    }

    // MARK: - Estrazione informazioni certificato

    /// Estrae informazioni leggibili dal certificato server per la visualizzazione UI
    private func extractCertInfo(from serverTrust: SecTrust) -> ServerCertInfo? {
        guard let certChain = SecTrustCopyCertificateChain(serverTrust) as? [SecCertificate],
              let leafCert = certChain.first else {
            return nil
        }

        let certData = SecCertificateCopyData(leafCert) as Data
        let certSHA256 = Data(SHA256.hash(data: certData)).hexString

        // Estrae subject summary (nome del certificato)
        let subject = SecCertificateCopySubjectSummary(leafCert) as String? ?? "Sconosciuto"

        // Informazioni sulla chiave pubblica
        var pubKeyAlgorithm = "Sconosciuto"
        var pubKeySize = 0
        var pubKeySHA256 = ""

        if let publicKey = SecCertificateCopyKey(leafCert) {
            let attributes = SecKeyCopyAttributes(publicKey) as? [CFString: Any] ?? [:]

            if let keyType = attributes[kSecAttrKeyType] as? String {
                if keyType == (kSecAttrKeyTypeRSA as String) {
                    pubKeyAlgorithm = "RSA"
                } else if keyType == (kSecAttrKeyTypeECSECPrimeRandom as String) {
                    pubKeyAlgorithm = "EC (P-256/P-384/P-521)"
                }
            }
            if let keySizeBits = attributes[kSecAttrKeySizeInBits] as? Int {
                pubKeySize = keySizeBits
            }

            var extractError: Unmanaged<CFError>?
            if let keyData = SecKeyCopyExternalRepresentation(publicKey, &extractError) as Data? {
                pubKeySHA256 = Data(SHA256.hash(data: keyData)).base64EncodedString()
            }
        }

        return ServerCertInfo(
            subject: subject,
            publicKeyAlgorithm: pubKeyAlgorithm,
            publicKeySize: pubKeySize,
            publicKeySHA256: pubKeySHA256,
            certSHA256: certSHA256
        )
    }
}
