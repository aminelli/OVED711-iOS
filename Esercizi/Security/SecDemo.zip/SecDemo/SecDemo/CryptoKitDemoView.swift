//
//  CryptoKitDemoView.swift
//  SecDemo
//
//  Created by Antonio Minelli on 24/06/2026.
//
//  Interfaccia utente per la dimostrazione interattiva dei primitivi CryptoKit.

import SwiftUI
import CryptoKit

struct CryptoKitDemoView: View {

    // Il manager è creato come @State: è @MainActor e @Observable, quindi
    // SwiftUI aggiornerà automaticamente la vista ad ogni cambiamento di stato
    @State private var manager = CryptoKitManager()

    // Testi di input per le varie sezioni
    @State private var aesPlaintext: String = "Messaggio segreto da cifrare con AES-256-GCM"
    @State private var hashMessage: String = "Hello CryptoKit!"
    @State private var hkdfInput: String = ""

    var body: some View {
        List {
            // ── Sezione AES-GCM ──────────────────────────────────────────────
            Section {
                VStack(alignment: .leading, spacing: 12) {
                    Label("AES-256-GCM — Cifratura AEAD", systemImage: "lock.fill")
                        .font(.headline)

                    Text("Cifratura simmetrica autenticata: garantisce riservatezza, integrità e autenticità in un'unica operazione.")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    TextField("Testo da cifrare", text: $aesPlaintext, axis: .vertical)
                        .textFieldStyle(.roundedBorder)
                        .lineLimit(2...4)

                    HStack(spacing: 10) {
                        Button("Cifra") {
                            manager.encryptWithAESGCM(plaintext: aesPlaintext)
                        }
                        .buttonStyle(.borderedProminent)
                        .disabled(aesPlaintext.isEmpty || manager.isProcessing)

                        Button("Decifra") {
                            if let result = manager.aesResult {
                                manager.decryptWithAESGCM(result: result)
                            }
                        }
                        .buttonStyle(.bordered)
                        .disabled(manager.aesResult == nil || manager.isProcessing)
                    }

                    // Risultati AES-GCM
                    if let result = manager.aesResult {
                        VStack(alignment: .leading, spacing: 6) {
                            CryptoResultRow(label: "Chiave (256 bit)", value: result.keyData.hexString.truncated(to: 40))
                            CryptoResultRow(label: "Nonce (96 bit)", value: result.nonceData.hexString)
                            CryptoResultRow(label: "Ciphertext", value: result.ciphertext.hexString.truncated(to: 40))
                            CryptoResultRow(label: "Auth Tag (128 bit)", value: result.tag.hexString)
                        }
                        .padding(10)
                        .background(.blue.opacity(0.05), in: RoundedRectangle(cornerRadius: 8))
                    }

                    if let decrypted = manager.aesDecryptedText {
                        Label("Decifrato: \"\(decrypted)\"", systemImage: "checkmark.seal.fill")
                            .foregroundStyle(.green)
                            .font(.callout)
                    }
                }
                .padding(.vertical, 4)
            } header: {
                Text("AES-GCM")
            }

            // ── Sezione Curve25519 ECDH ──────────────────────────────────────
            Section {
                VStack(alignment: .leading, spacing: 12) {
                    Label("Curve25519 — X25519 ECDH", systemImage: "arrow.triangle.swap")
                        .font(.headline)

                    Text("Scambio di chiavi Diffie-Hellman: Alice e Bob calcolano lo stesso segreto condiviso senza inviarlo mai in chiaro.")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    Button("Esegui scambio di chiavi Alice ↔ Bob") {
                        manager.performCurve25519ECDH()
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(manager.isProcessing)

                    if let result = manager.ecdhResult {
                        VStack(alignment: .leading, spacing: 6) {
                            CryptoResultRow(label: "Pub. Alice (32B)", value: result.alicePublicKeyData.hexString.truncated(to: 40))
                            CryptoResultRow(label: "Pub. Bob (32B)", value: result.bobPublicKeyData.hexString.truncated(to: 40))
                            CryptoResultRow(label: "Segreto condiviso", value: result.sharedSecret.hexString.truncated(to: 40))
                        }
                        .padding(10)
                        .background(.purple.opacity(0.05), in: RoundedRectangle(cornerRadius: 8))

                        Label("I segreti di Alice e Bob coincidono ✓", systemImage: "checkmark.seal.fill")
                            .foregroundStyle(.green)
                            .font(.caption)

                        // Pulsante per derivare la chiave con HKDF dallo SharedSecret
                        Button("Deriva chiave AES con HKDF →") {
                            manager.deriveKeyWithHKDF(inputKeyMaterial: result.sharedSecret)
                        }
                        .buttonStyle(.bordered)
                        .font(.caption)
                    }
                }
                .padding(.vertical, 4)
            } header: {
                Text("Curve25519 ECDH")
            }

            // ── Sezione HKDF ─────────────────────────────────────────────────
            Section {
                VStack(alignment: .leading, spacing: 12) {
                    Label("HKDF — Key Derivation Function", systemImage: "key.radiowaves.forward.fill")
                        .font(.headline)

                    Text("Deriva chiavi crittografiche robuste da materiale grezzo (es: SharedSecret ECDH). Due fasi: Extract → PRK, Expand → OKM.")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    Button("Deriva da materiale casuale") {
                        // Genera IKM casuale per la demo standalone
                        let randomIKM = SymmetricKey(size: .bits256).withUnsafeBytes { Data($0) }
                        manager.deriveKeyWithHKDF(inputKeyMaterial: randomIKM)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(manager.isProcessing)

                    if let result = manager.hkdfResult {
                        VStack(alignment: .leading, spacing: 6) {
                            CryptoResultRow(label: "IKM (input grezzo)", value: result.inputKeyMaterial.hexString.truncated(to: 36))
                            CryptoResultRow(label: "Sale (256 bit)", value: result.salt.hexString.truncated(to: 36))
                            CryptoResultRow(label: "Info (contesto)", value: String(data: result.info, encoding: .utf8) ?? "–")
                            CryptoResultRow(label: "Chiave derivata (256 bit)", value: result.derivedKeyData.hexString.truncated(to: 40))
                        }
                        .padding(10)
                        .background(.orange.opacity(0.05), in: RoundedRectangle(cornerRadius: 8))
                    }
                }
                .padding(.vertical, 4)
            } header: {
                Text("HKDF")
            }

            // ── Sezione Hashing e HMAC ───────────────────────────────────────
            Section {
                VStack(alignment: .leading, spacing: 12) {
                    Label("SHA-2 e HMAC", systemImage: "number.circle.fill")
                        .font(.headline)

                    Text("Hash crittografici one-way (SHA-256/384/512) e codici di autenticazione HMAC con chiave segreta.")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    TextField("Messaggio da hashare", text: $hashMessage)
                        .textFieldStyle(.roundedBorder)

                    Button("Calcola Hash e HMAC") {
                        manager.computeHashAndHMAC(message: hashMessage)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(hashMessage.isEmpty || manager.isProcessing)

                    if let result = manager.hashResult {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("SHA-2 Hash")
                                .font(.caption.bold())
                                .foregroundStyle(.secondary)
                            CryptoResultRow(label: "SHA-256 (32B)", value: result.sha256.truncated(to: 40))
                            CryptoResultRow(label: "SHA-384 (48B)", value: result.sha384.truncated(to: 40))
                            CryptoResultRow(label: "SHA-512 (64B)", value: result.sha512.truncated(to: 40))

                            Divider()

                            Text("HMAC")
                                .font(.caption.bold())
                                .foregroundStyle(.secondary)
                            CryptoResultRow(label: "Chiave HMAC", value: result.hmacKeyHex.truncated(to: 36))
                            CryptoResultRow(label: "HMAC-SHA256", value: result.hmacSHA256.truncated(to: 40))
                            CryptoResultRow(label: "HMAC-SHA384", value: result.hmacSHA384.truncated(to: 40))
                            CryptoResultRow(label: "HMAC-SHA512", value: result.hmacSHA512.truncated(to: 40))

                            if result.hmacVerified {
                                Label("Verifica HMAC-SHA256: VALIDA ✓", systemImage: "checkmark.seal.fill")
                                    .foregroundStyle(.green)
                                    .font(.caption)
                            }
                        }
                        .padding(10)
                        .background(.green.opacity(0.05), in: RoundedRectangle(cornerRadius: 8))
                    }
                }
                .padding(.vertical, 4)
            } header: {
                Text("Hashing e HMAC")
            }

            // ── Errori ───────────────────────────────────────────────────────
            if let error = manager.errorMessage {
                Section {
                    Label(error, systemImage: "exclamationmark.triangle.fill")
                        .foregroundStyle(.red)
                        .font(.caption)
                }
            }
        }
        .navigationTitle("CryptoKit")
        .navigationBarTitleDisplayMode(.large)
        .overlay {
            if manager.isProcessing {
                ProgressView("Elaborazione...")
                    .padding()
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12))
            }
        }
    }
}

// MARK: - Componente riutilizzabile

/// Riga di visualizzazione per un risultato crittografico (label + valore)
private struct CryptoResultRow: View {
    let label: String
    let value: String

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label)
                .font(.caption2)
                .foregroundStyle(.secondary)
            Text(value)
                .font(.system(.caption, design: .monospaced))
                .lineLimit(1)
                .truncationMode(.middle)
        }
    }
}

// MARK: - Estensione String Helper

private extension String {
    /// Tronca la stringa a `length` caratteri aggiungendo "…" se necessario
    func truncated(to length: Int) -> String {
        count > length ? String(prefix(length)) + "…" : self
    }
}

#Preview {
    NavigationStack {
        CryptoKitDemoView()
    }
}
