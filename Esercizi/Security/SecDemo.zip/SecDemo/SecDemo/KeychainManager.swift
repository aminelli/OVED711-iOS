//
//  KeychainManager.swift
//  SecDemo
//
//  Created by Antonio Minelli on 24/06/2026.
//
//  Dimostra l'uso avanzato del portachiavi iOS (Keychain) e del Secure Enclave:
//  - Classi di item: kSecClassGenericPassword, kSecClassInternetPassword, kSecClassKey
//  - Attributi di accessibilità: kSecAttrAccessible*
//  - Access Control con biometria (Face ID / Touch ID)
//  - Secure Enclave: generazione e uso di chiavi P-256 protette hardware
//  - App Group Keychain sharing

import Foundation
import Security
import CryptoKit
import LocalAuthentication

// MARK: - Errori Keychain

/// Errori tipizzati per le operazioni sul portachiavi
enum KeychainError: Error, LocalizedError {
    case itemNotFound
    case duplicateItem
    case unexpectedData
    case authCancelled
    case secureEnclaveUnavailable
    case accessControlCreationFailed
    case unhandledError(status: OSStatus)

    var errorDescription: String? {
        switch self {
        case .itemNotFound:
            return "Item non trovato nel Keychain"
        case .duplicateItem:
            return "Item già presente nel Keychain"
        case .unexpectedData:
            return "Formato dati non atteso"
        case .authCancelled:
            return "Autenticazione biometrica annullata dall'utente"
        case .secureEnclaveUnavailable:
            return "Secure Enclave non disponibile (richiede iPhone 5S+ o iPad Pro)"
        case .accessControlCreationFailed:
            return "Impossibile creare SecAccessControl"
        case .unhandledError(let status):
            // Traduce l'OSStatus in stringa leggibile
            let message = SecCopyErrorMessageString(status, nil) as String? ?? "Errore sconosciuto"
            return "Keychain OSStatus \(status): \(message)"
        }
    }
}

// MARK: - KeychainManager

/// Manager centralizzato per le operazioni sul portachiavi iOS.
///
/// Il **Keychain** è un database cifrato del sistema operativo che fornisce
/// storage sicuro per credenziali, chiavi crittografiche e altri dati sensibili.
///
/// **Classi di item supportate:**
/// - `kSecClassGenericPassword`: credenziali generiche (username + password app)
/// - `kSecClassInternetPassword`: credenziali per server web (include host, porta, protocollo)
/// - `kSecClassCertificate`: certificati X.509
/// - `kSecClassKey`: chiavi crittografiche (pubblica, privata, simmetrica)
/// - `kSecClassIdentity`: coppia certificato + chiave privata
///
/// **Attributi di accessibilità (`kSecAttrAccessible*`):**
/// - `kSecAttrAccessibleWhenUnlocked` (default): accessibile quando il dispositivo è sbloccato
/// - `kSecAttrAccessibleWhenUnlockedThisDeviceOnly`: come sopra, senza backup iCloud
/// - `kSecAttrAccessibleAfterFirstUnlock`: accessibile dal primo sblocco post-riavvio
/// - `kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly`: come sopra, senza backup
/// - `kSecAttrAccessibleWhenPasscodeSetThisDeviceOnly`: richiede passcode attivo sul device
@MainActor
@Observable
final class KeychainManager {

    // MARK: - Stato osservabile

    var lastResult: String = ""
    var errorMessage: String?
    var isProcessing: Bool = false
    var secureEnclavePublicKey: String = ""
    var secureEnclaveAvailable: Bool = SecureEnclave.isAvailable

    // MARK: - Costanti interne

    /// Identificatore del servizio per le password generiche
    private let service = "com.secdemo.keychain"
    /// Account per la demo password standard
    private let accountStandard = "demo-standard"
    /// Account per la demo con protezione biometrica
    private let accountBiometric = "demo-biometric"
    /// Tag per identificare la chiave Secure Enclave nel Keychain
    private let seKeyTag = "com.secdemo.se.signing.key"
    /// Identificatore del gruppo App per la condivisione tra app
    /// ⚠️ Deve corrispondere all'entitlement configurato in Xcode → Signing & Capabilities
    private let appGroupIdentifier = "group.com.secdemo.shared"

    // MARK: - Generic Password (kSecClassGenericPassword)

    /// Salva una password generica nel Keychain con l'accessibilità specificata.
    ///
    /// `kSecClassGenericPassword` è la classe più comune per credenziali applicative.
    /// Identifica l'item con la coppia (service, account).
    ///
    /// Scelta dell'accessibilità consigliata:
    /// - App in foreground: `kSecAttrAccessibleWhenUnlockedThisDeviceOnly`
    /// - App con background fetch: `kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly`
    /// - MAI usare `kSecAttrAccessibleAlways` per dati sensibili
    ///
    /// - Parameters:
    ///   - password: Il valore segreto da salvare
    ///   - accessibility: Attributo kSecAttrAccessible* desiderato
    func saveGenericPassword(_ password: String,
                             accessibility: CFString = kSecAttrAccessibleWhenUnlockedThisDeviceOnly) {
        isProcessing = true
        errorMessage = nil
        Task {
            do {
                guard let passwordData = password.data(using: .utf8) else {
                    throw KeychainError.unexpectedData
                }

                // Dizionario di attributi dell'item Keychain.
                // kSecClass: definisce il tipo di item
                // kSecAttrService + kSecAttrAccount: identificano univocamente l'item
                // kSecValueData: il valore segreto cifrato dal sistema
                // kSecAttrAccessible: policy di accesso al dato
                let attributes: [CFString: Any] = [
                    kSecClass:          kSecClassGenericPassword,
                    kSecAttrService:    service,
                    kSecAttrAccount:    accountStandard,
                    kSecValueData:      passwordData,
                    kSecAttrAccessible: accessibility
                ]

                // Rimuove eventuali item precedenti per evitare errori errSecDuplicateItem
                let deleteQuery: [CFString: Any] = [
                    kSecClass:       kSecClassGenericPassword,
                    kSecAttrService: service,
                    kSecAttrAccount: accountStandard
                ]
                SecItemDelete(deleteQuery as CFDictionary)

                let status = SecItemAdd(attributes as CFDictionary, nil)
                guard status == errSecSuccess else {
                    throw KeychainError.unhandledError(status: status)
                }

                self.lastResult = """
                ✓ Password generica salvata
                Service: \(service)
                Account: \(accountStandard)
                Accessibilità: WhenUnlockedThisDeviceOnly
                Lunghezza: \(passwordData.count) byte
                """
            } catch {
                self.errorMessage = error.localizedDescription
            }
            self.isProcessing = false
        }
    }

    /// Legge una password generica dal Keychain.
    ///
    /// `kSecReturnData: true` indica al Keychain di restituire il valore cifrato.
    /// `kSecMatchLimit: kSecMatchLimitOne` restituisce solo il primo item corrispondente.
    func readGenericPassword() {
        isProcessing = true
        errorMessage = nil
        Task {
            do {
                let query: [CFString: Any] = [
                    kSecClass:       kSecClassGenericPassword,
                    kSecAttrService: service,
                    kSecAttrAccount: accountStandard,
                    kSecReturnData:  kCFBooleanTrue!,    // restituisci il valore come Data
                    kSecMatchLimit:  kSecMatchLimitOne   // solo il primo match
                ]

                var result: CFTypeRef?
                let status = SecItemCopyMatching(query as CFDictionary, &result)

                switch status {
                case errSecSuccess:
                    guard let data = result as? Data,
                          let password = String(data: data, encoding: .utf8) else {
                        throw KeychainError.unexpectedData
                    }
                    self.lastResult = "✓ Password letta: \"\(password)\""
                case errSecItemNotFound:
                    throw KeychainError.itemNotFound
                default:
                    throw KeychainError.unhandledError(status: status)
                }
            } catch {
                self.errorMessage = error.localizedDescription
            }
            self.isProcessing = false
        }
    }

    /// Aggiorna una password generica esistente nel Keychain.
    ///
    /// SecItemUpdate è preferibile a delete+add quando si vuole mantenere
    /// gli altri attributi dell'item (es: access control, accessibilità).
    func updateGenericPassword(_ newPassword: String) {
        isProcessing = true
        errorMessage = nil
        Task {
            do {
                guard let newPasswordData = newPassword.data(using: .utf8) else {
                    throw KeychainError.unexpectedData
                }

                // Query per trovare l'item da aggiornare
                let query: [CFString: Any] = [
                    kSecClass:       kSecClassGenericPassword,
                    kSecAttrService: service,
                    kSecAttrAccount: accountStandard
                ]

                // Dizionario con i nuovi valori
                let attributes: [CFString: Any] = [
                    kSecValueData: newPasswordData
                ]

                let status = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
                guard status == errSecSuccess else {
                    if status == errSecItemNotFound {
                        throw KeychainError.itemNotFound
                    }
                    throw KeychainError.unhandledError(status: status)
                }

                self.lastResult = "✓ Password aggiornata nel Keychain"
            } catch {
                self.errorMessage = error.localizedDescription
            }
            self.isProcessing = false
        }
    }

    /// Elimina una password generica dal Keychain.
    func deleteGenericPassword() {
        isProcessing = true
        errorMessage = nil
        Task {
            let query: [CFString: Any] = [
                kSecClass:       kSecClassGenericPassword,
                kSecAttrService: service,
                kSecAttrAccount: accountStandard
            ]
            let status = SecItemDelete(query as CFDictionary)
            if status == errSecSuccess || status == errSecItemNotFound {
                self.lastResult = "✓ Password eliminata dal Keychain"
            } else {
                self.errorMessage = KeychainError.unhandledError(status: status).localizedDescription
            }
            self.isProcessing = false
        }
    }

    // MARK: - Internet Password (kSecClassInternetPassword)

    /// Salva credenziali per un server web con kSecClassInternetPassword.
    ///
    /// A differenza di kSecClassGenericPassword, kSecClassInternetPassword
    /// include attributi aggiuntivi per identificare il server:
    /// - `kSecAttrServer`: hostname del server
    /// - `kSecAttrProtocol`: protocollo (kSecAttrProtocolHTTPS, ecc.)
    /// - `kSecAttrPort`: porta del server
    /// - `kSecAttrPath`: path URL
    /// - `kSecAttrAuthenticationType`: tipo di autenticazione
    func saveInternetPassword(username: String, password: String, server: String) {
        isProcessing = true
        errorMessage = nil
        Task {
            do {
                guard let passwordData = password.data(using: .utf8) else {
                    throw KeychainError.unexpectedData
                }

                let deleteQuery: [CFString: Any] = [
                    kSecClass:       kSecClassInternetPassword,
                    kSecAttrServer:  server,
                    kSecAttrAccount: username
                ]
                SecItemDelete(deleteQuery as CFDictionary)

                let attributes: [CFString: Any] = [
                    kSecClass:                kSecClassInternetPassword,
                    kSecAttrServer:           server,
                    kSecAttrAccount:          username,
                    kSecAttrProtocol:         kSecAttrProtocolHTTPS,
                    kSecAttrAuthenticationType: kSecAttrAuthenticationTypeHTTPBasic,
                    kSecValueData:            passwordData,
                    kSecAttrAccessible:       kSecAttrAccessibleWhenUnlockedThisDeviceOnly
                ]

                let status = SecItemAdd(attributes as CFDictionary, nil)
                guard status == errSecSuccess else {
                    throw KeychainError.unhandledError(status: status)
                }

                self.lastResult = """
                ✓ Credenziali Internet salvate
                Server: \(server)
                Username: \(username)
                Protocollo: HTTPS / HTTPBasic
                """
            } catch {
                self.errorMessage = error.localizedDescription
            }
            self.isProcessing = false
        }
    }

    // MARK: - Biometric Access Control

    /// Salva un segreto protetto da autenticazione biometrica.
    ///
    /// `SecAccessControlCreateWithFlags` crea un oggetto che definisce:
    /// - La policy di accessibilità base (es: WhenUnlockedThisDeviceOnly)
    /// - I flag di controllo accesso (es: biometryAny, biometryCurrentSet)
    ///
    /// **Flag disponibili:**
    /// - `.biometryAny`: qualsiasi biometria registrata (Face ID o Touch ID).
    ///   L'item rimane valido anche se vengono aggiunte nuove biometrie.
    /// - `.biometryCurrentSet`: SOLO le biometrie attualmente registrate.
    ///   L'item diventa inaccessibile se si aggiunge una nuova impronta/volto.
    ///   Più sicuro per app bancarie.
    /// - `.userPresence`: biometria O passcode.
    ///   Fallback al passcode se la biometria non è disponibile.
    /// - `.devicePasscode`: solo passcode, nessuna biometria.
    ///
    /// - Parameter secret: Il segreto da proteggere con Face ID / Touch ID
    func saveBiometricSecret(_ secret: String) {
        isProcessing = true
        errorMessage = nil
        Task {
            do {
                guard let secretData = secret.data(using: .utf8) else {
                    throw KeychainError.unexpectedData
                }

                // Crea il controllo di accesso biometrico.
                // kSecAttrAccessibleWhenUnlockedThisDeviceOnly: base dell'accessibilità
                // SecAccessControlCreateFlags.biometryAny: richiede Face ID o Touch ID
                var cfError: Unmanaged<CFError>?
                guard let accessControl = SecAccessControlCreateWithFlags(
                    kCFAllocatorDefault,
                    kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
                    [.biometryAny],   // usa .biometryCurrentSet per massima sicurezza
                    &cfError
                ) else {
                    throw cfError?.takeRetainedValue() as Error? ?? KeychainError.accessControlCreationFailed
                }

                // Il contesto LAContext permette di:
                // 1. Personalizzare il testo mostrato nel dialogo biometrico
                // 2. Riutilizzare un'autenticazione già avvenuta (touchIDAuthenticationAllowableReuseDuration)
                let context = LAContext()
                context.localizedReason = "Salva il segreto protetto da Face ID"

                // kSecAttrAccessControl sostituisce kSecAttrAccessible quando presente
                // kSecUseAuthenticationContext: usa il contesto LAContext personalizzato
                let attributes: [CFString: Any] = [
                    kSecClass:                    kSecClassGenericPassword,
                    kSecAttrService:              service,
                    kSecAttrAccount:              accountBiometric,
                    kSecValueData:                secretData,
                    kSecAttrAccessControl:        accessControl,
                    kSecUseAuthenticationContext: context
                ]

                let deleteQuery: [CFString: Any] = [
                    kSecClass:       kSecClassGenericPassword,
                    kSecAttrService: service,
                    kSecAttrAccount: accountBiometric
                ]
                SecItemDelete(deleteQuery as CFDictionary)

                let status = SecItemAdd(attributes as CFDictionary, nil)
                guard status == errSecSuccess else {
                    throw KeychainError.unhandledError(status: status)
                }

                self.lastResult = """
                ✓ Segreto biometrico salvato
                Protetto da: Face ID / Touch ID (biometryAny)
                La lettura richiederà autenticazione biometrica
                """
            } catch {
                self.errorMessage = error.localizedDescription
            }
            self.isProcessing = false
        }
    }

    /// Legge il segreto protetto da biometria.
    ///
    /// Quando SecItemCopyMatching tenta di accedere all'item, il sistema
    /// presenta automaticamente il dialogo Face ID / Touch ID.
    /// Se l'autenticazione fallisce → `errSecAuthFailed`.
    /// Se l'utente annulla → `errSecUserCanceled`.
    func readBiometricSecret() {
        isProcessing = true
        errorMessage = nil
        Task {
            do {
                let context = LAContext()
                context.localizedReason = "Accedi al segreto protetto da Face ID"

                let query: [CFString: Any] = [
                    kSecClass:                    kSecClassGenericPassword,
                    kSecAttrService:              service,
                    kSecAttrAccount:              accountBiometric,
                    kSecReturnData:               kCFBooleanTrue!,
                    kSecMatchLimit:               kSecMatchLimitOne,
                    kSecUseAuthenticationContext: context
                ]

                var result: CFTypeRef?
                let status = SecItemCopyMatching(query as CFDictionary, &result)

                switch status {
                case errSecSuccess:
                    guard let data = result as? Data,
                          let secret = String(data: data, encoding: .utf8) else {
                        throw KeychainError.unexpectedData
                    }
                    self.lastResult = "✓ Segreto biometrico letto: \"\(secret)\""
                case errSecItemNotFound:
                    throw KeychainError.itemNotFound
                case errSecUserCanceled:
                    throw KeychainError.authCancelled
                default:
                    throw KeychainError.unhandledError(status: status)
                }
            } catch {
                self.errorMessage = error.localizedDescription
            }
            self.isProcessing = false
        }
    }

    // MARK: - Secure Enclave

    /// Genera una chiave privata P-256 nel Secure Enclave con protezione biometrica.
    ///
    /// Il **Secure Enclave** è un coprocessore sicuro dedicato, presente in:
    /// - iPhone 5S e successivi
    /// - iPad Air 2, iPad mini 3 e successivi
    /// - Apple Watch (tutti i modelli)
    /// - Mac con chip T1, T2, M1, M2, M3, M4
    ///
    /// Proprietà della chiave generata nel Secure Enclave:
    /// - La chiave privata **non può MAI essere estratta** in chiaro
    /// - Le operazioni crittografiche avvengono fisicamente nel Secure Enclave
    /// - Anche con accesso root, la chiave privata non è recuperabile
    /// - Supporta: ECDSA (firma) e ECDH (key agreement) su curva P-256
    ///
    /// `dataRepresentation` della chiave è un **token opaco** che permette di
    /// ricaricare la chiave in sessioni future, ma non contiene il materiale privato.
    func generateSecureEnclaveKey() {
        isProcessing = true
        errorMessage = nil
        Task {
            do {
                // Verifica preliminare: il Secure Enclave non è disponibile su simulatore
                guard SecureEnclave.isAvailable else {
                    throw KeychainError.secureEnclaveUnavailable
                }

                // Crea il controllo di accesso per la chiave Secure Enclave.
                // .privateKeyUsage: flag obbligatorio per le chiavi Secure Enclave
                // .biometryAny: la chiave richiederà Face ID / Touch ID per ogni utilizzo
                var cfError: Unmanaged<CFError>?
                guard let accessControl = SecAccessControlCreateWithFlags(
                    kCFAllocatorDefault,
                    kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
                    [.privateKeyUsage, .biometryAny],
                    &cfError
                ) else {
                    throw cfError?.takeRetainedValue() as Error? ?? KeychainError.accessControlCreationFailed
                }

                // Genera la chiave P-256 nel Secure Enclave tramite CryptoKit.
                // SecureEnclave.P256.Signing.PrivateKey è il tipo CryptoKit specifico.
                // La chiave viene automaticamente persistita nel Secure Enclave;
                // dataRepresentation è il riferimento opaco da salvare nel Keychain.
                let privateKey = try SecureEnclave.P256.Signing.PrivateKey(
                    accessControl: accessControl
                )

                // Salva il dataRepresentation (token opaco, NON la chiave privata) nel Keychain
                let keyData = privateKey.dataRepresentation
                let tagData = seKeyTag.data(using: .utf8)!

                let deleteQuery: [CFString: Any] = [
                    kSecClass:              kSecClassKey,
                    kSecAttrApplicationTag: tagData
                ]
                SecItemDelete(deleteQuery as CFDictionary)

                let attributes: [CFString: Any] = [
                    kSecClass:              kSecClassKey,
                    kSecAttrKeyType:        kSecAttrKeyTypeECSECPrimeRandom,
                    kSecAttrApplicationTag: tagData,
                    kSecValueData:          keyData,
                    kSecAttrAccessControl:  accessControl,
                    // kSecAttrTokenID non necessario: gestiamo noi il token opaco
                ]

                let status = SecItemAdd(attributes as CFDictionary, nil)
                guard status == errSecSuccess else {
                    throw KeychainError.unhandledError(status: status)
                }

                let pubKeyHex = privateKey.publicKey.rawRepresentation.hexString
                self.secureEnclavePublicKey = pubKeyHex

                self.lastResult = """
                ✓ Chiave Secure Enclave generata
                Tipo: P-256 (secp256r1 / ECDSA)
                Chiave pubblica (65 byte): \(pubKeyHex.prefix(40))…
                Tag: \(seKeyTag)
                ⚠️ La chiave privata non può mai uscire dal Secure Enclave
                """
            } catch {
                self.errorMessage = error.localizedDescription
            }
            self.isProcessing = false
        }
    }

    /// Firma un messaggio con la chiave privata del Secure Enclave.
    ///
    /// Durante questa operazione:
    /// 1. Il sistema recupera il token opaco dal Keychain
    /// 2. Il Secure Enclave esegue la firma P-256 internamente
    /// 3. Viene presentato il dialogo Face ID / Touch ID (se configurato)
    /// 4. La firma viene restituita come DER-encoded ECDSA signature
    ///
    /// La verifica della firma avviene con la chiave **pubblica** (fuori dal Secure Enclave)
    func signWithSecureEnclaveKey(message: String) {
        isProcessing = true
        errorMessage = nil
        Task {
            do {
                guard SecureEnclave.isAvailable else {
                    throw KeychainError.secureEnclaveUnavailable
                }

                guard let messageData = message.data(using: .utf8) else {
                    throw KeychainError.unexpectedData
                }

                // Recupera il token opaco della chiave dal Keychain
                let tagData = seKeyTag.data(using: .utf8)!
                let query: [CFString: Any] = [
                    kSecClass:              kSecClassKey,
                    kSecAttrApplicationTag: tagData,
                    kSecAttrKeyType:        kSecAttrKeyTypeECSECPrimeRandom,
                    kSecReturnData:         kCFBooleanTrue!,
                    kSecMatchLimit:         kSecMatchLimitOne
                ]

                var item: CFTypeRef?
                let status = SecItemCopyMatching(query as CFDictionary, &item)
                guard status == errSecSuccess, let keyData = item as? Data else {
                    throw KeychainError.itemNotFound
                }

                // Ricostruisce la chiave dal dataRepresentation.
                // Questo attiva il prompt biometrico (se configurato con .biometryAny)
                let context = LAContext()
                context.localizedReason = "Firma il messaggio con Secure Enclave"

                let privateKey = try SecureEnclave.P256.Signing.PrivateKey(
                    dataRepresentation: keyData,
                    authenticationContext: context
                )

                // Firma: produce una firma ECDSA-P256 in formato DER.
                // L'hash SHA-256 del messaggio viene calcolato internamente.
                let signature = try privateKey.signature(for: messageData)

                // Verifica la firma con la chiave pubblica (operazione fuori dal SE)
                let isValid = privateKey.publicKey.isValidSignature(signature, for: messageData)

                self.lastResult = """
                ✓ Firma Secure Enclave completata
                Messaggio: "\(message)"
                Firma DER: \(signature.derRepresentation.hexString.prefix(40))…
                Lunghezza firma: \(signature.derRepresentation.count) byte
                Verifica: \(isValid ? "✓ VALIDA" : "✗ INVALIDA")
                """
            } catch {
                self.errorMessage = error.localizedDescription
            }
            self.isProcessing = false
        }
    }

    // MARK: - App Group Keychain Sharing

    /// Salva un segreto condiviso nell'App Group Keychain.
    ///
    /// L'**App Group Keychain** permette a più app dello stesso developer
    /// di condividere item nel portachiavi tramite `kSecAttrAccessGroup`.
    ///
    /// Configurazione necessaria in Xcode:
    /// 1. Target → Signing & Capabilities → "+ Capability" → "Keychain Sharing"
    /// 2. Aggiungere il gruppo: "group.com.secdemo.shared"
    /// 3. Aggiungere anche l'App Group entitlement se si usa un group. prefix
    ///
    /// Formato dell'access group:
    /// - Per app group: `group.<bundle_id>` (richiede App Groups capability)
    /// - Per keychain group: `<team_id>.<keychain_group_name>`
    ///
    /// - Parameter secret: Il segreto da condividere con le altre app del gruppo
    func saveToAppGroupKeychain(_ secret: String) {
        isProcessing = true
        errorMessage = nil
        Task {
            guard let secretData = secret.data(using: .utf8) else {
                self.errorMessage = "Impossibile convertire il segreto"
                self.isProcessing = false
                return
            }

            // kSecAttrAccessGroup: attributo fondamentale per la condivisione.
            // Il valore DEVE corrispondere a un gruppo configurato nell'entitlement
            // com.apple.security.keychain-access-groups del provisioning profile.
            let attributes: [CFString: Any] = [
                kSecClass:           kSecClassGenericPassword,
                kSecAttrService:     "com.secdemo.shared",
                kSecAttrAccount:     "shared-secret",
                kSecValueData:       secretData,
                kSecAttrAccessGroup: appGroupIdentifier,
                kSecAttrAccessible:  kSecAttrAccessibleWhenUnlockedThisDeviceOnly
            ]

            let deleteQuery: [CFString: Any] = [
                kSecClass:           kSecClassGenericPassword,
                kSecAttrService:     "com.secdemo.shared",
                kSecAttrAccount:     "shared-secret",
                kSecAttrAccessGroup: appGroupIdentifier
            ]
            SecItemDelete(deleteQuery as CFDictionary)

            let status = SecItemAdd(attributes as CFDictionary, nil)

            if status == errSecSuccess {
                self.lastResult = """
                ✓ Segreto salvato nell'App Group Keychain
                Access Group: \(appGroupIdentifier)
                Leggibile da qualsiasi app con lo stesso access group
                """
            } else if status == -34018 { // errSecMissingEntitlement
                // In un progetto demo senza entitlement App Group configurato
                self.lastResult = """
                ℹ️ App Group Keychain — Demo informativa
                Richiede entitlement: com.apple.security.keychain-access-groups
                Access Group da configurare: \(appGroupIdentifier)
                OSStatus: \(status) (errSecMissingEntitlement)
                Passaggi in Xcode: Signing & Capabilities → Keychain Sharing
                """
            } else {
                self.errorMessage = KeychainError.unhandledError(status: status).localizedDescription
            }

            self.isProcessing = false
        }
    }
}
